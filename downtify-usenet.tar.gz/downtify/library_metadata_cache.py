"""SQLite cache of per-file library display metadata (title/artist/album)."""

from __future__ import annotations

import sqlite3
import stat
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

from .library_cache_keys import (
    file_content_key,
    file_content_key_from_name_and_size,
)
from .library_metadata import library_entry_for_file
from .library_paths import locate_library_file
from .sqlite_utils import connect_sqlite

_TAG_READ_THREADS = 8

#: Bumped whenever a row gains fields read from the file's tags: rows
#: cached by an older version are treated as stale and re-read once.
#: 4: the audio format (codec, bitrate, sample rate, channels).
#: 5: genre (from tags, or iTunes when Sync cannot write the file).
META_VERSION = 5

#: Columns added after the table was first created, with their SQL type.
_ADDED_COLUMNS = {
    'has_cover': 'INTEGER NOT NULL DEFAULT 0',
    'cover_px': 'INTEGER NOT NULL DEFAULT 0',
    'album_artist': "TEXT NOT NULL DEFAULT ''",
    'track_number': 'INTEGER NOT NULL DEFAULT 0',
    'year': "TEXT NOT NULL DEFAULT ''",
    'duration': 'REAL NOT NULL DEFAULT 0',
    'meta_version': 'INTEGER NOT NULL DEFAULT 1',
    'codec': "TEXT NOT NULL DEFAULT ''",
    'bitrate': 'INTEGER NOT NULL DEFAULT 0',
    'sample_rate': 'INTEGER NOT NULL DEFAULT 0',
    'channels': 'INTEGER NOT NULL DEFAULT 0',
    'genre': "TEXT NOT NULL DEFAULT ''",
}

_ROW_COLUMNS = (
    'content_key, filename, file_mtime_ns, file_size, title, artist, '
    'album, has_cover, cover_px, album_artist, track_number, year, '
    'duration, meta_version, codec, bitrate, sample_rate, channels, '
    'genre'
)


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _norm_filename(filename: str) -> str:
    return str(filename or '').strip().replace('\\', '/')


def _file_stat(full_path: Path) -> tuple[int, int]:
    st = full_path.stat()
    return int(st.st_mtime_ns), int(st.st_size)


def _chunked(values: list[str], size: int):
    for index in range(0, len(values), size):
        chunk = values[index : index + size]
        if chunk:
            yield chunk


def _row_entry(
    stored: str, row: sqlite3.Row, item: dict[str, Any]
) -> dict[str, Any]:
    """A ``/tracks`` row from a fresh cache row plus the file's stat."""

    return {
        'file': stored,
        'title': str(row['title'] or ''),
        'artist': str(row['artist'] or ''),
        'album': str(row['album'] or ''),
        'album_artist': str(row['album_artist'] or ''),
        'track_number': int(row['track_number'] or 0),
        'year': str(row['year'] or ''),
        'duration': float(row['duration'] or 0.0),
        'codec': str(row['codec'] or ''),
        'bitrate': int(row['bitrate'] or 0),
        'sample_rate': int(row['sample_rate'] or 0),
        'channels': int(row['channels'] or 0),
        'genre': str(row['genre'] or '') if 'genre' in row.keys() else '',
        'has_cover': bool(int(row['has_cover'] or 0)),
        'cover_px': int(row['cover_px'] or 0),
        'added': int(item['mtime_ns']) // 1_000_000_000,
        'size': int(item['size']),
    }


class LibraryMetadataCache:
    """Caches ``/list`` rows; primary key is basename+size, not full path."""

    def __init__(self, db_path: Path) -> None:
        self._path = str(db_path)
        self._init_db()

    def _connect(self) -> sqlite3.Connection:
        return connect_sqlite(self._path, row_factory=True)

    def _init_db(self) -> None:
        with self._connect() as conn:
            row = conn.execute(
                "SELECT sql FROM sqlite_master WHERE name='library_metadata'"
            ).fetchone()
            if row is None:
                conn.execute("""
                    CREATE TABLE library_metadata (
                        content_key TEXT PRIMARY KEY,
                        filename TEXT NOT NULL,
                        title TEXT NOT NULL DEFAULT '',
                        artist TEXT NOT NULL DEFAULT '',
                        album TEXT NOT NULL DEFAULT '',
                        has_cover INTEGER NOT NULL DEFAULT 0,
                        cover_px INTEGER NOT NULL DEFAULT 0,
                        album_artist TEXT NOT NULL DEFAULT '',
                        track_number INTEGER NOT NULL DEFAULT 0,
                        year TEXT NOT NULL DEFAULT '',
                        duration REAL NOT NULL DEFAULT 0,
                        meta_version INTEGER NOT NULL DEFAULT 1,
                        codec TEXT NOT NULL DEFAULT '',
                        bitrate INTEGER NOT NULL DEFAULT 0,
                        sample_rate INTEGER NOT NULL DEFAULT 0,
                        channels INTEGER NOT NULL DEFAULT 0,
                        genre TEXT NOT NULL DEFAULT '',
                        file_mtime_ns INTEGER NOT NULL,
                        file_size INTEGER NOT NULL,
                        cached_at TEXT NOT NULL
                    )
                """)
                conn.execute("""
                    CREATE INDEX IF NOT EXISTS idx_library_metadata_filename
                    ON library_metadata (filename)
                """)
                return
            if not (row[0] and 'content_key' in str(row[0])):
                self._migrate_legacy_table(conn)
            self._ensure_columns(conn)

    @staticmethod
    def _ensure_columns(conn: sqlite3.Connection) -> None:
        cols = {
            str(r[1])
            for r in conn.execute('PRAGMA table_info(library_metadata)')
        }
        for name, sql_type in _ADDED_COLUMNS.items():
            if name not in cols:
                conn.execute(
                    f'ALTER TABLE library_metadata ADD COLUMN {name} {sql_type}'
                )

    @staticmethod
    def _migrate_legacy_table(conn: sqlite3.Connection) -> None:
        conn.execute("""
            CREATE TABLE library_metadata_new (
                content_key TEXT PRIMARY KEY,
                filename TEXT NOT NULL,
                title TEXT NOT NULL DEFAULT '',
                artist TEXT NOT NULL DEFAULT '',
                album TEXT NOT NULL DEFAULT '',
                file_mtime_ns INTEGER NOT NULL,
                file_size INTEGER NOT NULL,
                cached_at TEXT NOT NULL
            )
        """)
        rows = conn.execute('SELECT * FROM library_metadata').fetchall()
        for row in rows:
            filename = str(row['filename'])
            file_size = int(row['file_size'])
            ck = file_content_key_from_name_and_size(filename, file_size)
            if not ck:
                continue
            conn.execute(
                """INSERT OR REPLACE INTO library_metadata_new
                   (content_key, filename, title, artist, album,
                    file_mtime_ns, file_size, cached_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    ck,
                    filename,
                    str(row['title'] or ''),
                    str(row['artist'] or ''),
                    str(row['album'] or ''),
                    int(row['file_mtime_ns']),
                    file_size,
                    str(row['cached_at']),
                ),
            )
        conn.execute('DROP TABLE library_metadata')
        conn.execute(
            'ALTER TABLE library_metadata_new RENAME TO library_metadata'
        )
        conn.execute("""
            CREATE INDEX IF NOT EXISTS idx_library_metadata_filename
            ON library_metadata (filename)
        """)

    def get_entry(self, stored_path: str, full_path: Path) -> dict[str, Any]:
        """Return a ``/list`` row, reading tags only when cache is missing or stale."""

        rows = self.get_entries_batch([(stored_path, full_path)])
        return (
            rows[0] if rows else library_entry_for_file(stored_path, full_path)
        )

    def get_entries_batch(
        self, items: list[tuple[str, Path]]
    ) -> list[dict[str, Any]]:
        """Resolve many ``/tracks`` rows with one DB connection and batched lookups."""

        if not items:
            return []

        prepared: list[dict[str, Any]] = []
        for stored_path, full_path in items:
            name = _norm_filename(stored_path)
            if not name:
                prepared.append({
                    'stored': stored_path,
                    'full': full_path,
                    'ready': False,
                })
                continue
            try:
                file_stat = full_path.stat()
            except OSError:
                prepared.append({
                    'stored': stored_path,
                    'full': full_path,
                    'ready': False,
                })
                continue
            if not stat.S_ISREG(file_stat.st_mode):
                prepared.append({
                    'stored': stored_path,
                    'full': full_path,
                    'ready': False,
                })
                continue
            mtime_ns, size = int(file_stat.st_mtime_ns), int(file_stat.st_size)
            ck = file_content_key_from_name_and_size(full_path.name, size)
            prepared.append({
                'stored': stored_path,
                'full': full_path,
                'name': name,
                'ck': ck,
                'mtime_ns': mtime_ns,
                'size': size,
                'ready': True,
            })

        content_keys = [
            str(p['ck']) for p in prepared if p.get('ready') and p.get('ck')
        ]
        filenames = [str(p['name']) for p in prepared if p.get('ready')]

        by_ck: dict[str, sqlite3.Row] = {}
        by_name: dict[str, sqlite3.Row] = {}
        with self._connect() as conn:
            for chunk in _chunked(content_keys, 400):
                placeholders = ','.join('?' * len(chunk))
                query = f"""SELECT {_ROW_COLUMNS}
                            FROM library_metadata
                            WHERE content_key IN ({placeholders})"""
                for row in conn.execute(query, chunk):
                    by_ck[str(row['content_key'])] = row
            for chunk in _chunked(filenames, 400):
                placeholders = ','.join('?' * len(chunk))
                query = f"""SELECT {_ROW_COLUMNS}
                            FROM library_metadata
                            WHERE filename IN ({placeholders})"""
                for row in conn.execute(query, chunk):
                    by_name[_norm_filename(str(row['filename']))] = row

        results: list[Optional[dict[str, Any]]] = []
        filename_updates: list[tuple[str, str]] = []
        misses: list[tuple[int, dict[str, Any]]] = []

        for item in prepared:
            stored = str(item['stored'])
            if not item.get('ready'):
                misses.append((len(results), item))
                results.append(None)
                continue

            name = str(item['name'])
            ck = item.get('ck')
            row = by_ck.get(str(ck)) if ck else None
            if row is None:
                row = by_name.get(name)
            if (
                row is not None
                and int(row['file_mtime_ns']) == int(item['mtime_ns'])
                and int(row['file_size']) == int(item['size'])
                and int(row['meta_version'] or 1) >= META_VERSION
            ):
                if _norm_filename(str(row['filename'])) != name and ck:
                    filename_updates.append((name, str(ck)))
                results.append(_row_entry(stored, row, item))
                continue
            misses.append((len(results), item))
            results.append(None)

        # Tag reads on a miss mostly wait on the disk (HDD seeks, NAS
        # round-trips), where threads parallelize well — 2,000 files with a
        # simulated 2 ms I/O latency went from ~5 s sequential to ~0.6 s on
        # 8 threads.
        with ThreadPoolExecutor(
            max_workers=_TAG_READ_THREADS, thread_name_prefix='downtify-tags'
        ) as pool:
            read = list(
                pool.map(
                    lambda miss: library_entry_for_file(
                        str(miss[1]['stored']), miss[1]['full']
                    ),
                    misses,
                )
            )

        pending_stores: list[
            tuple[str, Optional[str], dict[str, Any], int, int]
        ] = []
        for (index, item), entry in zip(misses, read):
            results[index] = entry
            if item.get('ready'):
                pending_stores.append((
                    str(item['name']),
                    item.get('ck'),
                    entry,
                    int(item['mtime_ns']),
                    int(item['size']),
                ))

        if filename_updates or pending_stores:
            with self._connect() as conn:
                for index, (name, ck, entry, mtime_ns, size) in enumerate(
                    pending_stores,
                    start=1,
                ):
                    self._store_conn(conn, name, ck, entry, mtime_ns, size)
                    if index % 100 == 0:
                        conn.commit()
                for name, ck in filename_updates:
                    conn.execute(
                        'UPDATE library_metadata SET filename = ? WHERE content_key = ?',
                        (name, ck),
                    )

        return [entry for entry in results if entry is not None]

    def refresh(
        self, stored_path: str, full_path: Path
    ) -> Optional[dict[str, Any]]:
        """Re-read tags from disk and update the cache (e.g. after download)."""

        name = _norm_filename(stored_path)
        if not name or not full_path.is_file():
            self.forget(stored_path, full_path=full_path)
            return None
        try:
            mtime_ns, size = _file_stat(full_path)
        except OSError:
            self.forget(stored_path, full_path=full_path)
            return None
        entry = library_entry_for_file(stored_path, full_path)
        self._store(name, full_path, entry, mtime_ns, size)
        return entry

    def refresh_stored_path(
        self,
        stored_path: str,
        *,
        download_dir: Path,
        slskd_dir: Optional[Path] = None,
    ) -> None:
        full = locate_library_file(stored_path, download_dir, slskd_dir)
        if full is not None:
            self.refresh(stored_path, full)

    def forget(
        self,
        filename: str,
        *,
        full_path: Optional[Path] = None,
    ) -> None:
        name = _norm_filename(filename)
        if not name:
            return
        keys: list[str] = []
        if full_path is not None:
            ck = file_content_key(full_path)
            if ck:
                keys.append(ck)
        with self._connect() as conn:
            conn.execute(
                'DELETE FROM library_metadata WHERE filename = ?', (name,)
            )
            for ck in keys:
                conn.execute(
                    'DELETE FROM library_metadata WHERE content_key = ?', (ck,)
                )

    def _fetch_valid(
        self,
        stored_path: str,
        full_path: Path,
        mtime_ns: int,
        size: int,
    ) -> Optional[tuple[int, int, str, str, str]]:
        ck = file_content_key(full_path)
        if ck:
            row = self._fetch_by_content_key(ck)
            if row is not None and row[0] == mtime_ns and row[1] == size:
                self._touch_filename(ck, stored_path)
                return row
        row = self._fetch_by_filename(stored_path)
        if row is not None and row[0] == mtime_ns and row[1] == size:
            return row
        return None

    def _touch_filename(self, content_key: str, filename: str) -> None:
        name = _norm_filename(filename)
        if not name:
            return
        with self._connect() as conn:
            conn.execute(
                'UPDATE library_metadata SET filename = ? WHERE content_key = ?',
                (name, content_key),
            )

    def _fetch_by_content_key(
        self, content_key: str
    ) -> Optional[tuple[int, int, str, str, str]]:
        with self._connect() as conn:
            row = conn.execute(
                """SELECT file_mtime_ns, file_size, title, artist, album
                   FROM library_metadata WHERE content_key = ?""",
                (content_key,),
            ).fetchone()
        if row is None:
            return None
        return (
            int(row['file_mtime_ns']),
            int(row['file_size']),
            str(row['title'] or ''),
            str(row['artist'] or ''),
            str(row['album'] or ''),
        )

    def _fetch_by_filename(
        self, filename: str
    ) -> Optional[tuple[int, int, str, str, str]]:
        with self._connect() as conn:
            row = conn.execute(
                """SELECT file_mtime_ns, file_size, title, artist, album
                   FROM library_metadata WHERE filename = ?""",
                (filename,),
            ).fetchone()
        if row is None:
            return None
        return (
            int(row['file_mtime_ns']),
            int(row['file_size']),
            str(row['title'] or ''),
            str(row['artist'] or ''),
            str(row['album'] or ''),
        )

    @staticmethod
    def _store_conn(
        conn: sqlite3.Connection,
        filename: str,
        content_key: Optional[str],
        entry: dict[str, Any],
        mtime_ns: int,
        file_size: int,
    ) -> None:
        if not content_key:
            return
        name = _norm_filename(filename)
        conn.execute(
            """INSERT INTO library_metadata
               (content_key, filename, title, artist, album, has_cover,
                cover_px, album_artist, track_number, year, duration,
                meta_version, codec, bitrate, sample_rate, channels, genre,
                file_mtime_ns, file_size, cached_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
                       ?, ?)
               ON CONFLICT(content_key) DO UPDATE SET
               filename=excluded.filename,
               title=excluded.title,
               artist=excluded.artist,
               album=excluded.album,
               has_cover=excluded.has_cover,
               cover_px=excluded.cover_px,
               album_artist=excluded.album_artist,
               track_number=excluded.track_number,
               year=excluded.year,
               duration=excluded.duration,
               meta_version=excluded.meta_version,
               codec=excluded.codec,
               bitrate=excluded.bitrate,
               sample_rate=excluded.sample_rate,
               channels=excluded.channels,
               genre=excluded.genre,
               file_mtime_ns=excluded.file_mtime_ns,
               file_size=excluded.file_size,
               cached_at=excluded.cached_at""",
            (
                content_key,
                name,
                str(entry.get('title') or ''),
                str(entry.get('artist') or ''),
                str(entry.get('album') or ''),
                1 if entry.get('has_cover') else 0,
                int(entry.get('cover_px') or 0),
                str(entry.get('album_artist') or ''),
                int(entry.get('track_number') or 0),
                str(entry.get('year') or ''),
                float(entry.get('duration') or 0.0),
                META_VERSION,
                str(entry.get('codec') or ''),
                int(entry.get('bitrate') or 0),
                int(entry.get('sample_rate') or 0),
                int(entry.get('channels') or 0),
                str(entry.get('genre') or ''),
                mtime_ns,
                file_size,
                _now_iso(),
            ),
        )

    def _store(
        self,
        filename: str,
        full_path: Path,
        entry: dict[str, Any],
        mtime_ns: int,
        file_size: int,
    ) -> None:
        ck = file_content_key(full_path)
        if not ck:
            return
        with self._connect() as conn:
            self._store_conn(
                conn,
                filename,
                ck,
                entry,
                mtime_ns,
                file_size,
            )

    def merge_fields(
        self,
        stored_path: str,
        full_path: Path,
        fields: dict[str, Any],
    ) -> None:
        """Patch cached display fields without re-reading the audio file."""

        name = _norm_filename(stored_path)
        ck = file_content_key(full_path)
        if not name or not ck or not fields:
            return
        assignments: list[str] = []
        values: list[Any] = []
        if 'has_cover' in fields:
            assignments.append('has_cover = ?')
            values.append(1 if fields.get('has_cover') else 0)
        if 'cover_px' in fields:
            assignments.append('cover_px = ?')
            values.append(int(fields.get('cover_px') or 0))
        if 'genre' in fields:
            assignments.append('genre = ?')
            values.append(str(fields.get('genre') or ''))
        if not assignments:
            return
        assignments.append('cached_at = ?')
        values.append(_now_iso())
        values.append(ck)
        with self._connect() as conn:
            conn.execute(
                f"""UPDATE library_metadata SET {', '.join(assignments)}
                    WHERE content_key = ?""",
                values,
            )
