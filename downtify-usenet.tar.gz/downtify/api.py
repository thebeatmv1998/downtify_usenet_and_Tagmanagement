"""FastAPI router exposed by Downtify.

The endpoints intentionally mirror the surface that the previous
``spotdl``-powered backend exposed so the existing Vue frontend keeps
working without changes.

Library reads are per-user: a ``user`` browses only tracks, likes,
playlists, batches and queue jobs of their own (see
:mod:`downtify.track_owners` and ``docs/features/users.md``); an
``admin`` sees everything. Playing, streaming, searching and asking
for downloads stay shared, and files are never stored twice.

* ``GET  /api/version``
* ``GET  /api/health`` (liveness probe for the Docker ``HEALTHCHECK`` -
  see ``healthcheck.sh``; always ``200`` once the server can answer
  requests, regardless of downloader/monitor readiness)
* ``GET  /api/songs/search``
* ``GET  /api/artists/search``
* ``GET  /api/discover/chart`` (Deezer's own global "what's trending"
  chart - no auth, no genre filter - as ``{tracks, albums, artists,
  playlists}``; tracks are shaped like ``/api/songs/search``
  (``source: 'deezer'``, plus ``preview_url`` when Deezer offers a 30s
  clip) and downloadable the same way; albums/artists/playlists are
  read-only summaries - Downtify has no Deezer discography resolver,
  so their ``url`` only opens on Deezer, unlike a YouTube Music/Spotify
  result)
* ``GET  /api/finder/search`` (the Finder page's Deezer-only free-text
  search: ``{songs, albums, artists}``; songs shaped like the chart's
  tracks plus ``deezer_artist_id``/``deezer_album_id``, albums/artists
  as summaries with Deezer ids, fans and track/album counts)
* ``GET  /api/finder/artist`` (``artist_id``, ``lang``: a Deezer
  artist's photo, fans, album count, plain-text ``bio``, ``social``
  links, ``related`` artists and ``top_songs``)
* ``GET  /api/finder/artist/songs`` (``artist_id``, ``name``: the
  artist's songs as a Finder search's ``{songs, albums, artists}`` - a
  name search kept to rows by that Deezer id; albums/artists empty)
* ``GET  /api/finder/artist/albums`` (``artist_id``: their whole
  discography, most recent first; ``track_count`` is ``null`` until
  known)
* ``GET  /api/finder/albums/track_counts`` (``ids``, comma-separated, 50
  at most: ``{album_id: track_count}`` for the ones Deezer answered -
  throttled under Deezer's request quota)
* ``GET  /api/finder/album`` (``album_id``: label, genres, UPC, length,
  fans, contributors and ``tracks``, downloadable song rows)
* ``GET  /api/artists/top_songs`` (an artist's "Top songs" shelf preview,
  same shape as ``/api/songs/search`` - no further pagination offered)
* ``GET  /api/artists/top_albums`` (an artist's 5 most popular albums,
  sorted by YouTube Music's own "Popularity" order; same shape as
  ``/api/albums/search``; for every album/single, use ``/api/url`` on
  the artist's channel URL instead)
* ``GET  /api/artists/info`` (an artist's own profile: name, thumbnail,
  bio - not their releases)
* ``GET  /api/artists/similar`` (an artist's "Fans might also like"
  shelf, same shape as ``/api/artists/search``)
* ``GET  /api/artists/art`` (``{photo_url, banner_url, photo_version,
  banner_version}`` - the version, the file's modified time in ms, goes in
  the URL as ``?v=`` so a replaced image isn't served from a browser
  cache - whichever of an
  artist's saved photo/banner sidecar files exist under
  ``/downloads/.metadata/...``)
* ``GET  /api/artists/photo-proxy`` (DISPLAY-ONLY photo of an artist
  that has no saved one - a related artist, or a Library artist (in the
  grid and on its own page) nobody picked a photo for - relayed from
  Deezer and never stored - see
  ``downtify.artist_photo_proxy``; browser-cached for three hours - a
  photo, or Deezer having none (404) - but a photo already saved locally
  is served uncached instead, and a failure is a 503 that is never cached;
  ``?url=``, optional, is the artist's Deezer picture when the page
  already has it - Discover, the Finder - base64url-encoded, relayed
  without a search by name)
* ``POST /api/artists/art/bulk`` (the same, for many artists at once -
  body ``{names}``, response ``{<name>: {photo_url, banner_url,
  photo_version, banner_version}}`` - used
  by the Library page's artist grid)
* ``GET  /api/artists/art/search`` (free-text artist photo candidates from
  YouTube Music + Deezer, each ``{source, name, image_url}``)
* ``GET  /api/artists/art/spotify_candidate`` (a Spotify photo or banner
  candidate - ``kind`` query param - resolved from one already-downloaded
  track's Spotify id when ``file`` gives one (see
  ``downtify.track_index``), else from an exact-name search on the
  optional ``name`` param)
* ``POST /api/artists/art/from_url`` (fetch and save a chosen candidate or
  a pasted image link as an artist's photo or banner)
* ``POST /api/artists/art/upload`` (save an uploaded photo/banner - the
  raw image bytes as the request body, like ``POST /api/cookies``)
* ``DELETE /api/artists/art`` (remove a saved photo or banner)
* ``GET  /api/artists/profile`` (an artist's saved profile JSON: bio,
  origin, formation year, group flag, banner colour, social links,
  related artists, platform ids, which source their current photo/
  banner came from - a blank skeleton if nothing was saved yet; never
  seeds one, see ``POST .../ensure`` below for that)
* ``GET  /api/artists/top_songs/spotify`` (the artist's first five Spotify
  top songs, same shape as ``/api/artists/top_songs/url`` plus
  ``fetched_at``/``stale`` - read from ``.metadata/ArtistTopSongs/`` while
  fresh (7 days), fetched and saved when missing, refreshed in the
  background when stale; needs ``platforms_id.spotify`` in the profile)
* ``POST /api/artists/profile/ensure`` (seed a brand-new artist's
  profile the first time it's needed - Spotify/YouTube Music photo and
  banner (each only when its ``download_cover_art_artist``/``..._banner``
  setting is on), then everything ``.../bio`` below would fetch - a no-op
  once a profile file exists at all, even an empty one; body
  ``{name, lang, track_files}``)
* ``POST /api/artists/profile/bio`` (fetch bio and save it - Apple Music
  primary (also brings origin/formation year/genre/group flag/banner
  colour), Deezer secondary (bio fallback + social links + related artists) -
  body ``{name, lang, source?}`` (``source`` = ``applemusic`` or ``deezer``
  to save only that service's bio, no fallback; default: both, in that
  order); resolves and caches the artist's Apple Music/Deezer ids on first
  use)
* ``POST /api/artists/profile/bio/preview`` (one service's bio text only -
  body ``{name, lang, source}``, ``source`` = ``applemusic`` or ``deezer``;
  response ``{bio}``; saves nothing, the edit modal loads it into its text
  box and the user keeps it with ``PUT .../bio``)
* ``DELETE /api/artists/profile/bio`` (clear only the saved bio text -
  everything else is kept)
* ``PUT  /api/artists/profile/bio`` (manually set the bio text directly -
  body ``{name, bio}``; the user's own text, never fetched)
* ``PUT  /api/artists/profile/social`` (manually set all five social
  links directly - body ``{name, social: {twitter, facebook, website,
  instagram, youtube}}``; replaces the whole object, never fetched)
* ``GET  /api/song/url`` and ``GET /api/url`` (alias; ``/api/url`` also
  resolves an artist channel/``@handle`` (YouTube Music) or artist link
  (Deezer) URL into every one of their albums/singles as lightweight
  summaries, same shape as ``/api/albums/search`` - no tracklists;
  resolve a chosen release's tracks separately). A YouTube Music or
  Deezer playlist URL resolves to its tracks, like a Spotify playlist.
  Accepts a Spotify, YouTube Music or Deezer track/album/playlist URL
  (plus a YouTube Music/Deezer artist URL, as above).
* ``GET  /api/url/resolve`` (the same links, always as
  ``{kind, name, subtitle, cover_url, year, tracks, albums}`` - adds the
  playlist/album name and cover the plain track list lacks; a Deezer
  track's own ``preview_url`` survives into its song row, same as
  ``/api/discover/chart``)
* ``GET  /api/artists/top_songs/url`` (a Spotify, YouTube Music or Deezer
  artist URL - ``open.spotify.com/artist/...``, ``/channel/UC...``,
  ``/@handle`` or ``deezer.com/artist/...`` - resolved to ``{source,
  artist_id, name, cover_url, songs}``: the artist's own "Popular" /
  "Top songs" / "top" shelf, in the order the source ranks it)
* ``POST /api/download/url`` (optional JSON body: resolved Spotify row so
  ``track_number`` / ``album_track_total`` survive re-fetch by URL; a
  ``"source": "deezer"`` body is taken as-is instead, see
  ``_song_from_download_request``)
* ``POST /api/download/batch`` (JSON body ``{songs, playlist_url,
  generate_m3u}``; instead of ``playlist_url`` a caller may pass an
  explicit ``playlist_name`` and ``cover_url`` - e.g. an artist's top
  songs selection, which isn't backed by a real playlist id; a Deezer
  ``playlist_url`` gets the same per-playlist folder, M3U and cover as a
  Spotify/YouTube Music one, but isn't tracked as a resumable batch)
* ``POST /api/download/album`` (YouTube Music album/browse URL only;
  downloads every track from one shared, already-resolved tracklist so
  metadata stays consistent across the whole release)
* ``POST /api/download/csv`` (import a library-export CSV from Soundiiz,
  TuneMyMusic, Exportify, etc.; JSON body ``{csv, playlist_name,
  generate_m3u}`` - the raw CSV text, read client-side, not a multipart
  upload)
* ``POST /api/playlist/m3u``
* ``GET  /api/queue``, ``DELETE /api/queue``, ``DELETE /api/queue/item``
  and ``DELETE /api/queue/completed`` (drop finished jobs only)
* ``DELETE /api/library/playlist`` (delete a downloaded playlist's
  tracks, M3U and catalog entry; a manual playlist only loses the M3U)
* ``GET  /api/library/summary`` (Home page: counts + recent albums)
* ``GET  /api/library/albums`` (Library albums tab: albums without tracks)
* ``GET  /api/library/artists`` (Library artists tab / Discover)
* ``POST /api/library/lookup`` (search/link songs already in the library)
* ``POST /api/library/playlists`` (create an empty editable playlist)
* ``POST /api/library/playlists/tracks`` (add or remove tracks on a
  manual playlist)
* ``POST /api/library/playlists/rename`` (rename a manual playlist)
* ``POST /api/library/reconcile`` (fix stored library paths after files
  moved on disk, then refresh M3U/Navidrome playlists)
* ``POST /api/library/external/sync`` (start a background scan of
  extra folders) and ``GET /api/library/external/sync`` (running or
  last-finished status)
* ``POST /api/library/external/unmap`` (drop one extra folder from
  the library without deleting the audio files)
* ``GET  /api/library/replace/candidates`` (versions of a library track
  to pick from: YouTube Music and YouTube results, or a pasted link) and
  ``POST /api/library/replace`` (body ``{file, video_id}``: replace the
  track's audio with that video in place, as a queue job - see
  ``downtify/audio_replace.py``)
* ``GET  /api/library/upgrade`` and ``GET /api/library/upgrade/jobs``
  (an upgrade run's state, queue counts and per-track rows)
* ``POST /api/library/upgrade/scan`` (look for tracks with low-resolution
  artwork, no lyrics, incomplete tags or an album folder with no cover
  image; writes nothing), ``POST /api/library/upgrade/start`` (body
  ``{categories}``) and ``POST /api/library/upgrade/{pause,resume,cancel}``
* ``POST /api/library/albums/merge/preview`` (albums the tag sources say
  belong together, writes nothing) and ``POST /api/library/albums/merge``
  (body ``{plans}``: retag and move the confirmed albums into one folder
  each, then refresh the playlists that pointed at them)
* ``POST /api/library/playlists/rebuild`` (rewrite every known playlist's
  M3U from what is already on disk, including songs it did not download
  in the last batch)
* ``GET  /api/library/tags`` (every editable tag of one track) and
  ``POST /api/library/tags`` (body ``{file, fields, cover?, remove_cover?}``:
  write them, with an optional new cover, in place)
* ``GET  /api/library/tags/search`` (MusicBrainz or Discogs release
  candidates for a track) and ``GET /api/library/tags/release`` (a chosen
  release's album metadata and ordered tracklist) - see
  ``downtify/musicbrainz.py`` / ``downtify/discogs.py``
* ``GET  /api/library/duplicates`` (duplicate titles and albums in the
  library, for review and deletion via ``DELETE /delete/batch``)
* ``GET  /api/playlists/batches`` and
  ``GET|DELETE /api/playlists/batches/{spotify_playlist_id}`` (Spotify
  playlist downloads and their completeness against Spotify)
* ``GET  /api/playlists/incomplete`` and
  ``POST /api/playlists/incomplete/download-missing`` (queue only the
  tracks a downloaded playlist is still missing)
* ``GET  /api/settings``
* ``POST /api/settings/update``
* ``GET  /api/fs/dirs`` (admin: directory-name suggestions for path
  fields, ``?path=``)
* ``POST /api/slskd/test`` and ``POST /api/navidrome/test`` (try the
  connection with the settings as they are in the form, saved or not)
* ``GET  /api/cookies`` (current YouTube cookie configuration)
* ``POST /api/cookies`` (upload a Netscape cookies.txt as the raw request
  body - no multipart, so no ``python-multipart`` dependency)
* ``DELETE /api/cookies`` (remove the uploaded cookies.txt)
* ``GET|POST /api/monitor/playlists`` and
  ``PATCH|DELETE /api/monitor/playlists/{playlist_id}`` (playlist and
  artist watches; ``PATCH`` takes ``interval_minutes``, ``enabled`` and
  ``url`` - a link to a different playlist/artist of the same kind
  retargets the watch; artist watches also take ``release_types``
  (``album``/``single``/``ep``) and ``new_only``, on ``POST`` too),
  ``POST /api/monitor/playlists/{id}/check``
* ``GET|PUT /api/likes`` and ``POST /api/likes/clear`` (the heart on a
  library track; while any song is liked they are also written out as a
  playlist)
* ``POST /api/podcasts/resolve`` (preview a podcast from a pasted RSS
  or Spotify show/episode link) and ``GET /api/podcasts/search``
  (free-text, via the iTunes podcast directory)
* ``POST /api/podcasts/subscribe``, ``GET /api/podcasts/shows``,
  ``GET|PATCH|DELETE /api/podcasts/shows/{id}`` and
  ``GET /api/podcasts/shows/{id}/episodes`` (subscriptions are a watch
  kind in ``monitor.py``, checked on the same schedule as playlists and
  artists — see ``downtify.podcasts``)
* ``POST /api/podcasts/episodes/{id}/download``,
  ``DELETE /api/podcasts/episodes/{id}`` and
  ``PUT /api/podcasts/episodes/{id}/playback`` (per-episode download,
  removal and resume position)
* ``POST /api/discover`` (suggested artists the library doesn't have
  yet - body ``{library: [{name, tracks, liked}]}``, the Library page's
  own artist grouping; response ``{artists: [{name, deezer_id,
  picture_url, fans, score, because}], seeds, partial}`` - see
  ``downtify.discover``), ``POST /api/discover/collections`` (albums and
  playlists built on those artists - same body plus ``albums: [{artist,
  title}]`` and ``playlist_ids``; response ``{albums, more_albums,
  playlists, artist_urls, partial}``; Spotify only), ``POST
  /api/discover/collections/deezer`` (the same shelves from Deezer
  alone, the web page's first answer - body adds ``playlist_names``;
  every item carries ``source: 'deezer'`` and Deezer ids, albums also
  ``key``, playlists are Deezer's "100% <artist>"), ``POST
  /api/discover/collections/spotify`` (what Spotify adds, the second
  answer - body adds ``shown``, the album ``key``\\ s already on the page;
  albums matched to Deezer by name come with ``source: 'deezer'``, the
  rest ``'spotify'``; playlists are only Spotify's "This Is <artist>"),
  ``POST|DELETE
  /api/discover/listens`` (count
  one listen to an artist - body ``{artist}`` - or forget them all) and
  ``GET|POST|DELETE /api/discover/blocked`` (artists never to suggest -
  ``POST`` body ``{name}``, ``DELETE`` takes ``?name=``)
 * ``GET  /api/preview`` (a song's 30 s preview clip from Deezer, for a
   song with no ``preview_url`` of its own - ``?artist=&title=&duration=``,
   response ``{preview_url}``, ``""`` when Deezer has no matching song)
 * ``GET  /api/similar/tracks`` (tracks similar to ``?artist=&track=``
   via YouTube Music's own radio mix for the track - downloadable song
   rows plus ``match`` - see
   ``downtify.providers.youtube_similar_tracks``)
 * ``GET  /api/stream`` (a track's full audio as a fresh,
   short-lived direct URL - ``?video_id=`` - for third-party clients;
   the web player behind a song that isn't downloaded yet uses
   ``/api/stream/file`` below instead - see ``downtify.stream``)
 * ``GET  /api/stream/file`` (that same audio downloaded once into
   ``/data/stream_cache`` and served from this server with seeking
   support - ``?video_id=``; what the web player streams, so playback
   never depends on the browser reaching YouTube itself)
 * ``POST /api/stream/prefetch`` (body ``{video_id}``: start caching
   that audio in the background and answer ``{queued: true}`` at once -
   how the player warms the next track up)
* ``GET  /api/server/info`` (public: server id, name, version,
  ``api_version``, ``require_sign_in`` (always true), capabilities) and
  ``PATCH /api/server`` (``{name}``) - see ``downtify/auth_routes.py``
* ``GET  /api/auth/status``, ``POST /api/auth/login`` (``{username,
  password}``), ``POST /api/auth/logout`` (signing in), ``GET|PATCH|DELETE
  /api/auth/devices[/{id}]`` (your paired apps; everyone's for an admin),
  ``POST /api/auth/revoke-all`` (everyone signed out), ``POST
  /api/auth/pairing``, ``GET|DELETE /api/auth/pairing/{id}``, ``POST
  /api/auth/pair`` (pairing an app) and ``POST /api/auth/ws-ticket`` -
  see ``downtify/auth.py`` for who may call what
* ``GET|PATCH /api/me``, ``PUT /api/me/password``, ``GET|PUT
  /api/me/preferences``, ``POST /api/me/sign-out-everywhere`` (your
  account), ``GET|POST /api/users``, ``PATCH|DELETE /api/users/{id}``
  (admins), ``GET /api/activity``, ``GET /api/activity/now`` (admins) and
  ``POST /api/activity/playback`` (players report what they play) - see
  ``downtify/account_routes.py``
* ``/api/v1/...``: the apps' API, by track id - ``GET /api/v1/library``
  (``?since=`` change feed), ``GET /api/v1/tracks/{id}`` (and
  ``/stream``, ``/cover``, ``/lyrics``), ``GET /api/v1/playlists``,
  ``GET|PUT /api/v1/likes`` and ``POST /api/v1/sign`` - see
  ``downtify/mobile_routes.py`` and ``docs/mobile-client-contract.md``
* ``WS   /api/ws`` (also ``library_changed``, ``device_paired``
  messages; a device token, session cookie or ``?ticket=`` is needed)
* ``GET  /api/check_update``
"""

from __future__ import annotations

import asyncio
import base64
import concurrent.futures.thread as cf_thread
import contextlib
import hashlib
import json
import mimetypes
import re
import shutil
import threading
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Collection, Optional
from urllib.parse import quote

from fastapi import (
    APIRouter,
    Body,
    HTTPException,
    Query,
    Request,
    Response,
    WebSocket,
    WebSocketDisconnect,
)
from fastapi.responses import FileResponse
from loguru import logger

from . import (
    album_merge,
    artist_photo_proxy,
    artist_profile,
    audio_replace,
    cover_sources,
    deezer,
    discogs,
    duplicates,
    integration_check,
    library_import,
    library_playlists,
    library_upgrade,
    lyrics,
    m3u,
    musicbrainz,
    providers,
    spotify,
    stream,
    tag_editor,
)
from .activity import ActivityLog, NowPlaying, describe_user_agent
from .auth import (
    AuthStore,
    PairingStore,
    Principal,
    RateLimiter,
    TicketStore,
    client_ip,
    trusted_proxies_from_env,
)
from .cookies import MAX_COOKIES_BYTES, CookiesStore, InvalidCookiesFile
from .cover_cache import CoverArtCache
from .cover_thumbs import CoverThumbs
from .discover import (
    DiscoverStore,
    collections,
    deezer_collections,
    recommendations,
    spotify_collections,
)
from .downloader import (
    AUDIO_PROVIDERS,
    DOWNLOAD_EXECUTOR,
    MAX_PARALLEL_DOWNLOADS,
    MAX_TRACK_DURATION_SECONDS,
    Downloader,
    NoAudioMatchError,
    TrackTooLongError,
    save_playlist_cover,
)
from .external_library import (
    effective_external_library,
    extra_dirs_from_settings,
)
from .external_sync import (
    ExternalSyncJob,
    folders_removed,
    run_external_sync,
    unmap_extra_folder,
)
from .fs_suggest import suggest_directories
from .library_catalog import (
    LibraryContext,
    drop_library_listing_files,
    entry_content_key,
    library_album_index,
    library_artist_index,
    library_context_from_state,
    library_home_summary,
    list_library_entries,
    list_library_paths,
    listing_for_request,
    lookup_library_songs,
    merge_library_listing_file,
    resolve_library_file,
)
from .library_delete import (
    delete_library_files,
    delete_playlist_from_library,
    remove_playlist_shell,
)
from .library_metadata import read_audio_metadata
from .library_metadata_cache import LibraryMetadataCache
from .library_paths import locate_library_file, slskd_dir_from_downloader
from .library_paths_cache import (
    add_invalidation_listener,
    invalidate_library_paths_cache,
)
from .library_reconcile import (
    playlist_refresh_enabled,
    reconcile_and_refresh,
    refresh_playlists_after_moves,
)
from .library_sync import LibrarySync
from .likes import (
    LIKED_PLAYLIST_NAME,
    LikedTracks,
    content_key_for,
    is_liked_playlist,
    remap_moved,
    sync_liked_playlist,
)
from .lyrics_cache import LyricsLookupCache
from .manual_playlists import (
    ManualPlaylistError,
    create_manual_playlist,
    edit_manual_playlist,
    rename_manual_playlist,
)
from .monitor import (
    ALL_RELEASE_TYPES,
    KIND_ARTIST,
    KIND_PLAYLIST,
    KIND_PODCAST,
    SOURCE_SPOTIFY,
    LibraryStores,
    MonitoredPlaylist,
    PlaylistMonitorDB,
    check_watch,
    download_playlist_cover,
    fetch_playlist,
    normalize_release_types,
    parse_playlist_url,
)
from .navidrome import _effective_navidrome_settings, cache_navidrome_song_id
from .navidrome_index import NavidromeIndex
from .playlist_batches import (
    PlaylistBatchStore,
    active_queue_count_for_playlist,
    split_tracks_by_library,
)
from .playlist_catalog import ManualPlaylistOwners, PlaylistCatalog
from .playlist_listing import list_library_playlists
from .playlist_spotify_cache import (
    PlaylistSpotifyCache,
    fetch_playlist_tracks,
    is_spotify_playlist_id,
)
from .playlist_tracks import build_library_song_index, resolve_track_file
from .podcasts import (
    PODCASTS_DIRNAME,
    EpisodeInfo,
    PodcastFeedNotFoundError,
    PodcastStore,
    best_cover_bytes,
    download_episode,
    fetch_feed,
    resolve_spotify_podcast,
    search_shows,
)
from .server_identity import ServerIdentity
from .slskd_provider import reset_slskd_parallelism
from .stream import StreamCache
from .track_index import (
    TrackIndex,
    normalize_spotify_track_id,
    resolve_existing_download,
)
from .track_owners import TrackOwners
from .traffic import DIRECTION_IN, TrafficCounters
from .transcode import Transcoder
from .update_check import UpdateChecker
from .usenet_provider import (
    SabnzbdClient as UsenetSabnzbdClient,
)
from .usenet_provider import (
    reset_usenet_parallelism,
)

MIN_PARALLEL_DOWNLOADS = 1

MIN_DOWNLOAD_DELAY_SECONDS = 0
MAX_DOWNLOAD_DELAY_SECONDS = 300

#: Longest track taken (seconds); ``0`` takes everything. The default
#: is :data:`downtify.downloader.MAX_TRACK_DURATION_SECONDS`.
MIN_TRACK_DURATION_SETTING_SECONDS = 0
MAX_TRACK_DURATION_SETTING_SECONDS = 6 * 3600

MIN_COVER_RESOLUTION = 300
MAX_COVER_RESOLUTION = 1200

DEFAULT_SETTINGS: dict[str, Any] = {
    'audio_providers': ['youtube-music'],
    'lyrics_providers': list(lyrics.PROVIDER_ORDER),
    'download_lyrics': True,
    'lyrics_lrc_beside': True,
    'lyrics_lrc_dir': lyrics.DEFAULT_LYRICS_LRC_DIR,
    'format': 'mp3',
    'bitrate': '320',
    'output': '{artists} - {title}.{output-ext}',
    'generate_m3u': True,
    'download_cover_art_playlists': True,
    # Whether Downtify may save an artist's photo/banner on its own: when
    # their Library page is first opened and when one of their tracks
    # finishes downloading (``enrich_artist_after_download``). The manual
    # picker on an artist's Library page never checks these.
    'download_cover_art_artist': True,
    'download_cover_art_artist_banner': False,
    'max_parallel_downloads': 3,
    'download_delay_seconds': 0,
    'max_track_duration_seconds': MAX_TRACK_DURATION_SECONDS,
    'external_sync_delay_seconds': 0,
    'cover_resolution': providers.DEFAULT_COVER_RESOLUTION,
    'download_cover_art': True,
    'overwrite_existing_files': True,
    'organize_by_artist': True,
    'organize_by_album': True,
    'search_albums': True,
    'mini_player_enabled': True,
    # The language the web UI is shown in (``en``, ``pt-BR``...). The choice
    # lives in the browser, so the page tells the server (see
    # ``model/settings.js``): work that runs without a browser, like an
    # artist's bio fetched after a download, needs it. ``''`` until a page
    # has said - then there is no language to fetch in.
    'ui_language': '',
    # Soulseek via slskd, used when 'slskd' is in audio_providers.
    'slskd': {
        'enabled': False,
        'base_url': '',
        'api_key': '',
        'download_dir': '/downloads',
        'source_dir': '/slskd',
        'leave_in_place': True,
        'timeout_seconds': 20,
        'search_retries': 5,
        'search_poll_seconds': 15,
        'download_attempts': 5,
        'poll_interval_seconds': 5,
        'poll_max_attempts': 60,
        'download_timeout_seconds': 600,
        'queued_timeout_seconds': 180,
        'duration_tolerance_seconds': 10,
        'duration_tolerance_percent': 15,
        'mix_duration_tolerance_percent': 50,
        'extensions': ['mp3', 'flac'],
        'min_bitrate': 256,
    },
    # Usenet via Newznab indexers + SABnzbd, used when 'usenet' is in
    # audio_providers.
    'usenet': {
        'enabled': False,
        'indexers': [],
        'sabnzbd': {
            'base_url': '',
            'api_key': '',
            'category': 'music',
            'complete_dir': '/usenet',
        },
        'timeout_seconds': 20,
        'download_timeout_seconds': 900,
        'poll_interval_seconds': 5,
        'poll_max_attempts': 180,
        'duration_tolerance_seconds': 10,
        'duration_tolerance_percent': 15,
        'extensions': ['flac', 'mp3'],
        'min_bitrate': 0,
        'max_bitrate': 0,
        'prefer_albums': False,
        'min_score': 5,
        'cleanup': True,
    },
    # Navidrome (Subsonic API) playlist sync after playlist downloads.
    'sync_navidrome': True,
    'navidrome': {
        'enabled': False,
        'url': '',
        'username': '',
        'password': '',
        'admin_username': '',
        'admin_password': '',
        'public_playlist': False,
        'scan_after_download': True,
        'scan_full': False,
        'scan_wait_seconds': 120,
        'scan_poll_seconds': 5,
        'scan_retry_seconds': 15,
        'client_name': 'Downtify',
        'api_version': '1.16.1',
    },
    # Folders of already-tagged audio to include in the library (in
    # place). Synced from Settings → Library; see
    # ``downtify.external_library``.
    'external_library': {
        'folders': [],
    },
    # Keep extracted cover art under /data/cover_cache for faster Library
    # and Player loads.
    'cache_cover_art': False,
    # Defaults the Library upgrade scan starts from (see
    # downtify.library_upgrade); a scan request may override them.
    'library_upgrade': {
        'artwork_min_px': library_upgrade.DEFAULT_ARTWORK_MIN_PX,
        'artwork_source': cover_sources.PREFERENCE_HIGHEST,
        'recheck_days': library_upgrade.DEFAULT_RECHECK_DAYS,
        'metadata_mode': library_upgrade.DEFAULT_METADATA_MODE,
    },
    # Personal access token for the tag editor's Discogs search. MusicBrainz
    # needs none; Discogs' database search does.
    'discogs_token': '',
}

# Settings stored as nested objects: saved values are merged over the
# defaults key by key, so a settings.json from an older version still gets
# every newer option.
_NESTED_SETTINGS = (
    'slskd',
    'usenet',
    'navidrome',
    'library_upgrade',
    'external_library',
)


def _clamp_parallel_downloads(value: Any) -> int:
    """Coerce and clamp a requested parallel-download count.

    Keeps the setting inside ``[MIN_PARALLEL_DOWNLOADS,
    MAX_PARALLEL_DOWNLOADS]`` regardless of what the client sends, so a
    malformed or malicious payload can't spin up an unbounded number of
    concurrent yt-dlp/ffmpeg processes.
    """
    try:
        count = int(value)
    except (TypeError, ValueError):
        count = DEFAULT_SETTINGS['max_parallel_downloads']
    return min(MAX_PARALLEL_DOWNLOADS, max(MIN_PARALLEL_DOWNLOADS, count))


def _clamp_download_delay(value: Any) -> float:
    """Coerce and clamp the requested inter-download delay, in seconds.

    Keeps the setting inside ``[MIN_DOWNLOAD_DELAY_SECONDS,
    MAX_DOWNLOAD_DELAY_SECONDS]`` regardless of what the client sends,
    so a malformed or malicious payload can't freeze batch/monitor
    downloads for an unbounded amount of time.
    """
    try:
        delay = float(value)
    except (TypeError, ValueError):
        delay = DEFAULT_SETTINGS['download_delay_seconds']
    return min(
        MAX_DOWNLOAD_DELAY_SECONDS, max(MIN_DOWNLOAD_DELAY_SECONDS, delay)
    )


def _clamp_track_duration(value: Any) -> int:
    """Coerce and clamp the longest track taken, in seconds.

    ``0`` takes everything (mixes included); anything else lands inside
    ``[60, MAX_TRACK_DURATION_SETTING_SECONDS]``. Applies to downloads
    and streams alike (see :mod:`downtify.stream`).
    """

    try:
        seconds = int(value)
    except (TypeError, ValueError):
        return int(DEFAULT_SETTINGS['max_track_duration_seconds'])
    if seconds <= 0:
        return MIN_TRACK_DURATION_SETTING_SECONDS
    return min(MAX_TRACK_DURATION_SETTING_SECONDS, max(60, seconds))


def _max_track_duration_seconds() -> int:
    """The live duration bound (downloads and streams share it)."""

    return _clamp_track_duration(
        state.settings.get(
            'max_track_duration_seconds',
            DEFAULT_SETTINGS['max_track_duration_seconds'],
        )
    )


_UI_LANGUAGE_RE = re.compile(r'[a-z]{2}(-[A-Z]{2})?')


def _clean_ui_language(value: Any) -> str:
    """*value* when it is a language code of the shape the web UI uses
    (``en``, ``pt-BR``), else ``''``. It ends up in ``settings.json`` and in
    other services' requests, so nothing else is kept."""

    code = value.strip() if isinstance(value, str) else ''
    return code if _UI_LANGUAGE_RE.fullmatch(code) else ''


def _clamp_cover_resolution(value: Any) -> int:
    """Coerce and clamp the requested cover art target size, in pixels.

    Keeps the setting inside ``[MIN_COVER_RESOLUTION,
    MAX_COVER_RESOLUTION]``. Affects YouTube Music-sourced cover art
    (see ``providers.set_cover_resolution``, which resizes a thumbnail
    URL directly) and Deezer-sourced cover art (see
    ``deezer._cover_from_images``, which instead picks the smallest of
    Deezer's four fixed image sizes that still meets it, reading this
    same value via ``providers.cover_resolution``). Spotify-sourced
    covers are unaffected: Downtify already uses the largest size
    Spotify's embed API offers, with no equivalent to resize or pick
    from.
    """
    try:
        px = int(value)
    except (TypeError, ValueError):
        px = DEFAULT_SETTINGS['cover_resolution']
    return min(MAX_COVER_RESOLUTION, max(MIN_COVER_RESOLUTION, px))


def _setting_int(
    data: dict[str, Any],
    key: str,
    default: int,
    *,
    minimum: int,
    maximum: int,
) -> int:
    try:
        value = int(data.get(key) or default)
    except (TypeError, ValueError):
        value = default
    return min(maximum, max(minimum, value))


def _slskd_extensions(raw: dict[str, Any]) -> list[str]:
    value = raw.get('extensions')
    if isinstance(value, str):
        value = value.split(',')
    if not isinstance(value, list):
        value = []
    extensions = [
        str(e).strip().lower().lstrip('.') for e in value if str(e).strip()
    ]
    return extensions or ['mp3', 'flac']


def _effective_slskd_settings(settings: dict[str, Any]) -> dict[str, Any]:
    """Normalized slskd settings (URLs trimmed, numbers clamped).

    ``source_dir`` defaults to ``/slskd`` when files are left in place and
    to the download folder otherwise. The parallel-download limit is taken
    from the global setting, capped at 8 for slskd.
    """

    raw = settings.get('slskd')
    if not isinstance(raw, dict):
        raw = {}
    download_dir = str(raw.get('download_dir') or '/downloads').strip()
    leave_in_place = raw.get('leave_in_place')
    leave_in_place = True if leave_in_place is None else bool(leave_in_place)
    source_dir = str(raw.get('source_dir') or '').strip() or (
        '/slskd' if leave_in_place else download_dir
    )
    try:
        min_bitrate = int(raw.get('min_bitrate') or 256)
    except (TypeError, ValueError):
        min_bitrate = 256

    def bounded(key: str, default: int, low: int, high: int) -> int:
        return _setting_int(raw, key, default, minimum=low, maximum=high)

    return {
        'enabled': bool(raw.get('enabled', False)),
        'base_url': str(raw.get('base_url') or '').strip().rstrip('/'),
        'api_key': str(raw.get('api_key') or '').strip(),
        'download_dir': download_dir,
        'source_dir': source_dir,
        'leave_in_place': leave_in_place,
        'extensions': _slskd_extensions(raw),
        'timeout_seconds': bounded('timeout_seconds', 20, 5, 120),
        'search_retries': bounded('search_retries', 5, 1, 20),
        'search_poll_seconds': bounded('search_poll_seconds', 15, 3, 60),
        'download_attempts': bounded('download_attempts', 5, 1, 10),
        'poll_interval_seconds': bounded('poll_interval_seconds', 5, 1, 30),
        'poll_max_attempts': bounded('poll_max_attempts', 60, 1, 300),
        'download_timeout_seconds': bounded(
            'download_timeout_seconds', 600, 30, 3600
        ),
        'queued_timeout_seconds': bounded(
            'queued_timeout_seconds', 180, 15, 3600
        ),
        'duration_tolerance_seconds': bounded(
            'duration_tolerance_seconds', 10, 1, 120
        ),
        'duration_tolerance_percent': bounded(
            'duration_tolerance_percent', 15, 1, 100
        ),
        'mix_duration_tolerance_percent': bounded(
            'mix_duration_tolerance_percent', 50, 1, 200
        ),
        'min_bitrate': min_bitrate,
        'max_parallel_downloads': _setting_int(
            settings, 'max_parallel_downloads', 3, minimum=1, maximum=8
        ),
    }


def _usenet_extensions(raw: dict[str, Any]) -> list[str]:
    value = raw.get('extensions')
    if isinstance(value, str):
        value = value.split(',')
    if not isinstance(value, list):
        value = []
    extensions = [
        str(e).strip().lower().lstrip('.') for e in value if str(e).strip()
    ]
    return extensions or ['flac', 'mp3']


def _effective_usenet_settings(settings: dict[str, Any]) -> dict[str, Any]:
    """Normalized usenet settings (URLs trimmed, numbers clamped).

    Indexers are normalized one by one; the SABnzbd connection lives in the
    ``sabnzbd`` sub-dict. The parallel-download limit is taken from the
    global setting, capped at 8 for usenet.
    """

    raw = settings.get('usenet')
    if not isinstance(raw, dict):
        raw = {}

    def bounded(key: str, default: int, low: int, high: int) -> int:
        return _setting_int(raw, key, default, minimum=low, maximum=high)

    indexers: list[dict[str, Any]] = []
    raw_indexers = raw.get('indexers')
    for row in raw_indexers if isinstance(raw_indexers, list) else []:
        if not isinstance(row, dict):
            continue
        indexers.append({
            'name': str(row.get('name') or '').strip(),
            'base_url': str(row.get('base_url') or '').strip().rstrip('/'),
            'api_key': str(row.get('api_key') or '').strip(),
            'type': (
                'prowlarr'
                if str(row.get('type') or '').strip().lower() == 'prowlarr'
                else 'newznab'
            ),
            'enabled': bool(row.get('enabled', True)),
        })

    sab = raw.get('sabnzbd')
    sab = sab if isinstance(sab, dict) else {}
    sabnzbd = {
        'base_url': str(sab.get('base_url') or '').strip().rstrip('/'),
        'api_key': str(sab.get('api_key') or '').strip(),
        'category': str(sab.get('category') or 'music').strip() or 'music',
        'complete_dir': str(sab.get('complete_dir') or '/usenet').strip(),
    }

    return {
        'enabled': bool(raw.get('enabled', False)),
        'indexers': indexers,
        'sabnzbd': sabnzbd,
        'timeout_seconds': bounded('timeout_seconds', 20, 5, 120),
        'download_timeout_seconds': bounded(
            'download_timeout_seconds', 900, 30, 7200
        ),
        'poll_interval_seconds': bounded('poll_interval_seconds', 5, 1, 30),
        'poll_max_attempts': bounded('poll_max_attempts', 180, 1, 1000),
        'duration_tolerance_seconds': bounded(
            'duration_tolerance_seconds', 10, 1, 120
        ),
        'duration_tolerance_percent': bounded(
            'duration_tolerance_percent', 15, 1, 100
        ),
        'extensions': _usenet_extensions(raw),
        'min_bitrate': bounded('min_bitrate', 0, 0, 2000),
        'max_bitrate': bounded('max_bitrate', 0, 0, 4000),
        'prefer_albums': bool(raw.get('prefer_albums', False)),
        'min_score': bounded('min_score', 5, 0, 100),
        'cleanup': bool(raw.get('cleanup', True)),
        'max_parallel_downloads': _setting_int(
            settings, 'max_parallel_downloads', 3, minimum=1, maximum=8
        ),
    }


def _effective_audio_providers(settings: dict[str, Any]) -> list[str]:
    """Enabled audio providers in the configured order.

    slskd and usenet are dropped while their integration is disabled. The
    user's selection is respected as-is: a source the UI shows as disabled
    must not be appended at runtime either.
    """

    slskd_enabled = bool(_effective_slskd_settings(settings).get('enabled'))
    usenet_enabled = bool(_effective_usenet_settings(settings).get('enabled'))
    out: list[str] = []
    for raw in settings.get('audio_providers') or []:
        name = str(raw or '').strip()
        if name == 'slskd' and not slskd_enabled:
            continue
        if name == 'usenet' and not usenet_enabled:
            continue
        if name in AUDIO_PROVIDERS and name not in out:
            out.append(name)
    return out or ['youtube-music']


def _stored_audio_providers(settings: dict[str, Any]) -> list[str]:
    """The user's audio-source selection for persistence.

    Validated and deduplicated, but unlike
    :func:`_effective_audio_providers` it neither drops sources whose
    integration is currently disabled (they come back when it is enabled
    again) nor appends anything — saving must not edit what the user
    picked.
    """

    out: list[str] = []
    for raw in settings.get('audio_providers') or []:
        name = str(raw or '').strip()
        if name in AUDIO_PROVIDERS and name not in out:
            out.append(name)
    return out


def _validate_integration_settings(
    slskd: dict[str, Any],
    navidrome: dict[str, Any],
    usenet: Optional[dict[str, Any]] = None,
) -> None:
    """Reject enabling slskd/Navidrome/usenet without the fields they need."""

    if slskd.get('enabled'):
        if not slskd.get('base_url'):
            raise HTTPException(
                status_code=400,
                detail='slskd base URL is required when enabled',
            )
        if not slskd.get('api_key'):
            raise HTTPException(
                status_code=400,
                detail='slskd API key is required when enabled',
            )
    if navidrome.get('enabled'):
        for key, label in (
            ('url', 'URL'),
            ('username', 'username'),
            ('password', 'password'),
        ):
            if not navidrome.get(key):
                raise HTTPException(
                    status_code=400,
                    detail=f'Navidrome {label} is required when enabled',
                )
    usenet = usenet if isinstance(usenet, dict) else {}
    if usenet.get('enabled'):
        sab = usenet.get('sabnzbd')
        sab = sab if isinstance(sab, dict) else {}
        if not sab.get('base_url'):
            raise HTTPException(
                status_code=400,
                detail='SABnzbd base URL is required when usenet is enabled',
            )
        if not sab.get('api_key'):
            raise HTTPException(
                status_code=400,
                detail='SABnzbd API key is required when usenet is enabled',
            )
        indexers = usenet.get('indexers')
        usable = [
            row
            for row in (indexers if isinstance(indexers, list) else [])
            if isinstance(row, dict)
            and row.get('enabled')
            and row.get('base_url')
            and row.get('api_key')
        ]
        if not usable:
            raise HTTPException(
                status_code=400,
                detail='At least one enabled indexer with base URL and API '
                'key is required when usenet is enabled',
            )


def _organize_enabled() -> bool:
    """True when tracks are routed into per-artist/per-album folders.

    In that case per-playlist folders are bypassed, so the M3U must be
    written to the legacy ``Playlists/`` directory where its relative
    track paths still resolve.
    """

    d = state.downloader
    return bool(d and (d.organize_by_artist or d.organize_by_album))


def _effective_lyrics_providers(settings: dict[str, Any]) -> list[str]:
    """The lyrics providers to try, in order."""

    return lyrics.providers_from_settings(settings)


class ConnectionManager:
    """Tracks the active WebSocket clients keyed by ``client_id``."""

    def __init__(self) -> None:
        self._clients: dict[str, WebSocket] = {}
        # client_id -> the paired device it belongs to, if any, so a
        # revoked device's socket can be closed at once.
        self._devices: dict[str, str] = {}
        # client_id -> the signed-in user, so a user signed out
        # everywhere (or deleted) is disconnected too.
        self._users: dict[str, int] = {}
        # Sockets that see every download job event (admins).
        self._admins: set[str] = set()

    async def connect(
        self,
        client_id: str,
        ws: WebSocket,
        device_id: str = '',
        user_id: int = 0,
        is_admin: bool = False,
    ) -> None:
        await ws.accept()
        self._clients[client_id] = ws
        if device_id:
            self._devices[client_id] = device_id
        else:
            self._devices.pop(client_id, None)
        if user_id:
            self._users[client_id] = user_id
        else:
            self._users.pop(client_id, None)
        if is_admin:
            self._admins.add(client_id)
        else:
            self._admins.discard(client_id)

    def disconnect(self, client_id: str) -> None:
        self._clients.pop(client_id, None)
        self._devices.pop(client_id, None)
        self._users.pop(client_id, None)
        self._admins.discard(client_id)

    async def send_user(self, user_id: int, message: dict[str, Any]) -> None:
        """Send *message* to every socket of *user_id*."""

        for cid in [c for c, uid in self._users.items() if uid == user_id]:
            await self.send(cid, message)

    async def close_user(self, user_id: int) -> None:
        """Close every socket of *user_id*, browsers and apps (``4401``)."""

        doomed = [cid for cid, uid in self._users.items() if uid == user_id]
        sockets = [self._clients.pop(cid, None) for cid in doomed]
        for cid in doomed:
            self._users.pop(cid, None)
            self._devices.pop(cid, None)
        await asyncio.gather(
            *(ws.close(code=4401) for ws in sockets if ws is not None),
            return_exceptions=True,
        )

    async def close_device(self, device_id: str = '') -> None:
        """Close the sockets of *device_id* - every paired device's when
        it's empty (``4401``: signed out)."""

        doomed = [
            cid
            for cid, dev in self._devices.items()
            if dev and (not device_id or dev == device_id)
        ]
        sockets = [self._clients.pop(cid, None) for cid in doomed]
        for cid in doomed:
            self._devices.pop(cid, None)
        await asyncio.gather(
            *(ws.close(code=4401) for ws in sockets if ws is not None),
            return_exceptions=True,
        )

    async def send(self, client_id: str, message: dict[str, Any]) -> None:
        ws = self._clients.get(client_id)
        if ws is None:
            return
        try:
            await ws.send_text(json.dumps(message))
        except Exception:
            self._clients.pop(client_id, None)

    async def broadcast_job(
        self, user_ids: Collection[int], message: dict[str, Any]
    ) -> None:
        """A download job event: its waiters and the admins, nobody else.

        The titles in job events would otherwise tell every connected
        client what someone else is downloading (``GET /api/queue`` is
        filtered the same way). Ownerless jobs keep the old broadcast.
        """

        targets_set = {int(uid) for uid in user_ids if uid}
        if not targets_set:
            await self.broadcast(message)
            return
        targets = [
            cid for cid, uid in self._users.items() if uid in targets_set
        ]
        targets += [cid for cid in self._admins if cid not in targets]
        for client_id in targets:
            await self.send(client_id, message)

    async def broadcast(self, message: dict[str, Any]) -> None:
        # Serialized once, sent to every client concurrently: one slow
        # client (a phone on a weak connection) no longer delays the rest.
        clients = list(self._clients.items())
        if not clients:
            return
        text = json.dumps(message)
        results = await asyncio.gather(
            *(ws.send_text(text) for _, ws in clients),
            return_exceptions=True,
        )
        for (client_id, ws), result in zip(clients, results):
            # Only drop that exact socket: the client may have reconnected
            # under the same id while the sends were in flight.
            if isinstance(result, Exception) and (
                self._clients.get(client_id) is ws
            ):
                self._clients.pop(client_id, None)

    async def close_all(self, code: int = 1012) -> None:
        """Close every tracked socket (``1012`` = service restart).

        Cleared before awaiting so a concurrent reconnect cannot land in
        the map we are tearing down. Safe if uvicorn already closed the
        transport.
        """
        clients = list(self._clients.items())
        self._clients.clear()
        self._devices.clear()
        self._admins.clear()
        if not clients:
            return
        await asyncio.gather(
            *(ws.close(code=code) for _, ws in clients),
            return_exceptions=True,
        )


class AppState:
    version: str = '0.0.0'
    downloader: Optional[Downloader] = None
    connections: ConnectionManager = ConnectionManager()
    settings: dict[str, Any] = dict(DEFAULT_SETTINGS)
    settings_path: Optional[Path] = None
    cookies_store: Optional[CookiesStore] = None
    update_checker: Optional[UpdateChecker] = None
    loop: Optional[asyncio.AbstractEventLoop] = None
    monitor_db: Optional[PlaylistMonitorDB] = None
    download_jobs: dict[str, dict[str, Any]] = {}
    download_semaphore: Optional[asyncio.Semaphore] = None
    # Fire-and-forget work owned by the process (import batches, monitor
    # loops, playlist refresh). Cancelled in :func:`shutdown_resources`.
    background_tasks: set[asyncio.Task[Any]] = set()
    # Library stores in /data/downtify_library.db (opened at startup).
    track_index: Optional[TrackIndex] = None
    navidrome_index: Optional[NavidromeIndex] = None
    metadata_cache: Optional[LibraryMetadataCache] = None
    cover_cache: Optional[CoverArtCache] = None
    playlist_catalog: Optional[PlaylistCatalog] = None
    playlist_batch_store: Optional[PlaylistBatchStore] = None
    playlist_spotify_cache: Optional[PlaylistSpotifyCache] = None
    lyrics_cache: Optional[LyricsLookupCache] = None
    upgrade_runner: Optional[library_upgrade.LibraryUpgradeRunner] = None
    external_sync: Optional[ExternalSyncJob] = None
    likes: Optional[LikedTracks] = None
    track_owners: Optional[TrackOwners] = None
    manual_playlist_owners: Optional[ManualPlaylistOwners] = None
    traffic: Optional[TrafficCounters] = None
    podcasts: Optional[PodcastStore] = None
    discover: Optional[DiscoverStore] = None
    # Sign-in and paired apps (see downtify/auth.py and auth_routes.py).
    auth: Optional[AuthStore] = None
    pairing: PairingStore = PairingStore()
    ws_tickets: TicketStore = TicketStore()
    login_limiter: RateLimiter = RateLimiter()
    pair_limiter: RateLimiter = RateLimiter()
    identity: Optional[ServerIdentity] = None
    # {host, port, source}: where the server listens and what chose the
    # port (downtify/server_port.py).
    listen: dict[str, Any] = {}
    # What users do (downtify/activity.py), for admins.
    activity: Optional[ActivityLog] = None
    now_playing: NowPlaying = NowPlaying()
    # The mobile API (downtify/mobile_routes.py).
    library_sync: Optional[LibrarySync] = None
    transcoder: Optional[Transcoder] = None
    stream_cache: Optional[StreamCache] = None
    cover_thumbs: Optional[CoverThumbs] = None
    discovery: Any = None


state = AppState()
router = APIRouter()
_shutdown_done = False


def spawn_task(coro: Any, *, name: Optional[str] = None) -> asyncio.Task[Any]:
    """Create a task and track it for :func:`shutdown_resources`."""
    task = asyncio.create_task(coro, name=name)
    state.background_tasks.add(task)
    task.add_done_callback(state.background_tasks.discard)
    return task


# ---------------------------------------------------------------------------
# Who is asking (see downtify/auth.py) and the activity log
# ---------------------------------------------------------------------------

_TRUSTED_PROXIES = trusted_proxies_from_env()


def principal_of(request: Request) -> Optional[Principal]:
    """Who made *request* (set by the auth middleware), if anyone."""

    return (request.scope.get('state') or {}).get('principal')


def request_user_id(request: Optional[Request]) -> int:
    """The signed-in user behind *request* (``0`` when there is none)."""

    if request is None:
        return 0
    principal = principal_of(request)
    return int(getattr(principal, 'user_id', 0) or 0)


def request_is_admin(request: Optional[Request]) -> bool:
    """Whether *request* was made by an admin (sees every track)."""

    if request is None:
        return False
    principal = principal_of(request)
    return bool(principal is not None and principal.is_admin)


def allowed_entry_keys(request: Optional[Request]) -> Optional[set[str]]:
    """Content keys *request* may browse (``None``: everything).

    Admins see the whole library, including files nobody owns (monitor
    sweeps, reconciled drops, pre-feature downloads). Anyone else sees
    only files they asked to download.
    """

    if request_is_admin(request) or state.track_owners is None:
        return None
    user_id = request_user_id(request)
    if not user_id:
        return set()
    return state.track_owners.owned_keys(user_id)


def _playlist_owner_maps() -> tuple[dict[str, int], dict[str, int]]:
    """``({casefolded catalog name: user_id}, {manual name: user_id})``."""

    catalog_names: dict[str, int] = {}
    manual: dict[str, int] = {}
    try:
        catalog = state.playlist_catalog
        if catalog is not None:
            catalog_names = {
                str(name or '').strip().casefold(): int(uid or 0)
                for name, uid in catalog.playlist_owner_map().items()
            }
        owned = state.manual_playlist_owners
        if owned is not None:
            manual = dict(owned.owner_map())
    except Exception:
        logger.opt(exception=True).debug('Could not read playlist owners')
    return catalog_names, manual


def _playlist_visible(
    name: str, *, liked: bool, manual: bool, user_id: int
) -> bool:
    """Whether *user_id* may open a playlist (admins bypass this)."""

    if liked or not user_id:
        return False
    catalog_names, manual_owners = _playlist_owner_maps()
    key = str(name or '').strip().casefold()
    if manual:
        return manual_owners.get(key) == user_id
    return catalog_names.get(key) == user_id


def _filter_playlists_for(
    playlists: list[dict[str, Any]], request: Optional[Request]
) -> list[dict[str, Any]]:
    """Playlists *request* may open, with a personal liked entry.

    Admins see everything as before. Anyone else sees playlists they
    own (downloaded or Library-created); the shared liked-songs file
    is swapped for their own hearts (which live in the database only).
    """

    if request_is_admin(request):
        return playlists
    user_id = request_user_id(request)
    kept = [
        playlist
        for playlist in playlists
        if not playlist.get('liked')
        and _playlist_visible(
            str(playlist.get('name') or ''),
            liked=False,
            manual=bool(playlist.get('manual')),
            user_id=user_id,
        )
    ]
    if user_id and state.likes is not None:
        try:
            liked_files = state.likes.paths(user_id)
        except Exception:
            logger.opt(exception=True).debug(
                'Could not read likes for playlist listing'
            )
            liked_files = []
        if liked_files:
            kept.append({
                'name': LIKED_PLAYLIST_NAME,
                'files': liked_files,
                'count': len(liked_files),
                'added': 0,
                'cover': '',
                'liked': True,
                'manual': False,
            })
    kept.sort(
        key=lambda item: (
            not item.get('liked'),
            str(item.get('name') or '').casefold(),
        )
    )
    return kept


def _filter_entries_for(
    entries: list[dict[str, Any]], request: Optional[Request]
) -> list[dict[str, Any]]:
    """Library rows *request* may browse, with foreign playlists cut.

    A track can sit in playlists nobody else may open (someone else's
    download shares the file): those names are scrubbed from its row,
    so the row never reveals them. Rows are copied, never mutated - the
    snapshot they come from is shared.
    """

    allowed = allowed_entry_keys(request)
    if allowed is None:
        return entries
    user_id = request_user_id(request)
    catalog_names, manual_owners = _playlist_owner_maps()
    owned = {name for name, uid in catalog_names.items() if uid == user_id} | {
        key for key, uid in manual_owners.items() if uid == user_id
    }

    def _scrubbed(row: dict[str, Any], names: Any) -> dict[str, Any]:
        kept = [
            str(raw)
            for raw in names
            if is_liked_playlist(raw)
            or str(raw or '').strip().casefold() in owned
        ]
        return {**row, 'playlists': kept}

    filtered = []
    for entry in entries:
        if entry_content_key(entry) not in allowed:
            continue
        names = entry.get('playlists')
        filtered.append(_scrubbed(entry, names) if names else entry)
    return filtered


def entries_for_request(request: Optional[Request]) -> list[dict[str, Any]]:
    """``GET /tracks`` rows *request* may browse."""

    return _filter_entries_for(listing_for_request(library_context()), request)


def filter_paths_for_request(
    paths: list[str], request: Optional[Request]
) -> list[str]:
    """Library paths *request* may browse (``GET /list``), order kept."""

    allowed = allowed_entry_keys(request)
    if allowed is None:
        return list(paths)
    by_file = {}
    for entry in listing_for_request(library_context()):
        by_file[str(entry.get('file') or '').replace('\\', '/')] = (
            entry_content_key(entry)
        )
    return [
        path
        for path in paths
        if by_file.get(str(path or '').replace('\\', '/')) in allowed
    ]


def playlists_for_request(request: Optional[Request]) -> list[dict[str, Any]]:
    """Playlist listing entries *request* may open."""

    ctx = library_context()
    found = list_library_playlists(
        ctx.download_dir, ctx.slskd_dir, ctx.extra_dirs
    )
    return _filter_playlists_for(found, request)


def playlist_entry_for_request(
    name: str, request: Optional[Request]
) -> Optional[dict[str, Any]]:
    """The listing entry for *name* when *request* may open it.

    Falls back to the playlist catalog when the M3U is gone (a delete
    still has tracks to take): admins see every catalog entry, anyone
    else only entries they own.
    """

    wanted = str(name or '').strip()
    if not wanted:
        return None
    for playlist in playlists_for_request(request):
        if str(playlist.get('name') or '') == wanted:
            return playlist
    catalog = state.playlist_catalog
    if catalog is None:
        return None
    try:
        rows = catalog.list_tracks(wanted)
    except Exception:
        return None
    if not rows:
        return None
    if not request_is_admin(request):
        user_id = request_user_id(request)
        try:
            owner = catalog.playlist_owner_map().get(wanted)
        except Exception:
            logger.opt(exception=True).debug(
                'Could not read owner for playlist {!r}', wanted
            )
            owner = None
        if not user_id or int(owner or 0) != user_id:
            return None
    return {
        'name': wanted,
        'files': [str(row.get('filename') or '') for row in rows],
        'count': len(rows),
        'added': 0,
        'cover': '',
        'liked': False,
        'manual': False,
    }


def require_playlist_visible(name: str, request: Optional[Request]) -> None:
    """404 unless *request* may open the playlist (as if unknown)."""

    if playlist_entry_for_request(name, request) is None:
        raise HTTPException(status_code=404, detail='Playlist not found')


def claim_manual_playlist(name: str, request: Optional[Request]) -> None:
    """Record a Library-created playlist's owner (best effort)."""

    user_id = request_user_id(request)
    if not user_id or state.manual_playlist_owners is None:
        return
    try:
        state.manual_playlist_owners.set_owner(name, user_id)
    except Exception:
        logger.opt(exception=True).debug(
            'Could not record owner for playlist {!r}', name
        )


def request_ip(request: Request) -> str:
    return client_ip(request.scope, _TRUSTED_PROXIES)


def client_label(request: Request, principal: Optional[Principal]) -> str:
    """What a request came from, for the activity log: a paired app's
    name, or ``Web (Firefox on Linux)``."""

    if principal is not None and principal.device_id and state.auth:
        device = state.auth.get_device(principal.device_id) or {}
        return str(device.get('name') or 'App')
    browser = describe_user_agent(request.headers.get('user-agent', ''))
    return f'Web ({browser})' if browser else 'Web'


def user_preferences(request: Request) -> dict[str, Any]:
    """The signed-in user's own preferences (Settings > General)."""

    if state.auth is None:
        return {}
    principal = principal_of(request)
    if principal is None or not principal.user_id:
        return {}
    return state.auth.users.preferences(principal.user_id)


async def log_activity(
    request: Request,
    kind: str,
    summary: str = '',
    detail: Optional[dict[str, Any]] = None,
) -> None:
    """Add what *request*'s user did to the activity log. Never fails the
    request it's called from."""

    log = state.activity
    if log is None:
        return
    principal = principal_of(request)
    try:
        label = await asyncio.to_thread(client_label, request, principal)
        await asyncio.to_thread(
            log.record,
            kind,
            user_id=principal.user_id if principal else 0,
            username=principal.username if principal else '',
            summary=summary,
            detail=detail,
            client=label,
            ip=request_ip(request),
        )
    except Exception:
        logger.exception('Activity log: could not record {}', kind)


def song_label(song: dict[str, Any]) -> str:
    """``Artist - Title`` for a song as the download endpoints get it."""

    artists = song.get('artists') or []
    artist = (
        ', '.join(str(a) for a in artists)
        if isinstance(artists, list)
        else str(artists)
    )
    title = str(song.get('name') or song.get('title') or '')
    return ' - '.join(part for part in (artist, title) if part)


_SHUTDOWN_TASK_TIMEOUT_SECONDS = 1.0


def _skip_threadpool_join() -> None:
    """Stop CPython from joining every ThreadPoolExecutor on exit.

    Python 3.9+ registers ``concurrent.futures.thread._python_exit`` with
    ``threading._register_atexit``, not ``atexit``. That hook ``join()``s
    every worker still in ``_threads_queues`` — download, metadata, and
    ``asyncio.to_thread`` pools. Setting ``daemon=True`` does not skip it.
    A second Ctrl+C during shutdown was interrupting that join.
    """
    try:
        threading._threading_atexits.clear()
    except Exception:
        pass
    try:
        for thread in list(getattr(cf_thread, '_threads_queues', {})):
            try:
                thread.daemon = True
            except Exception:
                pass
    except Exception:
        pass
    for thread in threading.enumerate():
        if thread is threading.main_thread():
            continue
        try:
            thread.daemon = True
        except Exception:
            pass


def release_thread_pools() -> None:
    """Stop accepting pool work and do not join in-flight workers."""
    DOWNLOAD_EXECUTOR.shutdown(wait=False, cancel_futures=True)
    _skip_threadpool_join()


async def shutdown_resources() -> None:
    """Close WebSockets, cancel background work, release the download pool.

    Idempotent: lifespan and ``main``'s ``finally`` may both call this.
    """
    global _shutdown_done
    if _shutdown_done:
        return
    _shutdown_done = True

    logger.info('Downtify shutdown: closing WebSockets and background tasks')
    await state.connections.close_all()

    tasks = list(state.background_tasks)
    for task in tasks:
        task.cancel()
    if tasks:
        try:
            await asyncio.wait_for(
                asyncio.gather(*tasks, return_exceptions=True),
                timeout=_SHUTDOWN_TASK_TIMEOUT_SECONDS,
            )
        except asyncio.TimeoutError:
            still = sum(1 for task in tasks if not task.done())
            logger.warning(
                'Shutdown: {} background task(s) still running, continuing',
                still,
            )

    if state.upgrade_runner is not None:
        try:
            state.upgrade_runner.pause()
        except Exception:
            logger.exception('Library upgrade: could not pause on shutdown')

    try:
        loop = asyncio.get_running_loop()
        await asyncio.wait_for(
            loop.shutdown_default_executor(),
            timeout=_SHUTDOWN_TASK_TIMEOUT_SECONDS,
        )
    except Exception:
        pass

    release_thread_pools()
    logger.info('Downtify shutdown: complete')


def library_context() -> LibraryContext:
    """Where library files live (downloads + slskd folder) and the
    stores that describe them."""

    download_dir = (
        Path(state.downloader.download_dir)
        if state.downloader is not None
        else Path('/downloads')
    )
    return library_context_from_state(
        download_dir,
        state.settings,
        state.track_index,
        metadata_cache=state.metadata_cache,
        playlist_catalog=state.playlist_catalog,
    )


def library_stores() -> LibraryStores:
    """The library stores Playlist Monitor sweeps keep up to date."""

    return LibraryStores(
        track_index=state.track_index,
        playlist_catalog=state.playlist_catalog,
        navidrome_index=state.navidrome_index,
        metadata_cache=state.metadata_cache,
        cover_cache=state.cover_cache,
        playlist_spotify_cache=state.playlist_spotify_cache,
        track_owners=state.track_owners,
    )


def stored_content_key(stored_path: str) -> str:
    """The ownership key of a library path (``''`` when not on disk)."""

    try:
        full = resolve_library_file(stored_path, library_context())
    except Exception:
        return ''
    if full is None:
        return ''
    try:
        return content_key_for(full) or ''
    except Exception:
        return ''


def ownership_action(
    stored_path: str, request: Optional[Request]
) -> tuple[str, str]:
    """How a delete treats one file: ``(action, content_key)``.

    ``delete`` takes it off disk (an admin, or the last owner -
    today's behavior when nobody else has it). ``release`` drops
    one's own ownership row while the file stays for the rest.
    ``missing`` isn't on disk; ``foreign`` isn't theirs.
    """

    key = stored_content_key(stored_path)
    if not key:
        return 'missing', ''
    if state.track_owners is None:
        return 'delete', key
    if request_is_admin(request):
        return 'delete', key
    user_id = request_user_id(request)
    try:
        owners = state.track_owners.owners(key)
    except Exception:
        logger.opt(exception=True).debug(
            'Could not read owners for {}', stored_path
        )
        owners = []
    if user_id and user_id in owners:
        return ('delete' if len(owners) == 1 else 'release'), key
    return 'foreign', key


def release_file_ownership(
    stored_path: str, content_key: str, user_id: int
) -> dict[str, Any]:
    """Drop one owner's row after their delete; the file stays put."""

    if state.track_owners is not None and content_key and user_id:
        try:
            state.track_owners.remove(content_key, user_id)
        except Exception:
            logger.opt(exception=True).warning(
                'Could not release {} for user {}', stored_path, user_id
            )
    if state.library_sync is not None:
        try:
            name = str(stored_path or '').strip().replace('\\', '/')
            state.library_sync.touch(name)
        except Exception:
            logger.opt(exception=True).debug(
                'Could not poke the sync feed for {}', stored_path
            )
    announce_library_changed()
    return {'released': True}


def _record_download_traffic(filename: str, user_id: int) -> None:
    """Count a finished download's bytes as the downloader's upstream."""

    if not user_id or state.traffic is None or state.downloader is None:
        return
    try:
        full = locate_library_file(
            filename,
            Path(state.downloader.download_dir),
            slskd_dir_from_downloader(state.downloader),
        )
        if full is None:
            return
        state.traffic.add(user_id, DIRECTION_IN, full.stat().st_size)
    except Exception:
        logger.opt(exception=True).debug(
            'Could not record download traffic for {}', filename
        )


def record_stream_fetch_traffic(video_path: Path, user_id: int) -> None:
    """Count a stream-cache fetch's bytes as upstream (it served no one
    yet - the serve itself is counted on the way out)."""

    if not user_id or state.traffic is None:
        return
    try:
        state.traffic.add(user_id, DIRECTION_IN, video_path.stat().st_size)
    except Exception:
        logger.opt(exception=True).debug(
            'Could not record stream traffic for {}', video_path
        )


def rekey_file_owners(
    old_key: str, new_key: str, stored_path: str = ''
) -> None:
    """Point ownership rows at a rewritten file (best effort)."""

    if state.track_owners is None:
        return
    try:
        state.track_owners.rekey(old_key, new_key, stored_path)
    except Exception:
        logger.opt(exception=True).debug(
            'Could not rekey owners for {}', stored_path
        )


def drop_file_owners(content_key: str) -> None:
    """Forget every owner (their file was just deleted from disk)."""

    if state.track_owners is None or not content_key:
        return
    try:
        state.track_owners.drop_file(content_key)
    except Exception:
        logger.opt(exception=True).warning(
            'Could not drop owners for a deleted file'
        )


#: Who pre-feature files belong to on the first start with ownership.
MIGRATION_USERNAME = 'brillik'


def resolve_migration_user_id() -> int:
    """Who files without owners belong to: ``brillik`` when that account
    exists, else the oldest admin, else ``0`` (nobody - try again next
    start)."""

    users = state.auth.users if state.auth is not None else None
    if users is None:
        return 0
    try:
        found = users.by_username(MIGRATION_USERNAME)
        if found is not None:
            return int(found['id'])
        first = users.first_admin()
        return int(first['id']) if first is not None else 0
    except Exception:
        logger.opt(exception=True).debug(
            'Could not resolve the migration user'
        )
        return 0


def migrate_first_run_ownership() -> dict[str, int]:
    """Attribute every ownerless thing, once.

    Runs on start while the ownership table is still empty (a fresh
    install has no files yet, so this is a no-op there): every library
    file becomes the migration user's, and pre-feature likes,
    playlists, batches, podcast shows and progress, monitor watches and
    discover history take the same owner. Later arrivals record their
    real downloader instead. Returns what was attributed.
    """

    done = {
        'files': 0,
        'likes': 0,
        'playlists': 0,
        'batches': 0,
        'podcasts': 0,
        'watches': 0,
        'listens': 0,
    }
    owners = state.track_owners
    if owners is None or not owners.is_empty():
        return done
    user_id = resolve_migration_user_id()
    if not user_id:
        logger.warning(
            'Ownership backfill: no users yet, will retry on next start'
        )
        return done
    try:
        paths = list_library_paths(library_context())
    except Exception:
        logger.opt(exception=True).warning(
            'Ownership backfill: could not list the library'
        )
        return done
    claimed = 0
    for stored in paths:
        try:
            key = stored_content_key(stored)
        except Exception:
            continue
        name = str(stored or '').strip().replace('\\', '/')
        if key and owners.add(key, user_id, name):
            claimed += 1
    done['files'] = claimed

    def _migrate(label: str, store: Any, method: str) -> None:
        if store is None:
            return
        try:
            done[label] = getattr(store, method)(user_id)
        except Exception:
            logger.opt(exception=True).warning(
                'Ownership backfill: could not migrate {}', label
            )

    _migrate('likes', state.likes, 'reassign_legacy')
    _migrate('playlists', state.playlist_catalog, 'reassign_legacy')
    _migrate('batches', state.playlist_batch_store, 'reassign_legacy')
    _migrate('podcasts', state.podcasts, 'reassign_legacy')
    _migrate('watches', state.monitor_db, 'reassign_legacy')
    _migrate('listens', state.discover, 'reassign_legacy')
    if any(done.values()):
        logger.info(
            'Ownership backfill: {} file(s), {} like(s), {} playlist(s), '
            '{} batch(es), {} podcast row(s), {} watch(es), {} listen row(s)'
            ' now belong to user {}',
            done['files'],
            done['likes'],
            done['playlists'],
            done['batches'],
            done['podcasts'],
            done['watches'],
            done['listens'],
            user_id,
        )
        if state.library_sync is not None:
            try:
                state.library_sync.touch_all()
            except Exception:
                logger.opt(exception=True).debug(
                    'Ownership backfill: could not poke the sync feed'
                )
    return done


def forget_library_file(stored_path: str) -> list[str]:
    """Drop a deleted file from the library stores.

    Removes it from the track index, playlist catalog, Navidrome song-id
    index and the metadata/cover caches, all keyed by its library path
    (the file itself is already gone). Returns the playlists it belonged
    to.
    """

    name = str(stored_path or '').strip().replace('\\', '/')
    if not name:
        return []
    affected: list[str] = []
    if state.playlist_catalog is not None:
        affected = state.playlist_catalog.remove_tracks_for_filename(name)
    if state.track_index is not None:
        state.track_index.remove_by_filename(name)
    if state.navidrome_index is not None:
        state.navidrome_index.forget_filename(name)
    if state.metadata_cache is not None:
        state.metadata_cache.forget(name)
    if state.cover_cache is not None:
        state.cover_cache.forget_by_stored_path(name)
    if state.likes is not None:
        state.likes.unlike(name)
    return affected


async def after_library_delete(
    results: dict[str, dict[str, Any]],
    response: dict[str, Any],
    user_id: int = 0,
) -> dict[str, Any]:
    """Update the library stores after ``DELETE /delete`` or
    ``/delete/batch`` and report affected playlists on ``response``.

    Wiped files leave every store (and everybody's likes); released
    ones only drop *user_id*'s like — the file and everyone else's
    hearts stay.
    """

    deleted = [f for f, r in results.items() if r.get('deleted')]
    released = [f for f, r in results.items() if r.get('released')]
    affected: set[str] = set()
    if deleted or (released and user_id):

        def _forget() -> None:
            liked_before = state.likes.count() if state.likes else 0
            for name in deleted:
                affected.update(forget_library_file(name))
            if state.likes is not None and user_id:
                for name in released:
                    state.likes.unlike(name, user_id)
            if deleted:
                # The rows are gone from disk: the RAM snapshot must
                # stop claiming them, or the search "already
                # downloaded" badge keeps a deleted track downloaded.
                drop_library_listing_files(library_context(), deleted)
                invalidate_library_paths_cache()
            if state.likes is not None and state.likes.count() != liked_before:
                # A deleted song can't stay liked, or on the playlist.
                _sync_liked_playlist()
                _announce_likes()

        await asyncio.to_thread(_forget)
    response['playlists_affected'] = sorted(affected)
    # The deleted tracks' playlists get their M3U/Navidrome playlist
    # rewritten in the background (can take minutes).
    response['playlists_refresh_scheduled'] = bool(affected)
    if affected:
        await _schedule_playlist_refresh_after_delete(affected)
    return response


def _fetch_playlist_tracks(
    spotify_playlist_id: str,
    *,
    refresh: bool = False,
) -> tuple[str, list[dict[str, Any]]]:
    return fetch_playlist_tracks(
        spotify_playlist_id,
        cache=state.playlist_spotify_cache,
        refresh=refresh,
    )


def _playlist_context_from_hints(
    hints: Optional[dict[str, Any]],
) -> dict[str, Any]:
    """Resolve optional playlist batch/retry context from client hints."""

    if not isinstance(hints, dict):
        return {}
    name = str(
        hints.get('downtify_playlist_name') or hints.get('playlist_name') or ''
    ).strip()
    playlist_url = str(
        hints.get('downtify_playlist_url') or hints.get('playlist_url') or ''
    ).strip()
    spotify_playlist_id = (
        str(
            hints.get('downtify_spotify_playlist_id')
            or hints.get('spotify_playlist_id')
            or ''
        ).strip()
        or None
    )
    order_raw = hints.get('downtify_track_order', hints.get('track_order', 0))
    try:
        track_order = int(order_raw)
    except (TypeError, ValueError):
        track_order = 0
    track_order = max(track_order, 0)

    if not name and playlist_url:
        parsed = spotify.parse_spotify_url(playlist_url)
        if parsed is not None and parsed[0] == 'playlist':
            spotify_playlist_id = spotify_playlist_id or parsed[1]
            try:
                name, _ = _fetch_playlist_tracks(parsed[1])
            except Exception:
                logger.opt(exception=True).warning(
                    'download: failed to resolve playlist name from url'
                )
                name = ''

    subdir: Optional[str] = None
    if name and state.downloader is not None and not _organize_enabled():
        subdir = m3u.sanitize_playlist_name(name)

    return {
        'playlist_name': name or None,
        'spotify_playlist_id': spotify_playlist_id,
        'track_order': track_order,
        'subdir': subdir,
    }


def _playlists_for_successful_download(
    song: dict[str, Any],
    *,
    primary_playlist: Optional[str] = None,
) -> set[str]:
    """Playlist names that should be refreshed after this track succeeds."""

    names: set[str] = set()
    primary = str(primary_playlist or '').strip()
    if primary:
        names.add(primary)
    tid = normalize_spotify_track_id(song)
    if not tid:
        return names
    if state.playlist_catalog is not None:
        names.update(state.playlist_catalog.playlists_for_track(tid))
    if state.monitor_db is not None:
        names.update(state.monitor_db.playlists_for_track(tid))
    return names


def _upsert_track_in_playlists(
    song: dict[str, Any],
    filename: str,
    playlist_names: set[str],
    *,
    primary_playlist: Optional[str] = None,
    primary_order: int = 0,
    spotify_playlist_id: Optional[str] = None,
    user_id: int = 0,
) -> None:
    """Register the file in the catalog for every affected playlist.

    Only the playlist the user actually downloaded (*primary_playlist*)
    is claimed for them; the other catalog playlists that happen to
    hold the track keep their owners.
    """

    if state.downloader is None or state.playlist_catalog is None:
        return
    if not playlist_names:
        return
    dl_dir = Path(state.downloader.download_dir)
    slskd = slskd_dir_from_downloader(state.downloader)
    full = locate_library_file(filename, dl_dir, slskd)
    if full is None:
        return
    catalog = state.playlist_catalog
    primary = str(primary_playlist or '').strip()
    for pl_name in sorted(playlist_names):
        sid = (
            spotify_playlist_id
            if pl_name == primary and spotify_playlist_id
            else catalog.spotify_id_for_playlist(pl_name)
        )
        catalog.ensure_playlist(
            pl_name,
            spotify_id=sid,
            user_id=user_id if pl_name == primary else None,
        )
        order = primary_order if pl_name == primary else 0
        catalog.upsert_track(pl_name, song, filename, full, track_order=order)


def _register_download_playlists_on_disk(
    song: dict[str, Any],
    filename: str,
    *,
    playlist_name: Optional[str] = None,
    spotify_playlist_id: Optional[str] = None,
    track_order: int = 0,
    user_id: int = 0,
) -> set[str]:
    """Update indexes, catalog, monitor paths; return playlists to refresh."""

    if state.downloader is None or not filename:
        return set()
    tid = normalize_spotify_track_id(song)
    if state.monitor_db is not None and tid:
        state.monitor_db.update_filename_for_spotify(tid, filename)

    affected = _playlists_for_successful_download(
        song, primary_playlist=playlist_name
    )
    _upsert_track_in_playlists(
        song,
        filename,
        affected,
        primary_playlist=playlist_name,
        primary_order=track_order,
        spotify_playlist_id=spotify_playlist_id,
        user_id=user_id,
    )
    if state.track_index is not None:
        dl_dir = Path(state.downloader.download_dir)
        slskd = slskd_dir_from_downloader(state.downloader)
        full = locate_library_file(filename, dl_dir, slskd)
        if full is not None:
            state.track_index.register_song(song, filename, full_path=full)
    invalidate_library_paths_cache()
    return affected


async def _schedule_playlist_refresh_after_download(
    playlist_names: set[str],
) -> None:
    if not playlist_names or state.downloader is None:
        return
    if state.playlist_catalog is None:
        return

    async def _run() -> None:
        try:
            await asyncio.to_thread(
                refresh_playlists_after_moves,
                playlist_names,
                settings=state.settings,
                downloader=state.downloader,
                playlist_catalog=state.playlist_catalog,
                track_index=state.track_index,
                monitor_db=state.monitor_db,
                navidrome_index=state.navidrome_index,
                navidrome_scan=bool(
                    state.settings.get('navidrome', {}).get(
                        'scan_after_download', True
                    )
                ),
                playlist_spotify_cache=state.playlist_spotify_cache,
                cover_cache=state.cover_cache,
                metadata_cache=state.metadata_cache,
            )
        except Exception:
            logger.exception(
                'download: playlist refresh failed for {}',
                ', '.join(sorted(playlist_names)[:5]),
            )

    spawn_task(_run(), name='playlist-refresh-after-download')


def _merge_nested_setting(key: str, saved: dict[str, Any]) -> dict[str, Any]:
    """Merge a nested setting over its defaults.

    For ``usenet`` the SABnzbd sub-dict is deep-merged (older saves may
    lack newer keys) while the ``indexers`` list is replaced wholesale by
    the saved value.
    """
    merged = {**DEFAULT_SETTINGS[key], **saved}
    if key == 'usenet' and isinstance(saved.get('sabnzbd'), dict):
        merged['sabnzbd'] = {
            **DEFAULT_SETTINGS['usenet']['sabnzbd'],
            **saved['sabnzbd'],
        }
    return merged


# Defaults that changed for new installs. A settings file saved before,
# without the key, keeps the old default: turning organizing on by itself
# would scatter an existing library's new downloads into other folders.
_PREVIOUS_DEFAULTS: dict[str, Any] = {
    'organize_by_artist': False,
    'organize_by_album': False,
    'download_cover_art_playlists': False,
    'download_cover_art_artist': False,
}


def _load_settings(path: Path) -> dict[str, Any]:
    """Load saved settings from *path*, merging with DEFAULT_SETTINGS as base."""
    try:
        saved = json.loads(path.read_text(encoding='utf-8'))
        if isinstance(saved, dict):
            merged = {**DEFAULT_SETTINGS, **_PREVIOUS_DEFAULTS}
            for k, v in saved.items():
                if k not in DEFAULT_SETTINGS:
                    continue
                if k in _NESTED_SETTINGS and isinstance(v, dict):
                    merged[k] = _merge_nested_setting(k, v)
                else:
                    merged[k] = v
            merged['max_parallel_downloads'] = _clamp_parallel_downloads(
                merged['max_parallel_downloads']
            )
            merged['download_delay_seconds'] = _clamp_download_delay(
                merged['download_delay_seconds']
            )
            merged['max_track_duration_seconds'] = _clamp_track_duration(
                merged.get(
                    'max_track_duration_seconds',
                    DEFAULT_SETTINGS['max_track_duration_seconds'],
                )
            )
            merged['external_sync_delay_seconds'] = _clamp_download_delay(
                merged.get(
                    'external_sync_delay_seconds',
                    DEFAULT_SETTINGS['external_sync_delay_seconds'],
                )
            )
            merged['cover_resolution'] = _clamp_cover_resolution(
                merged['cover_resolution']
            )
            merged['ui_language'] = _clean_ui_language(merged['ui_language'])
            merged['external_library'] = effective_external_library(merged)
            normalize_lyrics_location(merged)
            return merged
    except Exception:
        pass
    return dict(DEFAULT_SETTINGS)


def _save_settings(path: Path, settings: dict[str, Any]) -> None:
    try:
        path.write_text(json.dumps(settings, indent=2), encoding='utf-8')
    except Exception as exc:
        logger.warning('Could not persist settings: {}', exc)


def _library_dirs() -> tuple[Path, Optional[Path]]:
    download_dir = (
        Path(state.downloader.download_dir)
        if state.downloader is not None
        else Path('/downloads')
    )
    slskd_dir = (
        slskd_dir_from_downloader(state.downloader)
        if state.downloader is not None
        else None
    )
    return download_dir, slskd_dir


def normalize_lyrics_location(settings: dict[str, Any]) -> None:
    """Keep ``lyrics_lrc_*`` keys valid against the current music trees."""

    download_dir, slskd_dir = _library_dirs()
    extra = extra_dirs_from_settings(settings, download_dir, slskd_dir)
    settings['lyrics_lrc_beside'] = lyrics.coerce_bool(
        settings.get('lyrics_lrc_beside'), True
    )
    settings['lyrics_lrc_dir'] = lyrics.sanitize_lyrics_lrc_dir(
        settings.get('lyrics_lrc_dir'),
        download_dir=download_dir,
        slskd_dir=slskd_dir,
        extra_dirs=extra,
    )


def bind_lrc_resolver() -> None:
    """Point sidecar writes at the live settings (folder vs beside)."""

    def _resolve(audio: Path) -> Path:
        ctx = library_context()
        return lyrics.lrc_sidecar_path(
            audio,
            settings=state.settings,
            download_dir=ctx.download_dir,
            slskd_dir=ctx.slskd_dir,
            extra_dirs=ctx.extra_dirs,
        )

    def _root() -> Optional[Path]:
        return Path(
            str(
                state.settings.get('lyrics_lrc_dir')
                or lyrics.DEFAULT_LYRICS_LRC_DIR
            )
        )

    def _search(audio: Path) -> list[Path]:
        ctx = library_context()
        dedicated = lyrics.lrc_sidecar_path(
            audio,
            settings={**state.settings, 'lyrics_lrc_beside': False},
            download_dir=ctx.download_dir,
            slskd_dir=ctx.slskd_dir,
            extra_dirs=ctx.extra_dirs,
        )
        return [dedicated]

    lyrics.set_lrc_resolver(_resolve, tree_root=_root, search=_search)


@router.get('/api/version')
def get_version() -> str:
    return state.version


@router.get('/api/health')
def get_health() -> dict[str, Any]:
    """Liveness probe: the process is up and FastAPI is serving requests.

    Deliberately doesn't check the downloader/monitor DB — those are
    only set up once ``main.py``'s startup hook finishes, so gating
    health on them would report unhealthy during the brief, normal
    window right after boot. Docker's ``HEALTHCHECK`` already has a
    ``--start-period`` for that; this endpoint just needs to answer.
    """
    return {'status': 'ok', 'version': state.version}


@router.get('/api/check_update')
def check_update() -> Optional[dict[str, Any]]:
    """Result of the last hourly GitHub Releases check (see
    ``downtify/update_check.py``), or ``None`` before the first one has
    run — briefly, right after startup.
    """
    if state.update_checker is None:
        return None
    return state.update_checker.status(state.version)


@router.get('/api/songs/search')
def search_endpoint(query: str = Query('')) -> list[dict[str, Any]]:
    results = providers.search_songs(query, limit=20)
    if results:
        return results
    audio_providers = _effective_audio_providers(state.settings)
    if not query.strip() or not {'slskd', 'usenet'} & set(audio_providers):
        return []
    # With slskd or usenet enabled, a search YouTube Music has nothing for
    # can still be downloaded from Soulseek or Usenet: offer the query
    # itself as a track ("Artist - Title" is split into artist and title).
    stub = providers.song_stub_from_text_query(q := query.strip())
    if stub is None:
        return []
    logger.info(
        'Search fallback for slskd: q={!r} title={!r} artists={}',
        q,
        stub.get('name'),
        stub.get('artists'),
    )
    return [stub]


@router.get('/api/albums/search')
def search_albums_endpoint(
    request: Request,
    query: str = Query(''),
    limit: int = Query(25, ge=1, le=50),
) -> list[dict[str, Any]]:
    # A user's own choice (Settings > General) wins over the server's.
    wanted = user_preferences(request).get(
        'search_albums', state.settings.get('search_albums', True)
    )
    if not wanted:
        return []
    return providers.search_albums(query, limit=limit)


@router.get('/api/artists/search')
def search_artists_endpoint(query: str = Query('')) -> list[dict[str, Any]]:
    return providers.search_artists(query, limit=10)


@router.get('/api/discover/chart')
def discover_chart_endpoint(
    limit: int = Query(25, ge=1, le=50),
) -> dict[str, Any]:
    try:
        return deezer.fetch_chart(limit=limit)
    except ValueError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


_DEEZER_ID = r'^\d+$'


@router.get('/api/finder/search')
def finder_search_endpoint(
    query: str = Query(''),
    limit: int = Query(25, ge=1, le=50),
) -> dict[str, Any]:
    try:
        return deezer.finder_search(query, limit=limit)
    except ValueError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@router.get('/api/finder/artist')
def finder_artist_endpoint(
    artist_id: str = Query(..., pattern=_DEEZER_ID),
    lang: str = Query('en', max_length=16),
) -> dict[str, Any]:
    try:
        artist = deezer.finder_artist(artist_id, lang)
    except ValueError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc
    # Plain text, paragraphs split by a blank line - the same cleanup a
    # saved artist bio gets, so the page never renders Deezer's HTML.
    artist['bio'] = artist_profile._format_bio_text(artist.pop('bio_html'))
    return artist


@router.get('/api/finder/artist/songs')
def finder_artist_songs_endpoint(
    artist_id: str = Query(..., pattern=_DEEZER_ID),
    name: str = Query(..., min_length=1),
) -> dict[str, Any]:
    """A Deezer artist's songs, shaped like a Finder search's
    ``{songs, albums, artists}`` (albums and artists always empty) - see
    ``downtify.deezer.finder_artist_songs``."""

    try:
        songs = deezer.finder_artist_songs(artist_id, name)
    except ValueError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc
    return {'songs': songs, 'albums': [], 'artists': []}


@router.get('/api/finder/artist/albums')
def finder_artist_albums_endpoint(
    artist_id: str = Query(..., pattern=_DEEZER_ID),
) -> list[dict[str, Any]]:
    try:
        return deezer.finder_artist_albums(artist_id)
    except ValueError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@router.get('/api/finder/albums/track_counts')
def finder_album_track_counts_endpoint(
    ids: str = Query(''),
) -> dict[str, int]:
    return deezer.album_track_counts(ids.split(','))


@router.get('/api/finder/album')
def finder_album_endpoint(
    album_id: str = Query(..., pattern=_DEEZER_ID),
) -> dict[str, Any]:
    try:
        return deezer.finder_album(album_id)
    except ValueError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@router.get('/api/artists/top_songs')
def artist_top_songs_endpoint(
    channel_id: str = Query(...),
) -> list[dict[str, Any]]:
    return providers.artist_top_songs_from_channel_id(channel_id)


@router.get('/api/artists/top_albums')
def artist_top_albums_endpoint(
    channel_id: str = Query(...),
) -> list[dict[str, Any]]:
    return providers.artist_top_albums_from_channel_id(channel_id)


@router.get('/api/artists/info')
def artist_info_endpoint(channel_id: str = Query(...)) -> dict[str, Any]:
    return providers.artist_info_from_channel_id(channel_id)


@router.get('/api/artists/similar')
def artist_similar_endpoint(
    channel_id: str = Query(...),
) -> list[dict[str, Any]]:
    return providers.artist_similar_from_channel_id(channel_id)


def _artist_profile_download_dir() -> Path:
    return (
        Path(state.downloader.download_dir)
        if state.downloader is not None
        else Path('/downloads')
    )


def _artist_art_entry(download_dir: Path, name: str) -> dict[str, Any]:
    """An artist's saved photo/banner URLs, each with the version
    (``*_version``, see ``artist_profile.image_version_for``) the client
    puts in the URL so a replaced image isn't shown from a browser cache."""

    entry: dict[str, Any] = {}
    for prefix, kind in (
        ('photo', artist_profile.KIND_PHOTO),
        ('banner', artist_profile.KIND_BANNER),
    ):
        entry[f'{prefix}_url'] = artist_profile.image_url_for(
            download_dir, name, kind
        )
        entry[f'{prefix}_version'] = artist_profile.image_version_for(
            download_dir, name, kind
        )
    return entry


@router.get('/api/artists/art')
def artist_art_endpoint(name: str = Query(...)) -> dict[str, Any]:
    return _artist_art_entry(_artist_profile_download_dir(), name)


def _decode_base64url(value: str) -> str:
    """*value* decoded from base64url (padding optional) to text, or
    :class:`ValueError` when it isn't valid base64url text."""

    try:
        padded = value + '=' * (-len(value) % 4)
        return base64.urlsafe_b64decode(padded.encode('ascii')).decode('utf-8')
    except ValueError as exc:
        # binascii.Error and the Unicode errors are all ValueErrors.
        raise ValueError('url is not base64url') from exc


@router.get('/api/artists/photo-proxy')
def artist_photo_proxy_endpoint(
    name: str = Query(...), url: str = ''
) -> Response:
    """DISPLAY-ONLY artist photo for the UI, never persisted.

    A photo already saved for the artist wins and is served uncached;
    otherwise Deezer's is relayed and cached by the browser for
    three hours, and so is Deezer saying the artist has none (404). A
    failure - Deezer unreachable or over its request limit, a broken
    download - is a 503 the browser is told not to keep, so the next visit
    simply asks again. Not a way to obtain a photo to keep - see
    ``downtify.artist_photo_proxy``.

    *url*, optional: the artist's Deezer picture, when the page already
    has it (Discover's suggestions, the Finder), base64url-encoded (RFC
    4648 section 5, padding optional) so the address travels as one plain
    query value - relayed as the photo without searching Deezer for the
    name. Only a Deezer CDN address is accepted; anything else, or a value
    that isn't base64url, is a ``400``.
    """

    cache_control = (
        f'public, max-age={artist_photo_proxy.BROWSER_CACHE_SECONDS}'
    )
    local = artist_profile.image_path_for(
        _artist_profile_download_dir(), name, artist_profile.KIND_PHOTO
    )
    if local.is_file():
        return FileResponse(
            local,
            media_type=mimetypes.guess_type(str(local))[0] or 'image/jpeg',
            # Only remote photos are cached: a saved one may be replaced
            # at any moment, so the browser revalidates it every time.
            headers={'Cache-Control': 'no-cache'},
        )
    try:
        if url:
            photo = artist_photo_proxy.fetch_photo_at(_decode_base64url(url))
        else:
            photo = artist_photo_proxy.fetch_proxied_photo(name)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except artist_photo_proxy.PhotoUnavailable:
        # Not "no photo": never cached, so whatever went wrong (a rate
        # limit, say) is gone the next time the page asks.
        return Response(status_code=503, headers={'Cache-Control': 'no-store'})
    if photo is None:
        # Deezer's own answer that the artist has none: cacheable, or the
        # page would re-ask for every tile on every visit.
        return Response(
            status_code=404, headers={'Cache-Control': cache_control}
        )
    data, content_type = photo
    return Response(
        content=data,
        media_type=content_type,
        headers={
            'Cache-Control': cache_control,
            'ETag': f'"{hashlib.sha1(data).hexdigest()}"',
        },
    )


@router.post('/api/artists/art/bulk')
async def artist_art_bulk_endpoint(request: Request) -> dict[str, Any]:
    """Saved photo/banner URLs for many artists in one call - the Library
    page's artist grid needs this for every tile at once, rather than one
    request per artist."""

    payload = await _json_object(request)
    names = payload.get('names')
    if not isinstance(names, list):
        return {}
    download_dir = _artist_profile_download_dir()
    result: dict[str, Any] = {}
    for raw_name in names:
        name = str(raw_name or '').strip()
        if not name or name in result:
            continue
        result[name] = _artist_art_entry(download_dir, name)
    return result


@router.get('/api/artists/art/search')
def artist_art_search_endpoint(
    name: str = Query(...),
) -> list[dict[str, Any]]:
    query = name.strip()
    if not query:
        return []
    results: list[dict[str, Any]] = [
        {
            'source': 'youtube',
            'name': artist.get('name') or '',
            'image_url': artist['cover_url'],
        }
        for artist in providers.search_artists(query, limit=8)
        if artist.get('cover_url')
    ]
    results.extend(deezer.search_artist(query, limit=8))
    return results


@router.get('/api/artists/art/spotify_candidate')
def artist_art_spotify_candidate_endpoint(
    file: str = Query(''),
    kind: str = Query(artist_profile.KIND_PHOTO),
    name: str = Query(''),
) -> dict[str, Any]:
    """A Spotify photo/banner candidate for an artist.

    The artist is resolved from *file* (a library track downloaded from
    Spotify - the most reliable route, no namesake risk) when that gives
    one, else from an exact-name search on *name*.
    """

    artist_id: Optional[str] = None
    try:
        artist_id = _spotify_artist_id_from_library_file(file)
        if not artist_id and name.strip():
            found = spotify.search_artist_by_name(name)
            artist_id = found['id'] if found else None
        if not artist_id:
            return {}
        image_url = (
            spotify.artist_banner_url_from_id(artist_id)
            if kind == artist_profile.KIND_BANNER
            else spotify.artist_image_url_from_id(artist_id)
        )
        if not image_url:
            return {}
        artist_name = spotify.artist_name_from_id(artist_id)
    except Exception:
        logger.opt(exception=True).debug(
            'Spotify artist art candidate lookup failed (file={!r}, '
            'name={!r})',
            file,
            name,
        )
        return {}
    return {'source': 'spotify', 'name': artist_name, 'image_url': image_url}


def _spotify_artist_id_from_library_file(file: str) -> Optional[str]:
    """Spotify id of the first artist of a library file's Spotify track,
    or ``None`` when *file* is empty, unknown, or wasn't from Spotify."""

    if not file.strip() or state.track_index is None:
        return None
    if resolve_library_file(file, library_context()) is None:
        return None
    track_id = state.track_index.spotify_id_for_filename(
        file.strip().replace('\\', '/')
    )
    if not track_id:
        return None
    return spotify.primary_artist_id_from_track_id(track_id)


@router.post('/api/artists/art/from_url')
async def artist_art_from_url_endpoint(request: Request) -> dict[str, Any]:
    payload = await _json_object(request)
    name = str(payload.get('name') or '').strip()
    kind = str(payload.get('kind') or '').strip()
    image_url = str(payload.get('image_url') or '').strip()
    source = str(payload.get('source') or '').strip()
    if not name or kind not in {
        artist_profile.KIND_PHOTO,
        artist_profile.KIND_BANNER,
    }:
        raise HTTPException(status_code=400, detail='Invalid request')
    try:
        url = await asyncio.to_thread(
            artist_profile.fetch_and_save_image,
            _artist_profile_download_dir(),
            name,
            kind,
            image_url,
            source,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return {'url': url}


@router.post('/api/artists/art/upload')
async def artist_art_upload_endpoint(
    request: Request,
    name: str = Query(...),
    kind: str = Query(...),
    source: str = '',
) -> dict[str, Any]:
    if kind not in {artist_profile.KIND_PHOTO, artist_profile.KIND_BANNER}:
        raise HTTPException(status_code=400, detail='Invalid kind')
    content = await request.body()
    if len(content) > artist_profile.MAX_IMAGE_BYTES:
        raise HTTPException(status_code=413, detail='File is too large')
    try:
        url = await asyncio.to_thread(
            artist_profile.save_image,
            _artist_profile_download_dir(),
            name,
            kind,
            content,
            source,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return {'url': url}


@router.delete('/api/artists/art')
def artist_art_delete_endpoint(
    name: str = Query(...), kind: str = Query(...)
) -> dict[str, Any]:
    if kind not in {artist_profile.KIND_PHOTO, artist_profile.KIND_BANNER}:
        raise HTTPException(status_code=400, detail='Invalid kind')
    removed = artist_profile.delete_image(
        _artist_profile_download_dir(), name, kind
    )
    return {'removed': removed}


@router.get('/api/artists/profile')
def artist_profile_endpoint(name: str = Query(...)) -> dict[str, Any]:
    return artist_profile.load_profile(_artist_profile_download_dir(), name)


@router.get('/api/artists/top_songs/spotify')
async def artist_top_songs_saved_endpoint(
    name: str = Query(...),
) -> dict[str, Any]:
    """An artist's saved Spotify top songs (see
    ``artist_profile.profile_top_songs_ensure``), for the artist page's Top
    songs tab.

    A fresh file is returned as is. A stale one is returned right away
    while a refresh runs in the background; with no file yet the songs are
    fetched now and saved. The Spotify artist id is the one in the artist's
    profile (``platforms_id.spotify``).
    """

    artist = name.strip()
    if not artist:
        raise HTTPException(status_code=400, detail='Invalid request')
    download_dir = _artist_profile_download_dir()
    profile = artist_profile.load_profile(download_dir, artist)
    spotify_id = str(profile['platforms_id'].get('spotify') or '')
    if not spotify_id:
        raise HTTPException(
            status_code=404, detail='No Spotify artist saved for this artist'
        )
    saved, fresh = artist_profile.profile_top_songs_cached(
        download_dir, artist, spotify_id
    )
    if saved is not None:
        if not fresh:
            artist_profile.profile_top_songs_refresh_in_background(
                download_dir, artist, spotify_id
            )
        return {**saved, 'stale': not fresh}
    try:
        data = await asyncio.to_thread(
            artist_profile.profile_top_songs_ensure,
            download_dir,
            artist,
            spotify_id,
        )
    except Exception as exc:
        logger.exception('Failed to fetch top songs for {}', artist)
        raise HTTPException(status_code=502, detail=str(exc)) from exc
    return {**data, 'stale': False}


@router.post('/api/artists/profile/ensure')
async def artist_profile_ensure_endpoint(request: Request) -> dict[str, Any]:
    payload = await _json_object(request)
    name = str(payload.get('name') or '').strip()
    lang = str(payload.get('lang') or 'en').strip()
    track_files = payload.get('track_files')
    if not name:
        raise HTTPException(status_code=400, detail='Invalid request')
    download_dir = _artist_profile_download_dir()
    profile = await asyncio.to_thread(
        artist_profile.ensure_profile,
        download_dir,
        name,
        track_files if isinstance(track_files, list) else [],
        lang,
        track_index=state.track_index,
        image_kinds=_artist_image_kinds_to_save(state.settings),
    )
    # The artist page's Top songs tab reads this file: get it made (or
    # refreshed once it's a week old) without holding up the profile.
    artist_profile.profile_top_songs_refresh_in_background(
        download_dir, name, str(profile['platforms_id'].get('spotify') or '')
    )
    return profile


def _artist_image_kinds_to_save(settings: dict[str, Any]) -> tuple[str, ...]:
    """Which of an artist's photo/banner Downtify may save on its own,
    per the user's ``download_cover_art_artist``/``..._banner`` settings.
    Only automatic saving is gated by them - the artist-art picker is
    always available and saves whatever the user picks."""

    return tuple(
        kind
        for kind, key in (
            (artist_profile.KIND_PHOTO, 'download_cover_art_artist'),
            (artist_profile.KIND_BANNER, 'download_cover_art_artist_banner'),
        )
        if settings.get(key)
    )


def _ui_language() -> str:
    """The language the web UI is shown in (see ``ui_language`` in
    ``DEFAULT_SETTINGS``), or ``en`` while no page has said."""

    return str(state.settings.get('ui_language') or '') or 'en'


def enrich_artist_after_download(song: dict[str, Any], filename: str) -> None:
    """``Downloader.on_downloaded``: a track just finished, so its artist's
    profile (bio, genre, origin, social links, platform ids) is seeded in the
    background if they have none yet - the same seeding as opening their
    Library page, see ``artist_profile.profile_seed_enqueue``.

    Photo and banner are saved only if the user's settings allow it, read
    now rather than at startup so a change applies to the very next track.
    The artist's top songs are deliberately left alone: they are made when
    their page is opened. Returns at once and never raises - this runs on
    the download's own thread.
    """

    try:
        artist_profile.profile_seed_enqueue(
            _artist_profile_download_dir(),
            song,
            _ui_language(),
            _artist_image_kinds_to_save(state.settings),
        )
    except Exception:
        logger.opt(exception=True).debug(
            'Could not queue the artist profile of {}', filename
        )


@router.post('/api/artists/profile/bio')
async def artist_profile_bio_endpoint(request: Request) -> dict[str, Any]:
    payload = await _json_object(request)
    name = str(payload.get('name') or '').strip()
    lang = str(payload.get('lang') or 'en').strip()
    source = str(payload.get('source') or artist_profile.BIO_SOURCE_AUTO)
    if not name:
        raise HTTPException(status_code=400, detail='Invalid request')
    try:
        return await asyncio.to_thread(
            artist_profile.fetch_bio,
            _artist_profile_download_dir(),
            name,
            lang,
            source,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.post('/api/artists/profile/bio/preview')
async def artist_profile_bio_preview_endpoint(
    request: Request,
) -> dict[str, str]:
    """One service's bio text for the edit modal's text box - saves
    nothing; the user keeps it (or not) with ``PUT .../bio``."""

    payload = await _json_object(request)
    name = str(payload.get('name') or '').strip()
    lang = str(payload.get('lang') or 'en').strip()
    source = str(payload.get('source') or '').strip()
    if not name:
        raise HTTPException(status_code=400, detail='Invalid request')
    try:
        bio = await asyncio.to_thread(
            artist_profile.preview_bio,
            _artist_profile_download_dir(),
            name,
            lang,
            source,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return {'bio': bio}


@router.delete('/api/artists/profile/bio')
def artist_profile_bio_delete_endpoint(
    name: str = Query(...),
) -> dict[str, Any]:
    return artist_profile.remove_bio(_artist_profile_download_dir(), name)


@router.put('/api/artists/profile/bio')
async def artist_profile_bio_set_endpoint(request: Request) -> dict[str, Any]:
    payload = await _json_object(request)
    name = str(payload.get('name') or '').strip()
    if not name:
        raise HTTPException(status_code=400, detail='Invalid request')
    return artist_profile.save_bio(
        _artist_profile_download_dir(), name, str(payload.get('bio') or '')
    )


@router.put('/api/artists/profile/social')
async def artist_profile_social_set_endpoint(
    request: Request,
) -> dict[str, Any]:
    payload = await _json_object(request)
    name = str(payload.get('name') or '').strip()
    if not name:
        raise HTTPException(status_code=400, detail='Invalid request')
    social = payload.get('social')
    return artist_profile.save_social(
        _artist_profile_download_dir(),
        name,
        social if isinstance(social, dict) else {},
    )


@router.get('/api/song/url')
def song_url_endpoint(url: str = Query(...)):
    return _resolve_url(url)


@router.get('/api/url')
def url_endpoint(url: str = Query(...)):
    return _resolve_url(url)


def _resolve_url(url: str):
    spotify_parsed = spotify.parse_spotify_url(url)
    if spotify_parsed is not None:
        kind, sid = spotify_parsed
        try:
            if kind == 'track':
                return spotify.track_from_id(sid, with_album=True)
            if kind == 'album':
                return spotify.album_tracks_from_id(sid)
            if kind == 'playlist':
                return spotify.playlist_tracks_from_id(sid)
        except Exception as exc:
            logger.exception('Failed to resolve Spotify URL {}', url)
            raise HTTPException(status_code=502, detail=str(exc)) from exc
        raise HTTPException(
            status_code=400, detail=f'Unsupported entity type: {kind}'
        )

    youtube_parsed = providers.parse_youtube_url(url)
    if youtube_parsed is not None:
        kind, yid = youtube_parsed
        try:
            if kind == 'track':
                return providers.song_from_video_id(yid)
            if kind == 'album':
                return providers.album_tracks_from_browse_id(yid)
            if kind == 'playlist':
                return providers.playlist_tracks_from_id(yid)
            if kind == 'artist':
                return providers.artist_albums_from_channel_id(
                    providers.resolve_artist_channel_id(yid)
                )
        except ValueError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        except Exception as exc:
            logger.exception('Failed to resolve YouTube URL {}', url)
            raise HTTPException(status_code=502, detail=str(exc)) from exc
        raise HTTPException(
            status_code=400, detail=f'Unsupported entity type: {kind}'
        )

    deezer_parsed = deezer.parse_deezer_url(url)
    if deezer_parsed is not None:
        kind, did = deezer_parsed
        try:
            if kind == 'track':
                return deezer.track_from_id(did)
            if kind == 'album':
                return deezer.album_from_id(did)
            if kind == 'playlist':
                _, tracks = deezer.playlist_info_and_tracks(did)
                return tracks
            if kind == 'artist':
                _, _cover, releases = deezer.artist_page_from_id(did)
                return releases
        except ValueError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        except Exception as exc:
            logger.exception('Failed to resolve Deezer URL {}', url)
            raise HTTPException(status_code=502, detail=str(exc)) from exc
        raise HTTPException(
            status_code=400, detail=f'Unsupported entity type: {kind}'
        )

    raise HTTPException(status_code=400, detail='Invalid URL')


def _artists_label(song: dict[str, Any]) -> str:
    artists = song.get('artists') or []
    if isinstance(artists, list) and artists:
        return ', '.join(str(a) for a in artists if a)
    return str(song.get('artist') or '')


def _collection_details(
    kind: str, tracks: list[dict[str, Any]], name: str = ''
) -> dict[str, Any]:
    first = tracks[0] if tracks else {}
    is_album = kind == 'album'
    return {
        'kind': kind,
        'name': name or str(first.get('album_name') or ''),
        'subtitle': _artists_label(first) if is_album else '',
        # A playlist has no single cover in the track rows; the client
        # builds a mosaic from the tracks' own covers instead.
        'cover_url': str(first.get('cover_url') or '') if is_album else '',
        'year': str(first.get('year') or '') if is_album else '',
        'tracks': tracks,
        'albums': [],
    }


def _track_details(song: dict[str, Any]) -> dict[str, Any]:
    return {
        'kind': 'track',
        'name': str(song.get('name') or ''),
        'subtitle': _artists_label(song),
        'cover_url': str(song.get('cover_url') or ''),
        'year': str(song.get('year') or ''),
        'tracks': [song],
        'albums': [],
    }


def _spotify_details(kind: str, sid: str) -> dict[str, Any]:
    if kind == 'track':
        return _track_details(spotify.track_from_id(sid, with_album=True))
    if kind == 'album':
        return _collection_details('album', spotify.album_tracks_from_id(sid))
    if kind == 'playlist':
        name, tracks = spotify.playlist_info_and_tracks(sid)
        return _collection_details('playlist', tracks, name)
    if kind == 'artist':
        # The embed has no discography (see spotify.artist_name_from_id);
        # the releases come from the player's artist overview. The client
        # offers the top songs from /api/artists/top_songs/url.
        name, cover_url, releases = spotify.artist_page_from_id(sid)
        return {
            'kind': 'artist',
            'name': name,
            'subtitle': '',
            'cover_url': cover_url,
            'year': '',
            'tracks': [],
            'albums': releases,
        }
    raise HTTPException(
        status_code=400, detail=f'Unsupported entity type: {kind}'
    )


def _youtube_details(kind: str, yid: str) -> dict[str, Any]:
    if kind == 'track':
        return _track_details(providers.song_from_video_id(yid))
    if kind == 'album':
        return _collection_details(
            'album', providers.album_tracks_from_browse_id(yid)
        )
    if kind == 'playlist':
        name, tracks = providers.playlist_info_and_tracks_from_id(yid)
        return _collection_details('playlist', tracks, name)
    if kind == 'artist':
        channel_id = providers.resolve_artist_channel_id(yid)
        info = providers.artist_info_from_channel_id(channel_id)
        return {
            'kind': 'artist',
            'name': str(info.get('name') or ''),
            'subtitle': str(info.get('description') or ''),
            'cover_url': str(info.get('cover_url') or ''),
            'year': '',
            'tracks': [],
            'albums': providers.artist_albums_from_channel_id(channel_id),
        }
    raise HTTPException(
        status_code=400, detail=f'Unsupported entity type: {kind}'
    )


def _deezer_details(kind: str, did: str) -> dict[str, Any]:
    if kind == 'track':
        return _track_details(deezer.track_from_id(did))
    if kind == 'album':
        return _collection_details('album', deezer.album_from_id(did))
    if kind == 'playlist':
        name, tracks = deezer.playlist_info_and_tracks(did)
        return _collection_details('playlist', tracks, name)
    if kind == 'artist':
        # Deezer has a real discography endpoint (unlike Spotify's embed),
        # so - like YouTube Music - the releases come straight from it,
        # no overview-shelf fallback needed. The client offers top songs
        # from /api/artists/top_songs/url, same as the other two sources.
        name, cover_url, releases = deezer.artist_page_from_id(did)
        return {
            'kind': 'artist',
            'name': name,
            'subtitle': '',
            'cover_url': cover_url,
            'year': '',
            'tracks': [],
            'albums': releases,
        }
    raise HTTPException(
        status_code=400, detail=f'Unsupported entity type: {kind}'
    )


@router.get('/api/url/resolve')
def url_resolve_endpoint(url: str = Query(...)) -> dict[str, Any]:
    """What a pasted link points at, with its tracks (or releases).

    Same inputs as ``/api/song/url``, but always an object:
    ``{kind, name, subtitle, cover_url, year, tracks, albums}`` -
    ``kind`` is ``track``, ``album``, ``playlist`` or ``artist``; an
    artist fills ``albums`` (release summaries) instead of ``tracks``.
    """

    spotify_parsed = spotify.parse_spotify_url(url)
    youtube_parsed = (
        None if spotify_parsed else providers.parse_youtube_url(url)
    )
    deezer_parsed = (
        None
        if spotify_parsed or youtube_parsed
        else deezer.parse_deezer_url(url)
    )
    if spotify_parsed is None and youtube_parsed is None and not deezer_parsed:
        raise HTTPException(status_code=400, detail='Invalid URL')
    try:
        if spotify_parsed is not None:
            return _spotify_details(*spotify_parsed)
        if youtube_parsed is not None:
            return _youtube_details(*youtube_parsed)
        return _deezer_details(*deezer_parsed)
    except HTTPException:
        raise
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except Exception as exc:
        logger.exception('Failed to resolve URL {}', url)
        raise HTTPException(status_code=502, detail=str(exc)) from exc


# The YouTube Music "Top songs" playlist is the artist's whole catalogue
# ranked by popularity (well over a hundred rows, with alternate editions
# of the same song), so only its head is worth listing.
YOUTUBE_TOP_SONGS_LIMIT = 50


def _resolve_artist_top_songs(url: str) -> dict[str, Any]:
    """Artist name, cover and top songs for a pasted artist URL.

    Spotify is read from the artist's own "Popular" shelf (see
    :func:`spotify.artist_top_songs_from_id`). YouTube Music prefers the
    shelf's full auto-generated playlist (see
    :func:`providers.artist_full_top_songs_from_channel_id`), cut to
    ``YOUTUBE_TOP_SONGS_LIMIT``, and falls back to the ~5 item preview on
    the artist page.
    """

    spotify_parsed = spotify.parse_spotify_url(url)
    if spotify_parsed is not None and spotify_parsed[0] == 'artist':
        _, artist_id = spotify_parsed
        try:
            name, cover_url, songs = spotify.artist_top_songs_from_id(
                artist_id
            )
        except Exception as exc:
            logger.exception('Failed to resolve Spotify artist {}', url)
            raise HTTPException(status_code=502, detail=str(exc)) from exc
        return {
            'source': 'spotify',
            'artist_id': artist_id,
            'name': name,
            'cover_url': cover_url,
            'songs': songs,
        }

    youtube_parsed = providers.parse_youtube_url(url)
    if youtube_parsed is not None and youtube_parsed[0] == 'artist':
        _, channel_or_handle = youtube_parsed
        try:
            channel_id = providers.resolve_artist_channel_id(channel_or_handle)
            info = providers.artist_info_from_channel_id(channel_id)
            songs = providers.artist_full_top_songs_from_channel_id(
                channel_id
            ) or providers.artist_top_songs_from_channel_id(channel_id)
        except ValueError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        except Exception as exc:
            logger.exception('Failed to resolve YouTube artist {}', url)
            raise HTTPException(status_code=502, detail=str(exc)) from exc
        return {
            'source': 'youtube',
            'artist_id': channel_id,
            'name': info.get('name') or channel_id,
            'cover_url': info.get('cover_url') or '',
            'songs': songs[:YOUTUBE_TOP_SONGS_LIMIT],
        }

    deezer_parsed = deezer.parse_deezer_url(url)
    if deezer_parsed is not None and deezer_parsed[0] == 'artist':
        _, artist_id = deezer_parsed
        try:
            name, cover_url, songs = deezer.artist_top_songs_from_id(artist_id)
        except Exception as exc:
            logger.exception('Failed to resolve Deezer artist {}', url)
            raise HTTPException(status_code=502, detail=str(exc)) from exc
        return {
            'source': 'deezer',
            'artist_id': artist_id,
            'name': name,
            'cover_url': cover_url,
            'songs': songs,
        }

    raise HTTPException(
        status_code=400,
        detail='A Spotify, YouTube Music or Deezer artist URL is required',
    )


@router.get('/api/artists/top_songs/url')
async def artist_top_songs_from_url_endpoint(
    url: str = Query(...),
) -> dict[str, Any]:
    return await asyncio.to_thread(_resolve_artist_top_songs, url)


def _merge_client_track_hints(
    base: dict[str, Any],
    hints: Optional[dict[str, Any]],
) -> None:
    """Copy tagging fields from the client-resolved Spotify row.

    ``POST /api/download/url`` re-fetches metadata from the URL only, which loses
    ``track_number`` for rows that came from an album/playlist browse.
    """

    if not isinstance(hints, dict) or not hints:
        return
    tn = hints.get('track_number')
    if tn is not None:
        try:
            iv = int(tn)
        except (TypeError, ValueError):
            pass
        else:
            if iv > 0:
                base['track_number'] = iv
    tt = hints.get('album_track_total')
    if tt is not None:
        try:
            tv = int(tt)
        except (TypeError, ValueError):
            pass
        else:
            if tv > 0:
                base['album_track_total'] = tv
    rd = hints.get('release_date')
    if isinstance(rd, str) and rd.strip():
        base['release_date'] = rd.strip()
    yr = hints.get('year')
    if isinstance(yr, str) and yr.strip():
        base['year'] = yr.strip()
    # A video id the user pasted to retry a failed track: download exactly
    # that video instead of matching again.
    ytid = str(hints.get('youtube_id') or '').strip()
    if ytid:
        base['youtube_id'] = ytid
        base['youtube_id_override'] = True


_CLIENT_RESOLVED_SOURCES = {'text_search', 'deezer'}


def _song_from_download_request(
    url: str, client_hints: Optional[dict[str, Any]]
) -> dict[str, Any]:
    """The song to download for ``POST /api/download/url``.

    A slskd search stub (``source == 'text_search'``, see
    :func:`search_endpoint`) or a Deezer chart/Finder row (``source ==
    'deezer'``, see :func:`discover_chart_endpoint` and
    :func:`finder_search_endpoint`) has no URL this app
    can resolve on its own - both are taken from the request body as-is,
    already-resolved metadata that :func:`downtify.providers.find_match`
    can search YouTube/YouTube Music for directly.
    """

    if (
        isinstance(client_hints, dict)
        and client_hints.get('source') in _CLIENT_RESOLVED_SOURCES
    ):
        return dict(client_hints)
    song = _song_for_download(url)
    _merge_client_track_hints(song, client_hints)
    return song


def _song_for_download(url: str) -> dict[str, Any]:
    parsed = spotify.parse_spotify_url(url)
    if parsed is not None:
        kind, sid = parsed
        if kind == 'track':
            return spotify.track_from_id(sid, with_album=True)
        raise HTTPException(
            status_code=400,
            detail='Only Spotify track URLs are supported here',
        )
    youtube_parsed = providers.parse_youtube_url(url)
    if youtube_parsed is not None:
        kind, yid = youtube_parsed
        if kind == 'track':
            return providers.song_from_video_id(yid)
        raise HTTPException(
            status_code=400,
            detail='Only single YouTube video URLs are supported here',
        )
    deezer_parsed = deezer.parse_deezer_url(url)
    if deezer_parsed is not None:
        kind, did = deezer_parsed
        if kind == 'track':
            return deezer.track_from_id(did)
        raise HTTPException(
            status_code=400,
            detail='Only Deezer track URLs are supported here',
        )
    raise HTTPException(status_code=400, detail='Unsupported URL')


#: One lock per song id, so two accounts asking for the same track at
#: once share one download instead of writing one file twice.
_download_locks: dict[str, asyncio.Lock] = {}


def _register_job(
    song: dict[str, Any], status: str = 'queued', user_id: int = 0
) -> str:
    """Register a queue job, joining the running one when there is one.

    Two accounts asking for the same track share one job row (keyed by
    the song id as before): the requester joins ``user_ids``, an active
    job is never reset by a newcomer, and a finished one restarts fresh
    - the retry/re-download behavior stays exactly as it was.
    """

    song_id = str(song.get('song_id') or song.get('url') or id(song))
    job = state.download_jobs.get(song_id)
    if job is None:
        job = {
            'song': song,
            'status': status,
            'progress': 0,
            'message': '',
            'provider': '',
            'filename': None,
            'user_ids': set(),
        }
        state.download_jobs[song_id] = job
    elif job.get('status') not in {'queued', 'downloading'}:
        job.update(
            status=status,
            progress=0,
            message='',
            provider='',
            filename=None,
        )
    if user_id:
        users = job.setdefault('user_ids', set())
        if isinstance(users, set):
            users.add(user_id)
        else:
            job['user_ids'] = set(users) | {user_id}
    return song_id


def _job_users(job: dict[str, Any]) -> set[int]:
    """The accounts waiting on a job row (any shape it comes in)."""

    users = job.get('user_ids')
    if isinstance(users, set):
        return {int(uid) for uid in users if uid}
    if job.get('user_id'):
        return {int(job['user_id'])}
    return set()


def _note_download_owner(stored_path: str, user_id: int) -> None:
    """Record *user_id* as an owner of an on-disk download (best effort).

    Called for fresh downloads and for dedup hits alike, so two users
    asking for the same track share the one file with one row each.
    Never fails the download it runs next to.
    """

    if not user_id or state.track_owners is None or state.downloader is None:
        return
    try:
        full = locate_library_file(
            stored_path,
            Path(state.downloader.download_dir),
            slskd_dir_from_downloader(state.downloader),
        )
        if full is None:
            return
        key = content_key_for(full)
        if not key:
            return
        name = str(stored_path or '').strip().replace('\\', '/')
        added = state.track_owners.add(key, user_id, name)
        # New to this user: poke the mobile feed so their next
        # incremental sync picks the track up.
        if added and state.library_sync is not None:
            state.library_sync.touch(name)
    except Exception:
        logger.opt(exception=True).debug(
            'Could not record owner for {}', stored_path
        )


def _note_download_owners(stored_path: str, user_ids: Collection[int]) -> None:
    """Claim one finished file for every account waiting on its job."""

    for waiter in sorted(set(user_ids)):
        if waiter:
            _note_download_owner(stored_path, waiter)


async def _run_download(
    song: dict[str, Any],
    song_id: str,
    subdir: Optional[str] = None,
    delay_seconds: float = 0,
    *,
    playlist_name: Optional[str] = None,
    spotify_playlist_id: Optional[str] = None,
    track_order: int = 0,
    refresh_playlists: bool = True,
    user_id: int = 0,
) -> Optional[str]:
    """Run a single download to completion, updating jobs state and broadcasting WS events.

    The concurrency slot is acquired before the existing-file check and
    before the ``downloading`` broadcast, so a batch that starts every
    row at once cannot announce or look up all of them together. When
    *delay_seconds* is positive, that same slot stays held for that long
    after a successful download, so the next row can't start until the
    delay has elapsed. This is only meant for multi-song orchestration
    (playlist/album batches); single manual downloads should pass
    ``delay_seconds=0`` so a one-off download never waits around for
    nothing.

    With *Overwrite existing files* off, a song already in the library is
    not downloaded again: by its Spotify id in the track index (wherever it
    was saved, slskd folder included) or by its filename at the
    destination.

    A finished file is registered in the track index, the playlist catalog
    (for ``playlist_name``, at ``track_order``) and the caches. Unless
    ``refresh_playlists`` is off (a batch refreshes once at the end), the
    M3U/Navidrome playlists that contain the track are refreshed in the
    background.
    """

    if state.downloader is None:
        raise RuntimeError('Downloader not ready')

    loop = state.loop or asyncio.get_running_loop()
    job = state.download_jobs.get(song_id)
    if job is None:
        song_id = _register_job(song, status='downloading', user_id=user_id)
        job = state.download_jobs[song_id]
    elif user_id:
        users = job.setdefault('user_ids', set())
        if isinstance(users, set):
            users.add(user_id)
        else:
            job['user_ids'] = _job_users(job) | {user_id}

    # One download per track no matter how many accounts asked for it:
    # a second caller waits here, then shares the finished file (and
    # its ownership) instead of fetching the same bytes twice.
    lock = _download_locks.setdefault(song_id, asyncio.Lock())
    try:
        async with lock:
            if job.get('status') == 'done' and job.get('filename'):
                sharers = _job_users(job)
                if sharers:
                    await asyncio.to_thread(
                        _note_download_owners,
                        job['filename'],
                        sharers,
                    )
                return job['filename']
            return await _run_download_locked(
                song,
                song_id,
                job,
                loop,
                subdir=subdir,
                delay_seconds=delay_seconds,
                playlist_name=playlist_name,
                spotify_playlist_id=spotify_playlist_id,
                track_order=track_order,
                refresh_playlists=refresh_playlists,
                user_id=user_id,
            )
    finally:
        if not lock.locked():
            _download_locks.pop(song_id, None)


async def _run_download_locked(
    song: dict[str, Any],
    song_id: str,
    job: dict[str, Any],
    loop: asyncio.AbstractEventLoop,
    *,
    subdir: Optional[str] = None,
    delay_seconds: float = 0,
    playlist_name: Optional[str] = None,
    spotify_playlist_id: Optional[str] = None,
    track_order: int = 0,
    refresh_playlists: bool = True,
    user_id: int = 0,
) -> Optional[str]:
    """Single execution of a download job, for one owner of the lock.

    Shares the exact semantics the old ``_run_download`` body had: the
    concurrency slot is held across the existing-file check and the
    ``downloading`` broadcast, the post-download delay, and the
    skip-if-present path - except every broadcast and every ownership
    claim now covers all accounts waiting on the shared job, not just
    the caller that won the race to start it.
    """

    sem = state.download_semaphore
    try:
        async with sem if sem is not None else contextlib.nullcontext():
            if not getattr(state.downloader, 'overwrite_existing_files', True):
                existing_hit = await asyncio.to_thread(
                    resolve_existing_download,
                    state.downloader,
                    song,
                    subdir=subdir,
                    track_index=state.track_index,
                )
                if existing_hit:
                    existing, skip_message = existing_hit
                    logger.info(
                        'Skipping download ({}): {}',
                        skip_message.lower(),
                        existing,
                    )
                    job.update(
                        status='done',
                        filename=existing,
                        progress=100,
                        message=skip_message,
                    )
                    sharers = _job_users(job)
                    if sharers:
                        # The file is shared, the ownership isn't:
                        # everyone waiting on this job asked for it too.
                        await asyncio.to_thread(
                            _note_download_owners, existing, sharers
                        )
                    await state.connections.broadcast_job(
                        _job_users(job),
                        {
                            'song': song,
                            'progress': 100,
                            'message': skip_message,
                            'status': 'done',
                            'filename': existing,
                        },
                    )
                    return existing

            job['status'] = 'downloading'

            await state.connections.broadcast_job(
                _job_users(job),
                {
                    'song': song,
                    'progress': 0,
                    'message': '',
                    'status': 'downloading',
                },
            )

            def progress(
                pct: float, message: str, provider: Optional[str] = None
            ) -> None:
                j = state.download_jobs.get(song_id)
                if j:
                    j['progress'] = pct
                    j['message'] = message
                    if provider:
                        j['provider'] = provider
                asyncio.run_coroutine_threadsafe(
                    state.connections.broadcast_job(
                        _job_users(j or {}),
                        {
                            'song': song,
                            'progress': pct,
                            'message': message,
                            'provider': provider
                            or (j or {}).get('provider', ''),
                            'status': 'downloading',
                        },
                    ),
                    loop,
                )

            filename = await loop.run_in_executor(
                DOWNLOAD_EXECUTOR,
                lambda: state.downloader.download(
                    song, progress, subdir=subdir
                ),
            )
            job['status'] = 'done'
            job['filename'] = filename
            job['progress'] = 100
            if filename:
                await _record_finished_download(
                    song,
                    filename,
                    playlist_name=playlist_name,
                    spotify_playlist_id=spotify_playlist_id,
                    track_order=track_order,
                    refresh_playlists=refresh_playlists,
                    user_id=user_id,
                )
                others = _job_users(job) - ({user_id} if user_id else set())
                if others:
                    # The leader is recorded inside
                    # _record_finished_download; everyone else waiting
                    # on the shared job claims the same file too.
                    await asyncio.to_thread(
                        _note_download_owners, filename, others
                    )
            invalidate_library_paths_cache()
            await state.connections.broadcast_job(
                _job_users(job),
                {
                    'song': song,
                    'progress': 100,
                    'message': 'Done',
                    'status': 'done',
                    'filename': filename,
                },
            )
            if delay_seconds > 0:
                await asyncio.sleep(delay_seconds)
    except Exception as exc:
        if isinstance(exc, (NoAudioMatchError, TrackTooLongError)):
            # An expected outcome, not a crash: no traceback in the log.
            logger.warning('{} ({})', exc, song_id)
            message = str(exc)
        else:
            logger.exception('Download failed for {}', song_id)
            message = f'Error: {exc}'
        job['status'] = 'error'
        job['message'] = message
        await state.connections.broadcast_job(
            _job_users(job),
            {
                'song': song,
                'progress': 0,
                'message': message,
                'status': 'error',
            },
        )
        raise
    return filename


async def _record_finished_download(
    song: dict[str, Any],
    filename: str,
    *,
    playlist_name: Optional[str],
    spotify_playlist_id: Optional[str],
    track_order: int,
    refresh_playlists: bool,
    user_id: int = 0,
) -> None:
    """Register a downloaded file in the library stores (best effort)."""

    downloader = state.downloader
    if downloader is None:
        return

    def _record() -> set[str]:
        # Ownership first, and every step isolated: a hiccup in one
        # store (a locked sqlite under parallel downloads) must never
        # hide a finished download from the account that ordered it,
        # or from the library listing. Claiming is best-effort itself
        # and never raises.
        _note_download_owner(filename, user_id)
        try:
            affected = _register_download_playlists_on_disk(
                song,
                filename,
                playlist_name=playlist_name,
                spotify_playlist_id=spotify_playlist_id,
                track_order=track_order,
                user_id=user_id,
            )
        except Exception:
            logger.exception('Playlist bookkeeping failed for {}', filename)
            affected = set()
        _record_download_traffic(filename, user_id)
        download_dir = Path(downloader.download_dir)
        slskd_dir = slskd_dir_from_downloader(downloader)
        if state.navidrome_index is not None:
            cache_navidrome_song_id(
                state.settings,
                song,
                filename,
                state.navidrome_index,
                download_dir=download_dir,
                slskd_dir=slskd_dir,
            )
        if state.metadata_cache is not None:
            state.metadata_cache.refresh_stored_path(
                filename, download_dir=download_dir, slskd_dir=slskd_dir
            )
        merge_library_listing_file(library_context(), filename)
        if state.settings.get('cache_cover_art') and state.cover_cache:
            state.cover_cache.refresh_stored_path(
                filename, download_dir=download_dir, slskd_dir=slskd_dir
            )
        return affected

    try:
        affected = await asyncio.to_thread(_record)
    except Exception:
        logger.exception('Could not register {} in the library', filename)
        return
    if refresh_playlists and affected:
        await _schedule_playlist_refresh_after_download(affected)


@router.post('/api/download/url')
async def download_endpoint(
    request: Request,
    url: str = Query(...),
    client_id: str = Query(''),
    client_hints: Optional[dict[str, Any]] = Body(None),
):
    if state.downloader is None:
        raise HTTPException(status_code=500, detail='Downloader not ready')

    # Spotify/YouTube Music network calls: off the event loop, or every
    # other request and WebSocket stalls until they return.
    song = await asyncio.to_thread(
        _song_from_download_request, url, client_hints
    )
    # A retried track from a playlist carries its playlist in the hints,
    # so it lands in that playlist's folder and catalog.
    pl_ctx = await asyncio.to_thread(
        _playlist_context_from_hints, client_hints
    )
    logger.debug(
        'download/url: url={} body={} track_number={!r} year={!r} '
        'release_date={!r} playlist={!r}',
        url[:140],
        'json' if isinstance(client_hints, dict) else 'none',
        song.get('track_number'),
        song.get('year'),
        song.get('release_date'),
        pl_ctx.get('playlist_name'),
    )
    user_id = request_user_id(request)
    song_id = _register_job(song, status='downloading', user_id=user_id)
    await log_activity(
        request, 'download', song_label(song) or url[:200], {'url': url[:500]}
    )

    try:
        filename = await _run_download(
            song,
            song_id,
            subdir=pl_ctx.get('subdir'),
            playlist_name=pl_ctx.get('playlist_name'),
            spotify_playlist_id=pl_ctx.get('spotify_playlist_id'),
            track_order=int(pl_ctx.get('track_order') or 0),
            user_id=user_id,
        )
    except NoAudioMatchError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except TrackTooLongError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc
    return filename


def _m3u_entries_for(
    songs: list[dict[str, Any]],
    resolved: dict[int, Optional[str]],
    *,
    all_tracks: Optional[list[dict[str, Any]]] = None,
    tag_index: Optional[dict[str, str]] = None,
    playlist_subdir: Optional[str] = None,
) -> list[dict[str, Any]]:
    """Build M3U entries for a playlist, in playlist order.

    ``resolved`` maps a batch index to the filename just downloaded, so a
    partially-finished batch still produces a correctly-ordered file.
    When ``all_tracks`` (the playlist's full track list, as the source
    reports it) is given, tracks the library already had are resolved and
    included too — otherwise a playlist's M3U would list only what this
    batch happened to download.
    """

    def _entry(song: dict[str, Any], filename: str) -> dict[str, Any]:
        return {
            'filename': filename,
            'title': song.get('name') or '',
            'artist': ', '.join(song.get('artists') or []),
            'duration': song.get('duration') or 0,
        }

    if not all_tracks:
        # No playlist track list to resolve against: list what the batch
        # downloaded, in playlist order.
        return [
            _entry(song, resolved[index])
            for index, song in enumerate(songs)
            if resolved.get(index)
        ]

    # ``all_tracks`` is the playlist's own full, ordered track list; the
    # batch's downloads are matched onto it by track id, and everything
    # else is resolved against the library so a track downloaded earlier
    # (for another playlist, as an album, as a single) is not lost.
    downloaded = {
        str(songs[index].get('song_id')): filename
        for index, filename in resolved.items()
        if filename and songs[index].get('song_id')
    }
    entries: list[dict[str, Any]] = []
    for song in all_tracks:
        filename = downloaded.get(str(song.get('song_id') or ''))
        if not filename:
            try:
                filename = resolve_track_file(
                    song,
                    downloader=state.downloader,
                    track_index=state.track_index,
                    subdir=playlist_subdir,
                    tag_index=tag_index,
                )
            except Exception:
                logger.opt(exception=True).debug(
                    'Batch M3U: could not resolve {!r}', song.get('name')
                )
                filename = None
        if filename:
            entries.append(_entry(song, filename))
    return entries


async def _write_batch_m3u(
    songs: list[dict[str, Any]],
    resolved: dict[int, Optional[str]],
    playlist_name: str,
    playlist_subdir: str,
    *,
    all_tracks: Optional[list[dict[str, Any]]] = None,
    tag_index: Optional[dict[str, str]] = None,
) -> Optional[Path]:
    entries = _m3u_entries_for(
        songs,
        resolved,
        all_tracks=all_tracks,
        tag_index=tag_index,
        playlist_subdir=playlist_subdir,
    )
    if not entries:
        return None
    # When organize-by-artist/album is on, songs land in those folders
    # instead of the playlist subfolder, so the M3U must go to the legacy
    # Playlists/ directory (playlist_subdir=None) where relative paths
    # still resolve.
    organize = _organize_enabled()
    try:
        m3u_path, _kept = await asyncio.to_thread(
            m3u.write_m3u,
            state.downloader.download_dir,
            playlist_name,
            entries,
            playlist_subdir=None if organize else playlist_subdir,
            slskd_dir=slskd_dir_from_downloader(state.downloader),
        )
    except Exception:
        logger.exception('Failed to write M3U for {!r}', playlist_name)
        return None
    return m3u_path


# A Deezer playlist download is named/covered here the same way a Spotify/
# YouTube Music one is, without teaching Playlist Monitor's own
# parse_playlist_url/fetch_playlist/download_playlist_cover (SOURCE_SPOTIFY/
# SOURCE_YOUTUBE_MUSIC, imported above) about Deezer - Monitor has no Deezer
# watch support, and _resolve_watch_target below still only recognizes a
# Spotify or YouTube Music playlist/artist URL, unaffected by this.
_SOURCE_DEEZER = 'deezer'


def _playlist_target_for_batch(
    playlist_url: str,
) -> Optional[tuple[str, str]]:
    """``(source, id)`` to name and cover a playlist download with - a
    Spotify/YouTube Music playlist via :func:`parse_playlist_url`, or a
    Deezer one (download-only, see :data:`_SOURCE_DEEZER`)."""

    target = parse_playlist_url(playlist_url)
    if target is not None:
        return target
    deezer_parsed = deezer.parse_deezer_url(playlist_url)
    if deezer_parsed is not None and deezer_parsed[0] == 'playlist':
        return _SOURCE_DEEZER, deezer_parsed[1]
    return None


def _fetch_playlist_for_batch(
    source: str, playlist_id: str
) -> tuple[str, list[dict[str, Any]]]:
    if source == _SOURCE_DEEZER:
        return deezer.playlist_info_and_tracks(playlist_id)
    return fetch_playlist(source, playlist_id)


def _download_playlist_cover_for_batch(
    source: str,
    playlist_id: str,
    m3u_path: Path,
    settings: dict[str, Any],
) -> None:
    if source != _SOURCE_DEEZER:
        download_playlist_cover(source, playlist_id, m3u_path, settings)
        return
    if not settings.get('download_cover_art_playlists'):
        return
    try:
        cover_url = deezer.playlist_cover_url_from_id(playlist_id)
    except Exception:
        logger.exception(
            'Failed to resolve Deezer playlist cover art for {}',
            playlist_id,
        )
        return
    if not cover_url:
        return
    try:
        save_playlist_cover(cover_url, m3u_path)
    except Exception:
        logger.exception('Failed to save cover art for {}', m3u_path)


def _save_explicit_playlist_cover(
    cover_url: str, m3u_path: Path, settings: dict[str, Any]
) -> None:
    """Save *cover_url* beside *m3u_path*, when enabled.

    Counterpart to :func:`download_playlist_cover` for a batch that isn't
    backed by a real Spotify/YouTube Music playlist id (e.g. an artist's
    top songs) - the caller already knows the cover to use, so there's no
    playlist to re-fetch it from. Gated by the same
    ``download_cover_art_playlists`` setting.
    """

    if not settings.get('download_cover_art_playlists'):
        return
    try:
        save_playlist_cover(cover_url, m3u_path)
    except Exception:
        logger.exception('Failed to save cover art for {}', m3u_path)


async def _fetch_playlist_cover(
    target: Optional[tuple[str, str]],
    playlist_name: Optional[str],
    playlist_subdir: Optional[str],
    cover_url: Optional[str] = None,
) -> None:
    """Save the playlist's own cover art beside where its M3U will go.

    Resolving the M3U path without writing it (see ``m3u.m3u_path_for``)
    means the cover can land before the first track does. No-ops when
    the setting is off, or when the download didn't come from a
    playlist link (unless the caller passed an explicit ``cover_url``).
    """

    if (
        (target is None and not cover_url)
        or not playlist_name
        or state.downloader is None
    ):
        return
    # With organize-by-artist/album on, tracks are spread across those
    # folders and the M3U goes to the legacy Playlists/ directory — the
    # cover follows it, so both stay together.
    subdir = None if _organize_enabled() else playlist_subdir
    m3u_path = m3u.m3u_path_for(
        Path(state.downloader.download_dir),
        playlist_name,
        playlist_subdir=subdir,
    )
    if target is not None:
        await asyncio.to_thread(
            _download_playlist_cover_for_batch,
            *target,
            m3u_path,
            state.settings,
        )
    else:
        await asyncio.to_thread(
            _save_explicit_playlist_cover,
            cover_url,
            m3u_path,
            state.settings,
        )


async def _process_batch(
    songs: list[dict[str, Any]],
    job_ids: list[str],
    playlist_url: str,
    generate_m3u: bool,
    playlist_name: Optional[str] = None,
    *,
    batch_id: Optional[int] = None,
    cover_url: Optional[str] = None,
    user_id: int = 0,
) -> None:
    # Resolve the playlist name up-front so all tracks land in a single,
    # per-playlist sub-folder. Loose batches (e.g. albums or unrelated
    # tracks) keep the legacy flat layout under download_dir. A caller
    # without a Spotify/YouTube Music/Deezer playlist_url (e.g. a CSV
    # library import) can instead pass playlist_name directly.
    playlist_subdir: Optional[str] = None
    spotify_playlist_id: Optional[str] = None
    spotify_track_count = 0
    # The playlist's own full track list, as the source reports it. The
    # M3U is built from this (not just the batch), so songs the library
    # already had are listed too.
    all_tracks: list[dict[str, Any]] = []
    target = _playlist_target_for_batch(playlist_url) if playlist_url else None
    if target is not None:
        try:
            playlist_name, tracks = await asyncio.to_thread(
                _fetch_playlist_for_batch, *target
            )
            all_tracks = tracks
            playlist_subdir = m3u.sanitize_playlist_name(playlist_name)
            if target[0] == SOURCE_SPOTIFY:
                spotify_playlist_id = target[1]
                spotify_track_count = len(tracks)
                # Fresh Spotify track list for the playlist batch reports.
                if state.playlist_spotify_cache is not None:
                    await asyncio.to_thread(
                        state.playlist_spotify_cache.store,
                        spotify_playlist_id,
                        playlist_name,
                        tracks,
                    )
        except Exception:
            logger.exception(
                'Failed to resolve playlist name for {}', playlist_url
            )
    elif playlist_name:
        playlist_subdir = m3u.sanitize_playlist_name(playlist_name)

    if batch_id is not None and playlist_name and state.playlist_batch_store:
        await asyncio.to_thread(
            state.playlist_batch_store.update_batch_name,
            batch_id,
            playlist_name,
        )

    # A per-song delay only makes sense when there's a "next" song to
    # wait for; skip it entirely for a lone track so a single download
    # never waits around for nothing.
    delay_seconds = (
        state.settings.get('download_delay_seconds', 0)
        if len(songs) > 1
        else 0
    )

    wants_m3u = bool(generate_m3u and playlist_subdir and playlist_name)
    # Whole-library artist/title index (built once), so the M3U can list
    # songs the library already has from an earlier download. Only needed
    # for a real playlist with tracks the source reported.
    tag_index: Optional[dict[str, str]] = None
    if wants_m3u and all_tracks:
        try:
            tag_index = await asyncio.to_thread(
                build_library_song_index, library_context()
            )
        except Exception:
            logger.opt(exception=True).debug(
                'Batch M3U: library song index build failed'
            )
    if wants_m3u:
        # Before the first track, so the folder already looks like the
        # playlist while it fills up (and a media server scanning
        # mid-download finds the artwork).
        await _fetch_playlist_cover(
            target, playlist_name, playlist_subdir, cover_url
        )
    # Filename per song index, filled in as downloads land. The M3U is
    # rewritten from this after every completed download, so the playlist
    # grows as it downloads instead of appearing all at once at the end,
    # and one slow or hung track can't hold up what's already on disk.
    resolved: dict[int, Optional[str]] = {}
    m3u_lock = asyncio.Lock()

    async def _bounded(index: int, song: dict[str, Any], song_id: str) -> None:
        try:
            filename = await _run_download(
                song,
                song_id,
                subdir=playlist_subdir,
                delay_seconds=delay_seconds,
                playlist_name=playlist_name,
                spotify_playlist_id=spotify_playlist_id,
                track_order=int(song.get('downtify_track_order') or index),
                refresh_playlists=False,
                user_id=user_id,
            )
        except Exception:
            filename = None
        resolved[index] = filename
        if not (filename and wants_m3u):
            return
        # Serialized so concurrent downloads can't interleave writes to
        # the same file.
        async with m3u_lock:
            await _write_batch_m3u(
                songs,
                resolved,
                playlist_name,
                playlist_subdir,
                all_tracks=all_tracks,
                tag_index=tag_index,
            )

    await asyncio.gather(
        *[
            _bounded(i, s, sid)
            for i, (s, sid) in enumerate(zip(songs, job_ids))
        ],
        return_exceptions=False,
    )

    if wants_m3u:
        await _write_batch_m3u(
            songs,
            resolved,
            playlist_name,
            playlist_subdir,
            all_tracks=all_tracks,
            tag_index=tag_index,
        )

    await _finish_playlist_batch(
        songs,
        resolved,
        batch_id=batch_id,
        playlist_name=playlist_name,
        spotify_playlist_id=spotify_playlist_id,
        spotify_track_count=spotify_track_count,
        generate_m3u=generate_m3u,
    )


async def _finish_playlist_batch(
    songs: list[dict[str, Any]],
    resolved: dict[int, Optional[str]],
    *,
    batch_id: Optional[int],
    playlist_name: Optional[str],
    spotify_playlist_id: Optional[str],
    spotify_track_count: int,
    generate_m3u: bool,
) -> None:
    """Close a playlist batch: record its outcome, relink the playlist's
    on-disk tracks in the catalog and refresh its M3U/Navidrome playlist.

    A batch can cover only part of a Spotify playlist (e.g. downloading
    just the missing tracks), so the catalog is rebuilt from every track
    of the playlist already in the library before the refresh — otherwise
    the refreshed playlist would only contain this batch's tracks.
    """

    succeeded = sum(1 for filename in resolved.values() if filename)
    failed = len(songs) - succeeded
    if playlist_name:
        logger.info(
            'playlist batch: name={!r} downloaded={}/{} failed={}',
            playlist_name,
            succeeded,
            len(songs),
            failed,
        )
    if batch_id is not None and state.playlist_batch_store is not None:
        await asyncio.to_thread(
            state.playlist_batch_store.finish_batch,
            batch_id,
            succeeded,
            failed,
            status='complete' if failed == 0 else 'incomplete',
        )
    if not playlist_name or state.playlist_catalog is None:
        return
    if spotify_track_count and len(songs) < spotify_track_count:
        logger.info(
            'playlist batch: partial run {}/{} tracks for {!r}; rebuilding '
            'the catalog from the library before the playlist refresh',
            len(songs),
            spotify_track_count,
            playlist_name,
        )

    def _catalog_batch() -> None:
        catalog = state.playlist_catalog
        downloader = state.downloader
        if catalog is None or downloader is None:
            return
        download_dir = Path(downloader.download_dir)
        slskd_dir = slskd_dir_from_downloader(downloader)
        if spotify_playlist_id:
            catalog.ensure_playlist(
                playlist_name, spotify_id=spotify_playlist_id
            )
        for index, song in enumerate(songs):
            filename = resolved.get(index)
            full = (
                locate_library_file(filename, download_dir, slskd_dir)
                if filename
                else None
            )
            if full is None:
                continue
            catalog.upsert_track(
                playlist_name,
                song,
                filename,
                full,
                track_order=int(song.get('downtify_track_order') or index),
            )
        if spotify_playlist_id:
            linked = _rebuild_playlist_catalog_from_library(
                playlist_name, spotify_playlist_id
            )
            logger.info(
                'playlist batch: catalog has {} on-disk track(s) for {!r}',
                linked,
                playlist_name,
            )

    await asyncio.to_thread(_catalog_batch)

    do_m3u, do_navidrome = playlist_refresh_enabled(state.settings)
    if not generate_m3u:
        do_m3u = False
    if do_m3u or do_navidrome:
        await asyncio.to_thread(
            refresh_playlists_after_moves,
            {playlist_name},
            settings=state.settings,
            downloader=state.downloader,
            playlist_catalog=state.playlist_catalog,
            track_index=state.track_index,
            monitor_db=state.monitor_db,
            navidrome_index=state.navidrome_index,
            navidrome_scan=bool(
                _effective_navidrome_settings(state.settings).get(
                    'scan_after_download', True
                )
            ),
            playlist_spotify_cache=state.playlist_spotify_cache,
            cover_cache=state.cover_cache,
            metadata_cache=state.metadata_cache,
        )


def _rebuild_playlist_catalog_from_library(
    playlist_name: str,
    spotify_playlist_id: str,
) -> int:
    """Link every on-disk Spotify playlist track into the catalog (upsert)."""

    if (
        state.playlist_catalog is None
        or state.downloader is None
        or state.track_index is None
    ):
        return 0
    sid = str(spotify_playlist_id or '').strip()
    if not sid:
        return 0
    try:
        resolved_name, tracks = _fetch_playlist_tracks(sid)
    except Exception:
        logger.opt(exception=True).warning(
            'playlist batch: catalog rebuild failed for {!r}',
            playlist_name,
        )
        return 0
    pl_name = str(resolved_name or playlist_name or '').strip()
    if not pl_name:
        return 0

    subdir = _playlist_subdir_for_name(pl_name)
    catalog_filenames = _catalog_filenames_for_playlist(pl_name, sid)
    dl_dir = Path(state.downloader.download_dir)
    slskd = slskd_dir_from_downloader(state.downloader)
    state.playlist_catalog.ensure_playlist(pl_name, spotify_id=sid)

    linked = 0
    for index, track in enumerate(tracks):
        filename: Optional[str] = None
        full: Optional[Path] = None
        hit = resolve_existing_download(
            state.downloader,
            track,
            subdir=subdir,
            track_index=state.track_index,
        )
        if hit:
            filename = hit[0]
            full = locate_library_file(filename, dl_dir, slskd)
        else:
            tid = normalize_spotify_track_id(track)
            if tid and catalog_filenames:
                filename = str(catalog_filenames.get(tid) or '').strip()
                if filename:
                    full = locate_library_file(filename, dl_dir, slskd)
        if filename and full is not None:
            state.playlist_catalog.upsert_track(
                pl_name, track, filename, full, track_order=index
            )
            linked += 1
    return linked


def _playlist_subdir_for_name(playlist_name: str) -> str:
    return m3u.sanitize_playlist_name(playlist_name)


def _catalog_filenames_for_playlist(
    playlist_name: str,
    spotify_playlist_id: str,
) -> dict[str, str]:
    """Map Spotify track id to on-disk filename from the playlist catalog."""

    if state.playlist_catalog is None:
        return {}
    sid = str(spotify_playlist_id or '').strip()
    names: list[str] = []
    if str(playlist_name or '').strip():
        names.append(str(playlist_name).strip())
    for row in state.playlist_catalog.list_playlists_with_spotify_id():
        if sid and row['spotify_id'] != sid:
            continue
        name = str(row['name'] or '').strip()
        if name and name not in names:
            names.append(name)
    by_tid: dict[str, str] = {}
    for name in names:
        for row in state.playlist_catalog.list_tracks(name):
            tid = str(row.get('track_spotify_id') or '').strip()
            filename = str(row.get('filename') or '').strip()
            if tid and filename:
                by_tid[tid] = filename
    return by_tid


def _song_row_hint(song: dict[str, Any]) -> dict[str, Any]:
    return {
        'song_id': song.get('song_id'),
        'name': song.get('name') or '',
        'artists': list(song.get('artists') or []),
        'album_name': song.get('album_name') or '',
        'cover_url': song.get('cover_url') or '',
        'url': song.get('url') or '',
        'duration': song.get('duration') or 0,
    }


def _batch_scope(request: Optional[Request]) -> Optional[int]:
    """Whose batches *request* sees: ``None`` (everyone's) for an admin."""

    return None if request_is_admin(request) else request_user_id(request)


def _known_spotify_playlist_sources(
    user_id: Optional[int] = None,
) -> dict[str, dict[str, Any]]:
    """Merge Spotify playlist ids from batch store, catalog, and monitor.

    YouTube playlist ids (a pasted YT Music playlist also lives in the
    stores) are filtered out - the Spotify embed endpoint only serves
    Spotify ids and answering for them just produces retries. With
    *user_id*: only their batches and playlists (monitor watches are the
    admin's). Without it: everything.
    """

    sources: dict[str, dict[str, Any]] = {}

    def _add(sid: str, entry: dict[str, Any]) -> None:
        if not is_spotify_playlist_id(sid):
            return
        sources.setdefault(sid, entry)

    if state.playlist_batch_store is not None:
        for batch in state.playlist_batch_store.list_latest_batches(user_id):
            sid = str(batch['spotify_playlist_id'] or '').strip()
            if not sid:
                continue
            _add(
                sid,
                {
                    'playlist_name': batch['playlist_name'],
                    'playlist_url': batch['playlist_url'],
                    'expected_hint': int(batch.get('expected_count') or 0),
                    'batch': batch,
                },
            )
    if state.playlist_catalog is not None:
        owners: dict[str, int] = {}
        if user_id is not None and state.playlist_catalog is not None:
            try:
                owners = {
                    str(name or '').strip().casefold(): int(uid or 0)
                    for name, uid in state.playlist_catalog.playlist_owner_map().items()
                }
            except Exception:
                logger.opt(exception=True).debug(
                    'Could not read playlist owners'
                )
        for row in state.playlist_catalog.list_playlists_with_spotify_id():
            sid = str(row['spotify_id'] or '').strip()
            if not sid or not is_spotify_playlist_id(sid):
                continue
            if (
                user_id is not None
                and owners.get(str(row['name'] or '').strip().casefold(), 0)
                != user_id
            ):
                continue
            if sid not in sources:
                sources[sid] = {
                    'playlist_name': row['name'],
                    'playlist_url': f'https://open.spotify.com/playlist/{sid}',
                    'expected_hint': int(row.get('track_count') or 0),
                    'batch': None,
                }
            else:
                entry = sources[sid]
                if not entry.get('playlist_name'):
                    entry['playlist_name'] = row['name']
                if int(row.get('track_count') or 0) > int(
                    entry.get('expected_hint') or 0
                ):
                    entry['expected_hint'] = int(row['track_count'])
        monitor_by_name: dict[str, Any] = {}
        if state.monitor_db is not None and user_id is None:
            for pl in state.monitor_db.list_playlists():
                name = str(pl.name or '').strip()
                if name:
                    monitor_by_name[name] = pl
        batch_by_name: dict[str, dict[str, Any]] = {}
        if state.playlist_batch_store is not None:
            for batch in state.playlist_batch_store.list_latest_batches(
                user_id
            ):
                name = str(batch.get('playlist_name') or '').strip()
                if name:
                    batch_by_name[name] = batch
        for name in state.playlist_catalog.list_playlist_names():
            if (
                user_id is not None
                and owners.get(name.strip().casefold(), 0) != user_id
            ):
                continue
            sid = state.playlist_catalog.spotify_id_for_playlist(name) or ''
            if not sid:
                mon = monitor_by_name.get(name)
                if mon and mon.spotify_id:
                    sid = str(mon.spotify_id).strip()
                else:
                    batch = batch_by_name.get(name)
                    if batch:
                        sid = str(batch['spotify_playlist_id']).strip()
            if not sid or not is_spotify_playlist_id(sid) or sid in sources:
                continue
            track_count = len(state.playlist_catalog.list_tracks(name))
            sources[sid] = {
                'playlist_name': name,
                'playlist_url': f'https://open.spotify.com/playlist/{sid}',
                'expected_hint': track_count,
                'batch': batch_by_name.get(name),
            }
    if state.monitor_db is not None and user_id is None:
        for pl in state.monitor_db.list_playlists():
            sid = str(pl.spotify_id or '').strip()
            if not sid or not is_spotify_playlist_id(sid):
                continue
            if sid not in sources:
                sources[sid] = {
                    'playlist_name': pl.name,
                    'playlist_url': pl.url,
                    'expected_hint': int(pl.last_track_count or 0),
                    'batch': None,
                }
            else:
                entry = sources[sid]
                if pl.name and (
                    not entry.get('playlist_name')
                    or entry['playlist_name'] == sid
                ):
                    entry['playlist_name'] = pl.name
                if pl.url:
                    entry['playlist_url'] = pl.url
    return sources


def known_spotify_playlist_ids() -> list[str]:
    """Spotify playlist ids tracked by batches, catalog, and monitor."""

    return list(_known_spotify_playlist_sources().keys())


def _resolve_playlist_batch_status(
    *,
    missing_count: int,
    active_count: int,
    expected_count: int,
    batch: Optional[dict[str, Any]] = None,
) -> str:
    """Derive batch status from live counts (not stale DB status alone)."""

    if active_count > 0:
        return 'in_progress'
    if missing_count == 0 and expected_count > 0:
        if batch is not None and state.playlist_batch_store is not None:
            if batch.get('status') != 'complete':
                state.playlist_batch_store.mark_complete(batch['id'])
        return 'complete'
    if missing_count > 0:
        return 'incomplete'
    if batch is not None and batch.get('status') == 'complete':
        return 'complete'
    if batch is not None:
        return str(batch.get('status') or 'incomplete')
    return 'complete'


def _playlist_batch_summary(
    spotify_id: str,
    playlist_name: str,
    playlist_url: str,
    *,
    batch: Optional[dict[str, Any]] = None,
    expected_hint: int = 0,
) -> dict[str, Any]:
    """Counts from cached Spotify track list + library scan."""

    active_count = active_queue_count_for_playlist(
        spotify_id, state.download_jobs
    )

    if state.playlist_catalog is not None:
        for row in state.playlist_catalog.list_playlists_with_spotify_id():
            if row['spotify_id'] != spotify_id:
                continue
            if not playlist_name or playlist_name == spotify_id:
                playlist_name = str(row['name'])
            break

    cached_name: Optional[str] = None
    cached_tracks: Optional[list[dict[str, Any]]] = None
    if state.playlist_spotify_cache is not None:
        hit = state.playlist_spotify_cache.get(spotify_id)
        if hit is not None:
            cached_name, cached_tracks = hit

    if cached_tracks is not None:
        if cached_name:
            playlist_name = cached_name
        expected_count = len(cached_tracks)
        downloaded_count = 0
        missing_count = expected_count
        if (
            cached_tracks
            and state.downloader is not None
            and state.track_index is not None
        ):
            subdir = _playlist_subdir_for_name(playlist_name)
            catalog_filenames = _catalog_filenames_for_playlist(
                playlist_name,
                spotify_id,
            )
            downloaded_count, missing_tracks = split_tracks_by_library(
                cached_tracks,
                downloader=state.downloader,
                track_index=state.track_index,
                subdir=subdir,
                catalog_filenames=catalog_filenames,
            )
            missing_count = len(missing_tracks)
        status = _resolve_playlist_batch_status(
            missing_count=missing_count,
            active_count=active_count,
            expected_count=expected_count,
            batch=batch,
        )
        if status == 'complete':
            missing_count = 0
        return {
            'batch_id': batch['id'] if batch else None,
            'spotify_playlist_id': spotify_id,
            'playlist_name': playlist_name,
            'playlist_url': playlist_url,
            'expected_count': expected_count,
            'downloaded_count': downloaded_count,
            'missing_count': missing_count,
            'missing_tracks': [],
            'active_in_queue': active_count,
            'status': status,
            'source': 'cache',
            'started_at': batch.get('started_at') if batch else None,
            'finished_at': batch.get('finished_at') if batch else None,
        }

    downloaded_count = 0
    if state.playlist_catalog is not None:
        for row in state.playlist_catalog.list_playlists_with_spotify_id():
            if row['spotify_id'] != spotify_id:
                continue
            downloaded_count = int(row.get('track_count') or 0)
            break
        if not downloaded_count and playlist_name:
            downloaded_count = len(
                state.playlist_catalog.list_tracks(playlist_name)
            )

    expected_count = max(int(expected_hint or 0), 0)
    if batch is not None:
        expected_count = max(
            expected_count, int(batch.get('expected_count') or 0)
        )

    status = 'in_progress' if active_count > 0 else 'pending'
    return {
        'batch_id': batch['id'] if batch else None,
        'spotify_playlist_id': spotify_id,
        'playlist_name': playlist_name,
        'playlist_url': playlist_url,
        'expected_count': expected_count,
        'downloaded_count': downloaded_count,
        'missing_count': 0,
        'missing_tracks': [],
        'active_in_queue': active_count,
        'status': status,
        'source': 'pending',
        'started_at': batch.get('started_at') if batch else None,
        'finished_at': batch.get('finished_at') if batch else None,
    }


def _playlist_completeness_report(
    spotify_id: str,
    playlist_name: str,
    playlist_url: str,
    *,
    batch: Optional[dict[str, Any]] = None,
    expected_hint: int = 0,
    include_missing_tracks: bool = True,
    refresh: bool = False,
    user_id: Optional[int] = None,
) -> dict[str, Any]:
    tracks: list[dict[str, Any]] = []
    try:
        fetched_name, tracks = _fetch_playlist_tracks(
            spotify_id, refresh=refresh
        )
        if fetched_name:
            playlist_name = fetched_name
    except Exception:
        logger.opt(exception=True).debug(
            'playlist batch: Spotify fetch failed for {}',
            spotify_id,
        )

    subdir = _playlist_subdir_for_name(playlist_name)
    catalog_filenames = _catalog_filenames_for_playlist(
        playlist_name,
        spotify_id,
    )
    owned: Optional[set[str]] = None
    if user_id is not None and state.track_owners is not None:
        owned = state.track_owners.owned_keys(user_id)
    downloaded_count, missing_tracks = split_tracks_by_library(
        tracks,
        downloader=state.downloader,
        track_index=state.track_index,
        subdir=subdir,
        catalog_filenames=catalog_filenames,
        owned_keys=owned,
    )
    expected_count = len(tracks) or int(expected_hint or 0)
    if batch is not None and not expected_count:
        expected_count = int(batch.get('expected_count') or 0)
    missing_count = len(missing_tracks)
    if not tracks and expected_count > downloaded_count:
        missing_count = expected_count - downloaded_count

    active_count = active_queue_count_for_playlist(
        spotify_id, state.download_jobs, user_id
    )

    status = _resolve_playlist_batch_status(
        missing_count=missing_count,
        active_count=active_count,
        expected_count=expected_count,
        batch=batch,
    )

    track_hints = (
        [_song_row_hint(t) for t in missing_tracks]
        if include_missing_tracks
        else []
    )

    return {
        'batch_id': batch['id'] if batch else None,
        'spotify_playlist_id': spotify_id,
        'playlist_name': playlist_name,
        'playlist_url': playlist_url,
        'expected_count': expected_count,
        'downloaded_count': downloaded_count,
        'missing_count': missing_count,
        'missing_tracks': track_hints,
        'active_in_queue': active_count,
        'status': status,
        'source': 'spotify',
        'started_at': batch.get('started_at') if batch else None,
        'finished_at': batch.get('finished_at') if batch else None,
    }


def _report_for_spotify_playlist(
    spotify_playlist_id: str,
    *,
    mode: str = 'estimate',
    include_missing_tracks: bool = True,
    refresh: bool = False,
    user_id: Optional[int] = None,
) -> Optional[dict[str, Any]]:
    sid = str(spotify_playlist_id or '').strip()
    if not sid:
        return None
    meta = _known_spotify_playlist_sources(user_id).get(sid)
    if meta is None:
        return None
    batch = meta.get('batch')
    name = str(meta.get('playlist_name') or sid)
    url = str(
        meta.get('playlist_url') or f'https://open.spotify.com/playlist/{sid}'
    )
    hint = int(meta.get('expected_hint') or 0)
    if mode == 'spotify':
        return _playlist_completeness_report(
            sid,
            name,
            url,
            batch=batch if isinstance(batch, dict) else None,
            expected_hint=hint,
            include_missing_tracks=include_missing_tracks,
            refresh=refresh,
            user_id=user_id,
        )
    report = _playlist_batch_summary(
        sid,
        name,
        url,
        batch=batch if isinstance(batch, dict) else None,
        expected_hint=hint,
    )
    return report


def _build_playlist_batch_reports(
    *,
    include_tracks: bool = False,
    user_id: Optional[int] = None,
) -> list[dict[str, Any]]:
    if state.downloader is None or state.track_index is None:
        return []

    builder = (
        _playlist_completeness_report
        if include_tracks
        else _playlist_batch_summary
    )
    reports: list[dict[str, Any]] = []
    for sid, meta in _known_spotify_playlist_sources(user_id).items():
        batch = meta.get('batch')
        kwargs: dict[str, Any] = (
            {'user_id': user_id}
            if builder is _playlist_completeness_report
            else {}
        )
        reports.append(
            builder(
                sid,
                str(meta.get('playlist_name') or sid),
                str(
                    meta.get('playlist_url')
                    or f'https://open.spotify.com/playlist/{sid}'
                ),
                batch=batch if isinstance(batch, dict) else None,
                expected_hint=int(meta.get('expected_hint') or 0),
                **kwargs,
            )
        )
    reports.sort(
        key=lambda row: (
            row.get('status') != 'complete',
            row.get('playlist_name') or '',
        )
    )
    return reports


def collect_playlist_batch_sync_rows() -> list[dict[str, Any]]:
    """Playlist rows for startup batch registration."""

    rows: list[dict[str, Any]] = []
    for sid, meta in _known_spotify_playlist_sources().items():
        rows.append({
            'spotify_id': sid,
            'name': str(meta.get('playlist_name') or sid),
            'url': str(
                meta.get('playlist_url')
                or f'https://open.spotify.com/playlist/{sid}'
            ),
            'track_count': int(meta.get('expected_hint') or 0),
        })
    return rows


def _build_incomplete_playlist_reports(
    *,
    include_tracks: bool = False,
    user_id: Optional[int] = None,
) -> list[dict[str, Any]]:
    """Playlists that still need work (missing tracks or active queue jobs)."""

    return [
        row
        for row in _build_playlist_batch_reports(
            include_tracks=include_tracks, user_id=user_id
        )
        if row['status'] != 'complete'
    ]


def _missing_tracks_for_playlist(
    spotify_playlist_id: str,
    *,
    user_id: Optional[int] = None,
) -> tuple[str, str, list[dict[str, Any]]]:
    if state.downloader is None or state.track_index is None:
        raise HTTPException(status_code=500, detail='Downloader not ready')

    sid = str(spotify_playlist_id or '').strip()
    if not sid:
        raise HTTPException(
            status_code=400, detail='spotify_playlist_id required'
        )

    try:
        playlist_name, tracks = _fetch_playlist_tracks(sid)
    except Exception as exc:
        raise HTTPException(
            status_code=502, detail='Failed to fetch playlist from Spotify'
        ) from exc

    subdir = _playlist_subdir_for_name(playlist_name)
    catalog_filenames = _catalog_filenames_for_playlist(
        playlist_name,
        sid,
    )
    owned: Optional[set[str]] = None
    if user_id is not None and state.track_owners is not None:
        owned = state.track_owners.owned_keys(user_id)
    _downloaded, missing = split_tracks_by_library(
        tracks,
        downloader=state.downloader,
        track_index=state.track_index,
        subdir=subdir,
        catalog_filenames=catalog_filenames,
        owned_keys=owned,
    )
    playlist_url = f'https://open.spotify.com/playlist/{sid}'
    return playlist_name, playlist_url, missing


async def _submit_playlist_batch(
    songs: list[dict[str, Any]],
    playlist_url: str,
    *,
    generate_m3u: bool,
    batch_id: Optional[int] = None,
    playlist_name: Optional[str] = None,
    cover_url: Optional[str] = None,
    user_id: int = 0,
) -> dict[str, Any]:
    valid_songs: list[dict[str, Any]] = []
    job_ids: list[str] = []
    for song in songs:
        if not isinstance(song, dict):
            continue
        song_id = _register_job(song, status='queued', user_id=user_id)
        valid_songs.append(song)
        job_ids.append(song_id)

    if not valid_songs:
        raise HTTPException(status_code=400, detail='No valid songs in batch')

    # One frame for the whole batch. Per-row ``queued`` events made a
    # large playlist or CSV rebuild the queue once per track.
    await state.connections.broadcast({'type': 'queue_reload'})

    task = spawn_task(
        _process_batch(
            valid_songs,
            job_ids,
            playlist_url,
            generate_m3u,
            playlist_name,
            batch_id=batch_id,
            cover_url=cover_url,
            user_id=user_id,
        ),
        name='playlist-batch',
    )

    def _log_batch_failure(t: asyncio.Task) -> None:
        if t.cancelled():
            return
        exc = t.exception()
        if exc is not None:
            logger.opt(exception=exc).error('Batch processing crashed')

    task.add_done_callback(_log_batch_failure)
    return {'job_ids': job_ids, 'count': len(job_ids)}


@router.post('/api/download/batch')
async def download_batch_endpoint(request: Request) -> dict[str, Any]:
    if state.downloader is None:
        raise HTTPException(status_code=500, detail='Downloader not ready')

    try:
        payload = await request.json()
    except Exception as exc:
        raise HTTPException(status_code=400, detail='Invalid JSON') from exc

    songs = payload.get('songs') or []
    if not isinstance(songs, list) or not songs:
        raise HTTPException(
            status_code=400, detail='songs must be a non-empty list'
        )
    playlist_url = str(payload.get('playlist_url') or '')
    generate_m3u = bool(payload.get('generate_m3u', True))
    # No real Spotify/YouTube Music playlist id backs this batch (e.g. an
    # artist's top songs) - the caller names the playlist and its cover
    # directly instead of us deriving them from playlist_url.
    playlist_name = str(payload.get('playlist_name') or '') or None
    cover_url = str(payload.get('cover_url') or '') or None
    first_song = next((s for s in songs if isinstance(s, dict)), {})
    await log_activity(
        request,
        'download',
        playlist_name
        or str(first_song.get('album_name') or '')
        or song_label(first_song),
        {'songs': len(songs), 'url': playlist_url[:500]},
    )

    # A Spotify playlist download is tracked as a playlist batch, so an
    # incomplete one can be finished later (see /api/playlists/incomplete).
    batch_id: Optional[int] = None
    target = parse_playlist_url(playlist_url) if playlist_url else None
    if (
        target is not None
        and target[0] == SOURCE_SPOTIFY
        and state.playlist_batch_store is not None
    ):
        first = next((s for s in songs if isinstance(s, dict)), {})
        batch_user_id = request_user_id(request)
        batch_id = await asyncio.to_thread(
            state.playlist_batch_store.start_batch,
            target[1],
            str(first.get('album_name') or '').strip() or target[1],
            playlist_url,
            len(songs),
            user_id=batch_user_id,
        )

    return await _submit_playlist_batch(
        songs,
        playlist_url,
        generate_m3u=generate_m3u,
        batch_id=batch_id,
        playlist_name=playlist_name,
        cover_url=cover_url,
        user_id=request_user_id(request),
    )


def _scope_csv_song_ids(songs: list[dict[str, Any]]) -> None:
    """Replace per-file ``csv:N`` ids with ids unique to this import.

    ``parse_library_csv`` numbers from zero on every call. Two imports
    would otherwise share ``csv:0`` and overwrite one ``download_jobs``
    entry. The token is only a queue key; it is not a Spotify track id.
    """
    token = uuid.uuid4().hex[:12]
    for index, song in enumerate(songs):
        song['song_id'] = f'csv:{token}:{index}'


@router.post('/api/download/csv')
async def download_csv_endpoint(request: Request) -> dict[str, Any]:
    """Import a library-export CSV (Soundiiz, TuneMyMusic, Exportify, ...).

    Body: ``{"csv": "<raw file text>", "playlist_name": "...",
    "generate_m3u": true}``. The CSV is read client-side and sent as
    plain text in the JSON body rather than as a multipart upload, to
    match every other endpoint here and avoid an extra dependency.

    Each row is resolved the same way a free-text search would be, via
    :func:`providers.find_match` inside :meth:`Downloader.download` -
    there is no Spotify/YouTube URL per row, only a title, artist, and
    album when the CSV has it.
    """
    if state.downloader is None:
        raise HTTPException(status_code=500, detail='Downloader not ready')

    try:
        payload = await request.json()
    except Exception as exc:
        raise HTTPException(status_code=400, detail='Invalid JSON') from exc
    if not isinstance(payload, dict):
        raise HTTPException(status_code=400, detail='Invalid payload')

    csv_text = payload.get('csv')
    if not isinstance(csv_text, str) or not csv_text.strip():
        raise HTTPException(
            status_code=400, detail='csv must be a non-empty string'
        )

    try:
        songs = await asyncio.to_thread(
            library_import.parse_library_csv, csv_text
        )
    except library_import.LibraryCsvError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    playlist_name = (
        str(payload.get('playlist_name') or '').strip() or 'Imported Library'
    )
    generate_m3u = bool(payload.get('generate_m3u', True))
    # Parser ids restart at csv:0 on every file. The queue is keyed by
    # song_id, so a second import would replace the first import's jobs
    # and the badge /queue tabs would count the longer file only.
    _scope_csv_song_ids(songs)

    user_id = request_user_id(request)
    job_ids: list[str] = []
    for song in songs:
        song_id = _register_job(song, status='queued', user_id=user_id)
        job_ids.append(song_id)

    # Same single reload as _submit_playlist_batch. The rows are already
    # in download_jobs; clients fetch them with GET /api/queue.
    await state.connections.broadcast({'type': 'queue_reload'})

    task = spawn_task(
        _process_batch(
            songs,
            job_ids,
            '',
            generate_m3u,
            playlist_name=playlist_name,
            user_id=user_id,
        ),
        name='csv-batch',
    )

    def _log_batch_failure(t: asyncio.Task) -> None:
        if t.cancelled():
            return
        exc = t.exception()
        if exc is not None:
            logger.opt(exception=exc).error('CSV batch processing crashed')

    task.add_done_callback(_log_batch_failure)
    return {
        'job_ids': job_ids,
        'count': len(job_ids),
        'playlist_name': playlist_name,
    }


def _songs_for_album_download(url: str) -> list[dict[str, Any]]:
    youtube_parsed = providers.parse_youtube_url(url)
    if youtube_parsed is None or youtube_parsed[0] != 'album':
        raise HTTPException(
            status_code=400,
            detail='Only YouTube Music album/browse URLs are supported here',
        )
    _, browse_id = youtube_parsed
    songs = providers.album_tracks_from_browse_id(browse_id)
    if not songs:
        raise HTTPException(
            status_code=404, detail='Album not found or has no tracks'
        )
    return songs


@router.post('/api/download/album')
async def download_album_endpoint(
    request: Request, url: str = Query(...)
) -> dict[str, str]:
    """Download every track of a YouTube Music album/browse URL.

    Unlike ``POST /api/download/url`` (which only accepts a single video URL
    and therefore re-resolves catalog metadata independently, per track),
    this resolves the album's full tracklist once via
    :func:`providers.album_tracks_from_browse_id` and downloads each track
    using that shared, already-consistent metadata (track number, album
    name/artist, cover, year). This matters for compilations/"best of"
    albums, whose tracks would otherwise be re-matched one video at a time
    and can drift to their original, differently-tagged source album.

    Returns a mapping of ``song_id -> downloaded filename`` for every track
    that downloaded successfully (failed tracks are omitted, not raised).
    """
    if state.downloader is None:
        raise HTTPException(status_code=500, detail='Downloader not ready')

    songs = await asyncio.to_thread(_songs_for_album_download, url)
    first_song = songs[0] if songs else {}
    await log_activity(
        request,
        'download',
        str(first_song.get('album_name') or '') or url[:200],
        {'songs': len(songs), 'url': url[:500]},
    )
    # See _process_batch: only meaningful when there's a "next" track to
    # wait for, so a single-track album never waits around for nothing.
    delay_seconds = (
        state.settings.get('download_delay_seconds', 0)
        if len(songs) > 1
        else 0
    )

    user_id = request_user_id(request)

    async def _one(song: dict[str, Any]) -> tuple[str, Optional[str]]:
        song_id = str(song.get('song_id') or '')
        if not song_id:
            return '', None
        job_id = _register_job(song, status='downloading', user_id=user_id)
        try:
            filename = await _run_download(
                song, job_id, delay_seconds=delay_seconds, user_id=user_id
            )
        except Exception:
            logger.exception('Album track download failed for {}', song_id)
            return song_id, None
        return song_id, filename

    results = await asyncio.gather(*(_one(song) for song in songs))
    return {
        song_id: filename
        for song_id, filename in results
        if song_id and filename
    }


@router.post('/api/library/reconcile')
async def reconcile_library_endpoint() -> dict[str, Any]:
    """Detect moved files and refresh playlist M3U / Navidrome."""

    if state.downloader is None:
        raise HTTPException(status_code=500, detail='Downloader not ready')
    download_dir = Path(state.downloader.download_dir)

    def _run() -> dict[str, Any]:
        result = reconcile_and_refresh(
            download_dir,
            state.settings,
            state.downloader,
            track_index=state.track_index,
            playlist_catalog=state.playlist_catalog,
            monitor_db=state.monitor_db,
            navidrome_index=state.navidrome_index,
            refresh_playlists=True,
            playlist_spotify_cache=state.playlist_spotify_cache,
            cover_cache=state.cover_cache,
            metadata_cache=state.metadata_cache,
        )
        invalidate_library_paths_cache()
        if state.likes is not None:
            moved = remap_moved(state.likes, library_context())
            result['likes_updated'] = moved
            if moved:
                _sync_liked_playlist()
                _announce_likes()
        return result

    return await asyncio.to_thread(_run)


def _require_external_sync() -> ExternalSyncJob:
    if state.external_sync is None:
        raise HTTPException(
            status_code=503, detail='Extra-folder sync is not ready'
        )
    return state.external_sync


def broadcast_external_sync(status: dict[str, Any]) -> None:
    """Push extra-folder sync status from a worker thread."""

    loop = state.loop
    if loop is None:
        return
    asyncio.run_coroutine_threadsafe(
        state.connections.broadcast({
            'type': 'external_sync',
            'sync': status,
        }),
        loop,
    )


def _unmap_extra_roots(
    roots: list[Path], settings_for_dirs: dict[str, Any]
) -> dict[str, Any]:
    download_dir = (
        Path(state.downloader.download_dir)
        if state.downloader is not None
        else Path('/downloads')
    )
    slskd_dir = (
        slskd_dir_from_downloader(state.downloader)
        if state.downloader is not None
        else None
    )
    extra = extra_dirs_from_settings(
        settings_for_dirs, download_dir, slskd_dir
    )
    unmapped = 0
    folder_ids: list[str] = []
    for root in roots:
        info = unmap_extra_folder(
            root,
            download_dir=download_dir,
            slskd_dir=slskd_dir,
            extra_dirs=extra,
            cover_cache=state.cover_cache,
            metadata_cache=state.metadata_cache,
            playlist_catalog=state.playlist_catalog,
            track_index=state.track_index,
            likes=state.likes,
            navidrome_index=state.navidrome_index,
        )
        unmapped += int(info.get('unmapped') or 0)
        folder_ids.append(str(info.get('folder_id') or ''))
    return {'unmapped': unmapped, 'folder_ids': folder_ids}


def _unmap_removed_extra_folders(
    before: dict[str, Any], after: dict[str, Any]
) -> None:
    roots = folders_removed(before, after)
    if roots:
        _unmap_extra_roots(roots, before)


@router.post('/api/library/external/sync')
async def sync_external_library_endpoint(
    request: Request,
) -> dict[str, Any]:
    """Start a background scan of extra library folders.

    Optional JSON body ``{folders: ["/path", ...]}`` is saved into
    settings first (absolute paths only). The request returns the job
    status immediately; poll ``GET /api/library/external/sync`` or listen
    for ``external_sync`` WebSocket frames for the last-finished log.
    """

    payload = await _json_object(request)
    if 'folders' in payload:
        previous = dict(state.settings)
        state.settings['external_library'] = effective_external_library({
            'external_library': {'folders': payload.get('folders')}
        })
        if state.settings_path is not None:
            _save_settings(state.settings_path, state.settings)
        invalidate_library_paths_cache()
        _unmap_removed_extra_folders(previous, state.settings)

    job = _require_external_sync()
    if not job.try_begin():
        raise HTTPException(
            status_code=409,
            detail='A folder sync is already running',
        )
    download_dir = (
        Path(state.downloader.download_dir)
        if state.downloader is not None
        else Path('/downloads')
    )
    snapshot = job.snapshot()
    broadcast_external_sync(snapshot)

    async def _run() -> None:
        await asyncio.to_thread(
            run_external_sync,
            job,
            ctx=library_context(),
            download_dir=download_dir,
            settings=state.settings,
            lang=_ui_language(),
            image_kinds=_artist_image_kinds_to_save(state.settings),
            lyrics_cache=state.lyrics_cache,
            cover_cache=state.cover_cache,
            on_update=broadcast_external_sync,
        )

    spawn_task(_run(), name='external-library-sync')
    return snapshot


@router.get('/api/library/external/sync')
def get_external_sync_endpoint() -> dict[str, Any]:
    """Running extra-folder sync, or the last finished log."""

    return _require_external_sync().snapshot()


@router.post('/api/library/external/unmap')
async def unmap_external_folder_endpoint(
    request: Request,
) -> dict[str, Any]:
    """Stop mapping a folder: drop it from the library, keep the audio."""

    payload = await _json_object(request)
    raw = str(payload.get('folder') or '').strip()
    if not raw:
        raise HTTPException(status_code=400, detail='folder is required')
    root = Path(raw)
    previous = dict(state.settings)
    folders = [
        item
        for item in effective_external_library(state.settings)['folders']
        if Path(item) != root and str(item) != raw
    ]
    state.settings['external_library'] = effective_external_library({
        'external_library': {'folders': folders}
    })
    if state.settings_path is not None:
        _save_settings(state.settings_path, state.settings)
    result = _unmap_extra_roots([root], previous)
    normalize_lyrics_location(state.settings)
    bind_lrc_resolver()
    return {
        **result,
        'folders': list(effective_external_library(state.settings)['folders']),
    }


# ---------------------------------------------------------------------------
# Replacing a track's audio with a version picked by hand
# ---------------------------------------------------------------------------

_VIDEO_ID_RE = re.compile(r'^[A-Za-z0-9_-]{11}$')
# Files whose audio is being replaced right now.
_replacing: set[str] = set()


def _replaceable_track(file: str) -> tuple[Path, dict[str, Any]]:
    """A library file and its tags, or 404/400."""

    full = resolve_library_file(file, library_context())
    if full is None:
        raise HTTPException(status_code=404, detail='File not found')
    try:
        audio_replace.replacement_format(full)
    except audio_replace.ReplaceError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return full, read_audio_metadata(full)


def _track_summary(file: str, entry: dict[str, Any]) -> dict[str, Any]:
    return {
        'file': file,
        'title': str(entry.get('title') or ''),
        'artist': str(entry.get('artist') or '').replace(';', ', '),
        'album': str(entry.get('album') or ''),
        'duration': round(float(entry.get('duration') or 0), 1),
    }


@router.get('/api/library/replace/candidates')
async def replace_candidates(
    file: str = Query(...), query: str = Query('')
) -> dict[str, Any]:
    """Versions of a library track to replace its audio with:
    ``{track, query, candidates}``. ``query`` defaults to "Artist -
    Title"; a YouTube or YouTube Music link is that one video. Each
    candidate is ``{video_id, title, artist, album, duration,
    duration_diff, thumbnail, source, url}``."""

    full, entry = await asyncio.to_thread(_replaceable_track, file)
    text = query.strip() or audio_replace.search_query(entry)
    try:
        found = await asyncio.to_thread(audio_replace.candidates, text)
    except audio_replace.ReplaceError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    length = float(entry.get('duration') or 0)
    for row in found:
        row['duration_diff'] = (
            round(row['duration'] - length)
            if row['duration'] and length
            else None
        )
    return {
        'track': _track_summary(file, entry),
        'query': text,
        'candidates': found,
    }


@router.post('/api/library/replace')
async def replace_track_audio(request: Request) -> dict[str, Any]:
    """Replace a library track's audio with a YouTube video:
    ``{file, video_id}`` -> ``{job_id, file}``. Runs as a queue job (the
    usual progress messages, ``song.song_id`` = ``job_id``); the file keeps
    its path, format and tags."""

    payload = await _json_object(request)
    file = str(payload.get('file') or '').strip().replace('\\', '/')
    video_id = str(payload.get('video_id') or '').strip()
    if not file:
        raise HTTPException(status_code=400, detail='file is required')
    if not _VIDEO_ID_RE.fullmatch(video_id):
        raise HTTPException(status_code=400, detail='Unknown video')
    if state.downloader is None:
        raise HTTPException(status_code=500, detail='Downloader not ready')
    full, entry = await asyncio.to_thread(_replaceable_track, file)
    if file in _replacing:
        raise HTTPException(
            status_code=409, detail='This track is already being replaced'
        )
    summary = _track_summary(file, entry)
    song = {
        'song_id': f'replace:{file}',
        'name': summary['title'] or full.stem,
        'artists': [
            a.strip() for a in summary['artist'].split(',') if a.strip()
        ],
        'album_name': summary['album'],
        'cover_url': f'/cover?file={quote(file)}',
        'duration': summary['duration'],
        'url': f'https://music.youtube.com/watch?v={video_id}',
        # Tells the queue this job replaces a file's audio: a retry
        # replaces again instead of downloading a new track.
        'replace': {'file': file, 'video_id': video_id},
    }
    job_id = _register_job(song, status='downloading')
    _replacing.add(file)
    await log_activity(
        request,
        'audio_replaced',
        f'{summary["artist"]} - {summary["title"]}'.strip(' -'),
        {'file': file, 'video_id': video_id},
    )
    spawn_task(
        _run_replacement(job_id, song, file, full, video_id),
        name=f'replace-{video_id}',
    )
    return {'job_id': job_id, 'file': file}


async def _run_replacement(
    job_id: str,
    song: dict[str, Any],
    file: str,
    full: Path,
    video_id: str,
) -> None:
    loop = state.loop or asyncio.get_running_loop()
    job = state.download_jobs[job_id]

    def progress(
        pct: float, message: str, provider: Optional[str] = None
    ) -> None:
        job.update(progress=pct, message=message, provider=provider or '')
        asyncio.run_coroutine_threadsafe(
            state.connections.broadcast({
                'song': song,
                'progress': pct,
                'message': message,
                'provider': provider or '',
                'status': 'downloading',
            }),
            loop,
        )

    sem = state.download_semaphore
    try:
        old_key = content_key_for(full) or ''
    except Exception:
        old_key = ''
    try:
        await state.connections.broadcast({
            'song': song,
            'progress': 0,
            'message': 'Replacing audio',
            'status': 'downloading',
        })
        async with sem if sem is not None else contextlib.nullcontext():
            await loop.run_in_executor(
                DOWNLOAD_EXECUTOR,
                lambda: audio_replace.replace_audio(
                    state.downloader,
                    full,
                    video_id,
                    song=song,
                    progress_cb=progress,
                ),
            )
    except Exception as exc:
        _replacing.discard(file)
        logger.opt(
            exception=not isinstance(exc, audio_replace.ReplaceError)
        ).warning('Replacing the audio of {} failed: {}', file, exc)
        message = f'Error: {exc}'
        job.update(status='error', message=message)
        await state.connections.broadcast({
            'song': song,
            'progress': 0,
            'message': message,
            'status': 'error',
        })
        return
    _replacing.discard(file)
    await asyncio.to_thread(_after_replacement, file, full, old_key)
    job.update(status='done', progress=100, filename=file, message='Replaced')
    await state.connections.broadcast({
        'song': song,
        'progress': 100,
        'message': 'Replaced',
        'status': 'done',
        'filename': file,
    })
    announce_library_changed()


def _after_replacement(file: str, full: Path, old_key: str = '') -> None:
    """The caches that describe the file by its contents catch up."""

    if state.metadata_cache is not None:
        try:
            state.metadata_cache.refresh(file, full)
        except Exception:
            logger.debug('Metadata cache refresh failed for {}', file)
    if state.track_index is not None:
        spotify_id = state.track_index.spotify_id_for_filename(file)
        if spotify_id:
            state.track_index.register(spotify_id, file, full_path=full)
    if old_key and state.track_owners is not None:
        try:
            new_key = content_key_for(full) or ''
            if new_key:
                state.track_owners.rekey(old_key, new_key, file)
        except Exception:
            logger.opt(exception=True).debug(
                'Could not rekey owners for {}', file
            )
    invalidate_library_paths_cache(notify=False)


# ---------------------------------------------------------------------------
# Library upgrade (scan an existing library, then repair it)
# ---------------------------------------------------------------------------


def _require_upgrade_runner() -> library_upgrade.LibraryUpgradeRunner:
    if state.upgrade_runner is None:
        raise HTTPException(
            status_code=500, detail='Library upgrade not ready'
        )
    return state.upgrade_runner


def _upgrade_options(
    payload: dict[str, Any],
) -> library_upgrade.UpgradeOptions:
    """Request body over the saved defaults."""

    saved = state.settings.get('library_upgrade') or {}
    merged = {**saved, **(payload or {})}
    return library_upgrade.options_from(merged)


def broadcast_upgrade_progress(status: dict[str, Any]) -> None:
    """Push upgrade progress to connected clients from the worker thread."""

    loop = state.loop
    if loop is None:
        return
    asyncio.run_coroutine_threadsafe(
        state.connections.broadcast({
            'type': 'library_upgrade',
            'upgrade': status,
        }),
        loop,
    )


def _upgrade_payload(
    runner: library_upgrade.LibraryUpgradeRunner,
) -> dict[str, Any]:
    payload = runner.status()
    payload['categories'] = list(library_upgrade.CATEGORIES)
    payload['artwork_sources'] = list(cover_sources.ARTWORK_SOURCES)
    return payload


@router.get('/api/library/upgrade')
def library_upgrade_status() -> dict[str, Any]:
    """The current (or last) upgrade run, its queue counts and scan totals."""

    return _upgrade_payload(_require_upgrade_runner())


@router.get('/api/library/upgrade/jobs')
def library_upgrade_jobs(
    status: Optional[str] = Query(default=None),
    limit: int = Query(default=100, ge=1, le=1000),
) -> list[dict[str, Any]]:
    """Tracks in the current run, newest activity first."""

    runner = _require_upgrade_runner()
    run = runner.db.latest_run()
    if run is None:
        return []
    return runner.db.jobs(int(run['id']), status=status, limit=limit)


@router.post('/api/library/upgrade/scan')
async def library_upgrade_scan(
    payload: dict[str, Any] = Body(default={}),
) -> dict[str, Any]:
    """Look at every library track and report what is behind.

    Nothing is written: the scan fills a queue the client then confirms
    with ``/api/library/upgrade/start``.
    """

    runner = _require_upgrade_runner()
    try:
        return runner.start_scan(_upgrade_options(payload))
    except RuntimeError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc


@router.post('/api/library/upgrade/start')
async def library_upgrade_start(
    payload: dict[str, Any] = Body(default={}),
) -> dict[str, Any]:
    """Begin upgrading the scanned tracks, for the chosen categories."""

    runner = _require_upgrade_runner()
    categories = library_upgrade.normalize_categories(
        (payload or {}).get('categories')
    )
    try:
        return runner.start(categories)
    except RuntimeError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc


@router.post('/api/library/upgrade/pause')
async def library_upgrade_pause() -> dict[str, Any]:
    """Stop after the track being worked on; the queue is kept."""

    return _require_upgrade_runner().pause()


@router.post('/api/library/upgrade/resume')
async def library_upgrade_resume() -> dict[str, Any]:
    runner = _require_upgrade_runner()
    try:
        return runner.resume()
    except RuntimeError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc


@router.post('/api/library/upgrade/cancel')
async def library_upgrade_cancel() -> dict[str, Any]:
    """Drop the rest of the queue. Finished tracks stay upgraded."""

    return _require_upgrade_runner().cancel()


def _spotify_id_lookup() -> Optional[Any]:
    if state.track_index is None:
        return None
    index = state.track_index

    def _lookup(stored: str) -> str:
        return index.spotify_id_for_filename(stored) or ''

    return _lookup


@router.post('/api/library/albums/merge/preview')
async def library_albums_merge_preview() -> dict[str, Any]:
    """Albums the tag sources say belong together (writes nothing).

    A response the user confirms by posting back to
    ``/api/library/albums/merge``.
    """

    ctx = library_context()
    stats = {'looked_up': 0, 'resolved': 0}

    def _counting_resolver(
        song: dict[str, Any], spotify_id: str
    ) -> Optional[dict[str, Any]]:
        stats['looked_up'] += 1
        found = album_merge.default_resolver(song, spotify_id)
        if found and found.get('album_name'):
            stats['resolved'] += 1
        return found

    def _detect() -> list[album_merge.MergePlan]:
        return album_merge.detect_split_albums(
            ctx,
            spotify_id_for=_spotify_id_lookup(),
            resolver=_counting_resolver,
        )

    plans = await asyncio.to_thread(_detect)
    return {
        'candidates': [plan.to_dict() for plan in plans],
        'looked_up': stats['looked_up'],
        'resolved': stats['resolved'],
    }


@router.post('/api/library/albums/merge')
async def library_albums_merge(
    payload: dict[str, Any] = Body(default={}),
) -> dict[str, Any]:
    """Retag and move the confirmed albums into one folder each."""

    if state.downloader is None:
        raise HTTPException(status_code=500, detail='Downloader not ready')
    plans = (payload or {}).get('plans') or (payload or {}).get('groups') or []
    if not isinstance(plans, list):
        raise HTTPException(status_code=400, detail='plans must be a list')

    ctx = library_context()
    result = await asyncio.to_thread(
        album_merge.apply_merge,
        plans,
        ctx=ctx,
        downloader=state.downloader,
        settings=state.settings,
        monitor_db=state.monitor_db,
    )

    affected = set(result.get('playlists') or [])
    if affected and state.playlist_catalog is not None:
        await asyncio.to_thread(
            refresh_playlists_after_moves,
            affected,
            settings=state.settings,
            downloader=state.downloader,
            playlist_catalog=state.playlist_catalog,
            track_index=state.track_index,
            monitor_db=state.monitor_db,
            navidrome_index=state.navidrome_index,
            playlist_spotify_cache=state.playlist_spotify_cache,
            cover_cache=state.cover_cache,
            metadata_cache=state.metadata_cache,
        )
        result['playlists_refreshed'] = sorted(affected)
    return result


@router.post('/api/library/playlists/rebuild')
async def library_playlists_rebuild() -> dict[str, Any]:
    """Rewrite every known playlist's M3U from what is already on disk."""

    if state.downloader is None:
        raise HTTPException(status_code=500, detail='Downloader not ready')
    ctx = library_context()
    return await asyncio.to_thread(
        library_playlists.rebuild_playlist_m3us,
        ctx=ctx,
        settings=state.settings,
        downloader=state.downloader,
        monitor_db=state.monitor_db,
        playlist_catalog=state.playlist_catalog,
        track_index=state.track_index,
    )


# ── Tag editor ────────────────────────────────────────────────────────
#: Largest uploaded cover the tag editor accepts (bytes).
_MAX_COVER_BYTES = 12 * 1024 * 1024


def _decode_cover_image(value: str) -> bytes:
    """Decode a data URL or bare base64 image, with a size cap."""

    text = str(value or '').strip()
    if not text:
        return b''
    if text.startswith('data:'):
        _, _, text = text.partition(',')
    try:
        data = base64.b64decode(text, validate=False)
    except Exception as exc:
        raise HTTPException(
            status_code=400, detail='Cover is not valid base64'
        ) from exc
    if len(data) > _MAX_COVER_BYTES:
        raise HTTPException(status_code=413, detail='Cover image is too big')
    return data


def _musicbrainz_query(title: str, artist: str, fallback: str) -> str:
    """A MusicBrainz Lucene query from the editor's title/artist boxes."""

    parts: list[str] = []
    clean_title = title.replace('"', ' ').strip()
    clean_artist = artist.replace('"', ' ').strip()
    if clean_title:
        parts.append(f'recording:"{clean_title}"')
    if clean_artist:
        parts.append(f'artist:"{clean_artist}"')
    if parts:
        return ' AND '.join(parts)
    return fallback


@router.get('/api/library/tags')
async def library_tags(file: str = Query(..., min_length=1)) -> dict[str, Any]:
    """Every editable tag of one library track."""

    full = resolve_library_file(file, library_context())
    if full is None:
        raise HTTPException(status_code=404, detail='File not found')
    return {
        'file': file,
        'tags': await asyncio.to_thread(tag_editor.read_tags, full),
    }


@router.post('/api/library/tags')
async def library_tags_write(
    payload: dict[str, Any] = Body(default={}),
) -> dict[str, Any]:
    """Write edited tags (and optionally a new cover) into a library track."""

    file = str((payload or {}).get('file') or '').strip()
    if not file:
        raise HTTPException(status_code=400, detail='file is required')
    fields = (payload or {}).get('fields')
    if not isinstance(fields, dict):
        raise HTTPException(status_code=400, detail='fields must be an object')
    remove_cover = bool((payload or {}).get('remove_cover'))
    cover = _decode_cover_image((payload or {}).get('cover') or '')

    ctx = library_context()
    full = resolve_library_file(file, ctx)
    if full is None:
        raise HTTPException(status_code=404, detail='File not found')

    def _write() -> None:
        tag_editor.write_tags(
            full, fields, cover=cover or None, remove_cover=remove_cover
        )
        if ctx.metadata_cache is not None:
            try:
                ctx.metadata_cache.refresh(file, full)
            except Exception:
                logger.debug('Tag editor: metadata cache refresh failed')
        if state.cover_cache is not None and state.downloader is not None:
            try:
                state.cover_cache.refresh_stored_path(
                    file,
                    download_dir=Path(state.downloader.download_dir),
                    slskd_dir=slskd_dir_from_downloader(state.downloader),
                )
            except Exception:
                logger.debug('Tag editor: cover cache refresh failed')

    try:
        await asyncio.to_thread(_write)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        logger.opt(exception=True).warning('Tag editor: write failed')
        raise HTTPException(
            status_code=500, detail=f'Could not write tags: {exc}'
        ) from exc
    invalidate_library_paths_cache()
    return {
        'ok': True,
        'file': file,
        'tags': await asyncio.to_thread(tag_editor.read_tags, full),
    }


@router.get('/api/library/tags/search')
async def library_tags_search(
    source: str = Query('musicbrainz'),
    q: str = Query(''),
    title: str = Query(''),
    artist: str = Query(''),
    limit: int = Query(10, ge=1, le=25),
) -> dict[str, Any]:
    """Look a release up on MusicBrainz or Discogs to fill a track's tags."""

    query = str(q or '').strip()
    src = str(source or '').strip().lower()
    if src == 'musicbrainz':
        search_query = _musicbrainz_query(title, artist, query)
        if not search_query:
            raise HTTPException(status_code=400, detail='search is empty')
        results = await asyncio.to_thread(
            musicbrainz.search_recordings, search_query, limit=limit
        )
    elif src == 'discogs':
        search_query = (
            query or ' '.join(part for part in (artist, title) if part).strip()
        )
        if not search_query:
            raise HTTPException(status_code=400, detail='search is empty')
        try:
            results = await asyncio.to_thread(
                discogs.search_releases,
                search_query,
                token=str(state.settings.get('discogs_token') or ''),
                limit=limit,
            )
        except discogs.DiscogsTokenMissing as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
    else:
        raise HTTPException(status_code=400, detail='Unknown source')
    return {'source': src, 'results': results}


@router.get('/api/library/tags/release')
async def library_tags_release(
    source: str = Query(...),
    id: str = Query(..., min_length=1),
) -> dict[str, Any]:
    """A release's album metadata and ordered tracklist, for the editor."""

    src = str(source or '').strip().lower()
    if src == 'musicbrainz':
        data = await asyncio.to_thread(musicbrainz.release_tracklist, id)
    elif src == 'discogs':
        try:
            data = await asyncio.to_thread(
                discogs.release,
                id,
                token=str(state.settings.get('discogs_token') or ''),
            )
        except discogs.DiscogsTokenMissing as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
    else:
        raise HTTPException(status_code=400, detail='Unknown source')
    if data is None:
        raise HTTPException(status_code=404, detail='Release not found')
    return data


@router.get('/api/library/duplicates')
async def library_duplicates() -> dict[str, Any]:
    """Duplicate titles and albums already in the library listing."""

    entries = await asyncio.to_thread(list_library_entries, library_context())
    return await asyncio.to_thread(duplicates.find_duplicates, entries)


async def _schedule_playlist_refresh_after_delete(
    playlist_names: set[str],
) -> None:
    if not playlist_names or state.downloader is None:
        return
    if state.playlist_catalog is None:
        return

    async def _run() -> None:
        logger.info(
            'Library delete: scheduling M3U/Navidrome refresh for {}',
            ', '.join(sorted(playlist_names)[:8])
            + ('; ...' if len(playlist_names) > 8 else ''),
        )
        try:
            await asyncio.to_thread(
                refresh_playlists_after_moves,
                playlist_names,
                settings=state.settings,
                downloader=state.downloader,
                playlist_catalog=state.playlist_catalog,
                track_index=state.track_index,
                monitor_db=state.monitor_db,
                navidrome_index=state.navidrome_index,
                playlist_spotify_cache=state.playlist_spotify_cache,
                cover_cache=state.cover_cache,
                metadata_cache=state.metadata_cache,
            )
        except Exception:
            logger.exception(
                'library delete: background playlist refresh failed for {}',
                ', '.join(sorted(playlist_names)[:5]),
            )

    spawn_task(_run(), name='playlist-refresh-after-delete')


@router.get('/api/library/summary')
def library_summary(request: Request) -> dict[str, Any]:
    """Home-page library stats and a short recent-album shelf.

    Avoids sending every ``GET /tracks`` row to the browser when the
    page only shows counts and a handful of albums. A user sees their
    own library only.
    """

    return library_home_summary(
        library_context(), allowed_keys=allowed_entry_keys(request)
    )


@router.get('/api/library/albums')
def library_albums(request: Request) -> list[dict[str, Any]]:
    """Album tiles for the Library page, without every track row."""

    return library_album_index(
        library_context(), allowed_keys=allowed_entry_keys(request)
    )


@router.get('/api/library/artists')
def library_artists(request: Request) -> list[dict[str, Any]]:
    """Artist tiles for the Library page and Discover's library payload."""

    liked: set[str] = set()
    if state.likes is not None:
        liked = {
            str(path or '').replace('\\', '/')
            for path in state.likes.paths(likes_scope(request))
        }
    return library_artist_index(
        library_context(), liked, allowed_keys=allowed_entry_keys(request)
    )


@router.post('/api/library/lookup')
async def library_lookup(request: Request) -> list[dict[str, Any]]:
    """Library rows for search/link songs that are already downloaded."""

    payload = await _json_object(request)
    songs = payload.get('songs')
    if not isinstance(songs, list):
        songs = []
    return lookup_library_songs(
        library_context(), songs, allowed_keys=allowed_entry_keys(request)
    )


@router.post('/api/library/playlists')
async def create_library_playlist_endpoint(request: Request) -> dict[str, Any]:
    """Create an empty playlist the user can edit in the Library."""

    payload = await _json_object(request)
    name = str(payload.get('name') or '').strip()
    ctx = library_context()
    try:
        result = await asyncio.to_thread(create_manual_playlist, ctx, name)
    except ManualPlaylistError as exc:
        raise HTTPException(
            status_code=exc.status_code, detail=str(exc)
        ) from exc
    claim_manual_playlist(str(result.get('name') or name), request)
    invalidate_library_paths_cache()
    return result


@router.post('/api/library/playlists/tracks')
async def edit_library_playlist_tracks_endpoint(
    request: Request,
) -> dict[str, Any]:
    """Add or remove library files on a manual playlist."""

    payload = await _json_object(request)
    name = str(payload.get('name') or '').strip()
    require_playlist_visible(name, request)
    add = payload.get('add') if isinstance(payload.get('add'), list) else []
    remove = (
        payload.get('remove')
        if isinstance(payload.get('remove'), list)
        else []
    )
    ctx = library_context()
    try:
        result = await asyncio.to_thread(
            edit_manual_playlist,
            ctx,
            name,
            add=[str(item) for item in add],
            remove=[str(item) for item in remove],
        )
    except ManualPlaylistError as exc:
        raise HTTPException(
            status_code=exc.status_code, detail=str(exc)
        ) from exc
    invalidate_library_paths_cache()
    return result


@router.post('/api/library/playlists/rename')
async def rename_library_playlist_endpoint(request: Request) -> dict[str, Any]:
    """Rename a playlist the user created in the Library."""

    payload = await _json_object(request)
    name = str(payload.get('name') or '').strip()
    new_name = str(payload.get('new_name') or '').strip()
    require_playlist_visible(name, request)
    ctx = library_context()
    try:
        result = await asyncio.to_thread(
            rename_manual_playlist, ctx, name, new_name
        )
    except ManualPlaylistError as exc:
        raise HTTPException(
            status_code=exc.status_code, detail=str(exc)
        ) from exc
    if state.manual_playlist_owners is not None:
        try:
            await asyncio.to_thread(
                state.manual_playlist_owners.rename_owner,
                name,
                str(result.get('name') or new_name),
            )
        except Exception:
            logger.opt(exception=True).debug(
                'Could not move owner for playlist {!r}', name
            )
    invalidate_library_paths_cache()
    return result


@router.delete('/api/library/playlist')
async def delete_library_playlist_endpoint(
    request: Request,
    playlist_name: str = Query(..., min_length=1),
) -> dict[str, Any]:
    """Delete all tracks in a playlist, its M3U, and catalog entry.

    A user deletes their own playlist only: files others still own
    stay on disk (losing just this owner's row), files nobody else
    owns go like a single delete.
    """

    if state.downloader is None:
        raise HTTPException(status_code=500, detail='Downloader not ready')

    if is_liked_playlist(playlist_name):
        # Deleting a playlist deletes its tracks from disk. Here that must
        # only ever mean "unlike everything": the songs are the user's
        # library, the playlist merely lists the ones they hearted.
        await asyncio.to_thread(_clear_likes, likes_scope(request))
        return {
            'ok': True,
            'playlist': playlist_name,
            'files': [],
            'deleted_count': 0,
            'failed_count': 0,
            'failed': [],
            'playlists_affected': [],
            'playlists_refresh_scheduled': False,
        }

    return await _delete_playlist_by_name(request, playlist_name)


async def _delete_playlist_by_name(
    request: Request, playlist_name: str
) -> dict[str, Any]:
    """Shared core of both playlist delete endpoints."""

    if request_is_admin(request):

        def _run() -> dict[str, Any]:
            assert state.downloader is not None
            return delete_playlist_from_library(
                playlist_name,
                Path(state.downloader.download_dir),
                state.settings,
                state,
            )

        result = await asyncio.to_thread(_run)
    else:
        match = playlist_entry_for_request(playlist_name, request)
        if match is None:
            raise HTTPException(status_code=404, detail='Playlist not found')
        result = await _delete_owned_playlist(request, match)
    if not result.get('ok'):
        raise HTTPException(
            status_code=400,
            detail=str(result.get('error') or 'Playlist delete failed'),
        )
    affected = set(result.get('playlists_affected') or [])
    if affected:
        await _schedule_playlist_refresh_after_delete(affected)
    result['playlists_refresh_scheduled'] = bool(affected)
    return result


async def _delete_owned_playlist(
    request: Request, match: dict[str, Any]
) -> dict[str, Any]:
    """One user's playlist delete (see
    :func:`delete_library_playlist_endpoint`)."""

    name = str(match.get('name') or '')
    user_id = request_user_id(request)

    def _run() -> dict[str, Any]:
        assert state.downloader is not None
        download_dir = Path(state.downloader.download_dir)
        if match.get('manual'):
            result = delete_playlist_from_library(
                name, download_dir, state.settings, state
            )
            if state.manual_playlist_owners is not None:
                state.manual_playlist_owners.forget_owner(name)
            return result
        files = [
            str(item or '').strip().replace('\\', '/')
            for item in (match.get('files') or [])
            if str(item or '').strip()
        ]
        to_delete: list[str] = []
        released = 0
        for stored in files:
            action, key = ownership_action(stored, request)
            if action == 'delete' and key:
                to_delete.append(stored)
            elif action == 'release' and key:
                release_file_ownership(stored, key, user_id)
                released += 1
        keys = {stored: stored_content_key(stored) for stored in to_delete}
        batch = delete_library_files(
            to_delete, library_context(), state, log_failures=False
        )
        for gone in batch.get('deleted') or []:
            if keys.get(gone):
                drop_file_owners(keys[gone])
        if state.playlist_catalog is not None:
            state.playlist_catalog.delete_playlist(name)
        organize = bool(
            state.settings.get('organize_by_artist', False)
            or state.settings.get('organize_by_album', False)
        )
        shell = remove_playlist_shell(
            name, download_dir, organize_by_artist=organize
        )
        affected = set(batch.get('playlists_affected') or [])
        affected.add(name)
        failed = list(batch.get('failed') or [])
        logger.info(
            'Playlist delete finished for {!r}: {} audio file(s) '
            'removed, {} released, {} failed, {} M3U file(s)',
            name,
            len(batch.get('deleted') or []),
            released,
            len(failed),
            shell['m3u_removed'],
        )
        return {
            'ok': True,
            'playlist': name,
            'files': list(batch.get('deleted') or []),
            'deleted_count': len(batch.get('deleted') or []),
            'released_count': released,
            'failed_count': len(failed),
            'failed': failed,
            'playlists_affected': sorted(affected),
        }

    result = await asyncio.to_thread(_run)
    return result


@router.get('/api/playlists/batches')
async def list_playlist_batches_endpoint(request: Request) -> dict[str, Any]:
    """Tracked Spotify playlist batches (summary from Spotify cache)."""

    scope = _batch_scope(request)
    reports = await asyncio.to_thread(
        _build_playlist_batch_reports, user_id=scope
    )
    return {'playlists': reports, 'count': len(reports)}


@router.get('/api/playlists/batches/{spotify_playlist_id}')
async def get_playlist_batch_detail_endpoint(
    request: Request,
    spotify_playlist_id: str,
    tracks: bool = Query(default=True),
    refresh: bool = Query(default=False),
) -> dict[str, Any]:
    """Completeness for one playlist using cached Spotify track list."""

    scope = _batch_scope(request)
    report = await asyncio.to_thread(
        _report_for_spotify_playlist,
        spotify_playlist_id,
        mode='spotify',
        include_missing_tracks=tracks,
        refresh=refresh,
        user_id=scope,
    )
    if report is None:
        raise HTTPException(status_code=404, detail='Playlist not found')
    return report


def _purge_playlist_tracking(spotify_playlist_id: str) -> None:
    sid = str(spotify_playlist_id or '').strip()
    if not sid:
        return
    batches_removed = 0
    if state.playlist_batch_store is not None:
        batches_removed = (
            state.playlist_batch_store.delete_for_spotify_playlist(sid)
        )
    if state.playlist_spotify_cache is not None:
        state.playlist_spotify_cache.delete_playlist(sid)
    monitor_removed = False
    if state.monitor_db is not None:
        monitored = state.monitor_db.get_by_spotify_id(sid)
        if monitored is not None:
            state.monitor_db.delete_playlist(monitored.id)
            monitor_removed = True
    logger.info(
        'Playlist delete: cleared tracking for {} '
        '(batch_rows={}, spotify_cache=yes, monitor={})',
        sid,
        batches_removed,
        'removed' if monitor_removed else 'none',
    )


@router.delete('/api/playlists/batches/{spotify_playlist_id}')
async def delete_playlist_batch_endpoint(
    request: Request,
    spotify_playlist_id: str,
) -> dict[str, Any]:
    """Delete playlist audio, catalog, M3U, and batch/monitor/cache tracking."""

    sid = str(spotify_playlist_id or '').strip()
    if not sid:
        raise HTTPException(
            status_code=400, detail='spotify_playlist_id required'
        )
    if state.downloader is None:
        raise HTTPException(status_code=500, detail='Downloader not ready')

    scope = _batch_scope(request)
    meta = _known_spotify_playlist_sources(scope).get(sid)
    if meta is None:
        raise HTTPException(status_code=404, detail='Playlist not found')

    playlist_name = str(meta.get('playlist_name') or sid).strip() or sid
    logger.info(
        'Playlist batch delete requested for {!r} (spotify_id={})',
        playlist_name,
        sid,
    )

    if request_is_admin(request):

        def _run() -> dict[str, Any]:
            assert state.downloader is not None
            result = delete_playlist_from_library(
                playlist_name,
                Path(state.downloader.download_dir),
                state.settings,
                state,
            )
            _purge_playlist_tracking(sid)
            return result

        result = await asyncio.to_thread(_run)
    else:
        batch = meta.get('batch')
        if not isinstance(batch, dict) or not batch.get('id'):
            raise HTTPException(status_code=404, detail='Playlist not found')
        result = await _delete_playlist_by_name(request, playlist_name)
        if state.playlist_batch_store is not None:
            await asyncio.to_thread(
                state.playlist_batch_store.delete_for_spotify_playlist,
                sid,
                request_user_id(request),
            )
    if not result.get('ok'):
        raise HTTPException(
            status_code=400,
            detail=str(result.get('error') or 'Playlist delete failed'),
        )
    affected = set(result.get('playlists_affected') or [])
    if affected:
        await _schedule_playlist_refresh_after_delete(affected)
    result['spotify_playlist_id'] = sid
    result['playlists_refresh_scheduled'] = bool(affected)
    return result


@router.get('/api/playlists/incomplete')
async def list_incomplete_playlists_endpoint(
    request: Request,
) -> dict[str, Any]:
    """Playlist batches that are still missing tracks vs Spotify."""

    scope = _batch_scope(request)
    reports = await asyncio.to_thread(
        _build_incomplete_playlist_reports, user_id=scope
    )
    return {'playlists': reports, 'count': len(reports)}


@router.post('/api/playlists/incomplete/download-missing')
async def download_missing_playlist_tracks_endpoint(
    request: Request,
    body: dict[str, Any] = Body(...),
) -> dict[str, Any]:
    """Queue only tracks from a Spotify playlist that are not in the library."""

    if state.downloader is None:
        raise HTTPException(status_code=500, detail='Downloader not ready')

    spotify_playlist_id = str(body.get('spotify_playlist_id') or '').strip()
    playlist_url = str(body.get('playlist_url') or '').strip()
    if not spotify_playlist_id and playlist_url:
        parsed = spotify.parse_spotify_url(playlist_url)
        if parsed is not None and parsed[0] == 'playlist':
            spotify_playlist_id = parsed[1]
    if not spotify_playlist_id:
        raise HTTPException(
            status_code=400,
            detail='spotify_playlist_id or playlist_url required',
        )

    playlist_name, resolved_url, missing = await asyncio.to_thread(
        _missing_tracks_for_playlist,
        spotify_playlist_id,
        user_id=_batch_scope(request),
    )
    if not missing:
        if state.playlist_batch_store is not None:
            for batch in state.playlist_batch_store.list_open_batches():
                if batch['spotify_playlist_id'] == spotify_playlist_id:
                    state.playlist_batch_store.mark_complete(batch['id'])
        linked = await asyncio.to_thread(
            _rebuild_playlist_catalog_from_library,
            playlist_name,
            spotify_playlist_id,
        )
        do_m3u, do_navidrome = playlist_refresh_enabled(state.settings)
        if linked and (do_m3u or do_navidrome):
            await asyncio.to_thread(
                refresh_playlists_after_moves,
                {playlist_name},
                settings=state.settings,
                downloader=state.downloader,
                playlist_catalog=state.playlist_catalog,
                track_index=state.track_index,
                monitor_db=state.monitor_db,
                navidrome_index=state.navidrome_index,
                navidrome_scan=bool(
                    state.settings.get('navidrome', {}).get(
                        'scan_after_download', True
                    )
                ),
                playlist_spotify_cache=state.playlist_spotify_cache,
                cover_cache=state.cover_cache,
                metadata_cache=state.metadata_cache,
            )
        return {
            'count': 0,
            'message': 'Playlist already complete',
            'catalog_linked': linked,
            'playlist_refresh': bool(linked and (do_m3u or do_navidrome)),
        }

    generate_m3u = bool(body.get('generate_m3u', True))
    batch_id: Optional[int] = None
    if state.playlist_batch_store is not None:
        batch_id = await asyncio.to_thread(
            state.playlist_batch_store.start_batch,
            spotify_playlist_id,
            playlist_name,
            resolved_url,
            len(missing),
            user_id=request_user_id(request),
        )

    songs: list[dict[str, Any]] = []
    for index, track in enumerate(missing):
        song = dict(track)
        song['downtify_playlist_url'] = resolved_url
        song['downtify_track_order'] = index
        songs.append(song)

    result = await _submit_playlist_batch(
        songs,
        resolved_url,
        generate_m3u=generate_m3u,
        batch_id=batch_id,
        user_id=request_user_id(request),
    )
    result['missing_count'] = len(missing)
    result['playlist_name'] = playlist_name
    return result


def _queue_job_visible(job: dict[str, Any], request: Request) -> bool:
    """Whether the queue *job* is *request*'s own (admins see every job).

    A shared job is visible to every account waiting on it; an ownerless
    job (a system retry with no waiter yet) is admin-only.
    """

    if request_is_admin(request):
        return True
    return request_user_id(request) in _job_users(job)


@router.get('/api/queue')
def get_queue(request: Request) -> list[dict[str, Any]]:
    """The download queue: everyone's for an admin, one's own otherwise.

    Every row carries ``position``: the 1-based place among the still
    waiting jobs (``queued`` + ``downloading``) in the order shown, or
    ``None`` once finished. An admin's positions are global, a user's
    count their own slice. ``user_ids`` is the sorted waiter list; a
    shared job shows the same row (and the same position) to everyone
    waiting on it.
    """

    rows: list[dict[str, Any]] = []
    position = 0
    for job in state.download_jobs.values():
        if not _queue_job_visible(job, request):
            continue
        row = dict(job)
        if job.get('status') in {'queued', 'downloading'}:
            position += 1
            row['position'] = position
        else:
            row['position'] = None
        row['user_ids'] = sorted(_job_users(job))
        rows.append(row)
    return rows


@router.delete('/api/queue')
def clear_queue(request: Request) -> dict:
    if request_is_admin(request):
        state.download_jobs.clear()
        return {'cleared': True}
    for song_id in [
        key
        for key, job in list(state.download_jobs.items())
        if _queue_job_visible(job, request)
    ]:
        del state.download_jobs[song_id]
    return {'cleared': True}


@router.delete('/api/queue/completed')
def clear_completed_queue(request: Request) -> dict:
    """Remove finished jobs so a new playlist queue is easier to read."""
    removed = [
        song_id
        for song_id, job in list(state.download_jobs.items())
        if job.get('status') == 'done' and _queue_job_visible(job, request)
    ]
    for song_id in removed:
        del state.download_jobs[song_id]
    return {'removed': len(removed)}


@router.delete('/api/queue/item')
def remove_queue_item(request: Request, song_id: str = Query(...)) -> dict:
    job = state.download_jobs.get(song_id)
    if job is not None and _queue_job_visible(job, request):
        del state.download_jobs[song_id]
        return {'removed': True}
    return {'removed': False}


@router.post('/api/playlist/m3u')
async def write_playlist_m3u_endpoint(request: Request) -> dict[str, Any]:
    """Write an M3U for the playlist after the per-track downloads.

    The frontend POSTs ``{playlist_url, tracks: [{filename, title,
    artist, duration}, ...]}``, where ``playlist_url`` is a Spotify or
    YouTube Music playlist. The playlist name is resolved server-side
    via :func:`monitor.fetch_playlist` so the existing ``/api/song/url``
    shape stays untouched.
    """

    if state.downloader is None:
        raise HTTPException(status_code=500, detail='Downloader not ready')
    try:
        payload = await request.json()
    except Exception as exc:
        raise HTTPException(status_code=400, detail='Invalid JSON') from exc
    if not isinstance(payload, dict):
        raise HTTPException(status_code=400, detail='Invalid payload')

    playlist_url = str(payload.get('playlist_url') or '').strip()
    if not playlist_url:
        raise HTTPException(status_code=400, detail='Missing playlist_url')
    source_and_id = parse_playlist_url(playlist_url)
    if source_and_id is None:
        raise HTTPException(
            status_code=400,
            detail='Not a Spotify or YouTube Music playlist URL',
        )

    tracks = payload.get('tracks') or []
    if not isinstance(tracks, list):
        raise HTTPException(status_code=400, detail='tracks must be a list')

    try:
        playlist_name, _ = await asyncio.to_thread(
            fetch_playlist, *source_and_id
        )
    except Exception as exc:
        logger.exception('Failed to resolve playlist {}', playlist_url)
        raise HTTPException(status_code=502, detail=str(exc)) from exc

    entries = [t for t in tracks if isinstance(t, dict)]
    playlist_subdir = m3u.sanitize_playlist_name(playlist_name)
    organize = _organize_enabled()
    target, kept = m3u.write_m3u(
        state.downloader.download_dir,
        playlist_name,
        entries,
        playlist_subdir=None if organize else playlist_subdir,
    )
    if target is None:
        raise HTTPException(
            status_code=400, detail='No tracks resolved to a file on disk'
        )
    await asyncio.to_thread(
        download_playlist_cover,
        *source_and_id,
        target,
        state.settings,
    )
    return {'path': str(target), 'count': kept}


def _require_cookies_store() -> CookiesStore:
    if state.cookies_store is None:
        raise HTTPException(
            status_code=503, detail='Cookie storage is not ready yet'
        )
    return state.cookies_store


@router.get('/api/cookies')
def get_cookies_endpoint() -> dict[str, Any]:
    """Current cookie configuration, for the settings UI.

    ``locked`` means ``DOWNTIFY_COOKIES_FILE`` is set: that deployment
    manages its own cookie file, so uploads and deletions are refused.
    """
    return _require_cookies_store().status()


@router.post('/api/cookies')
async def upload_cookies_endpoint(request: Request) -> dict[str, Any]:
    """Store an uploaded Netscape ``cookies.txt``, replacing any previous one.

    The body is the raw file rather than a multipart form so Downtify
    doesn't need ``python-multipart`` just for this — a cookies.txt is
    plain text and never large.
    """
    store = _require_cookies_store()
    if store.is_locked():
        raise HTTPException(
            status_code=409,
            detail=(
                'Cookies are configured through the DOWNTIFY_COOKIES_FILE '
                'environment variable. Unset it to manage the file here.'
            ),
        )
    content = await request.body()
    if len(content) > MAX_COOKIES_BYTES:
        raise HTTPException(status_code=413, detail='File is too large')
    try:
        warnings = await asyncio.to_thread(store.save, content)
    except InvalidCookiesFile as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except OSError as exc:
        logger.exception('Failed to store uploaded cookies file')
        raise HTTPException(
            status_code=500, detail=f'Could not save the file: {exc}'
        ) from exc
    return {**store.status(), 'warnings': warnings}


@router.delete('/api/cookies')
async def delete_cookies_endpoint() -> dict[str, Any]:
    store = _require_cookies_store()
    if store.is_locked():
        raise HTTPException(
            status_code=409,
            detail=(
                'Cookies are configured through the DOWNTIFY_COOKIES_FILE '
                'environment variable. Unset it to manage the file here.'
            ),
        )
    try:
        deleted = await asyncio.to_thread(store.delete)
    except OSError as exc:
        logger.exception('Failed to delete stored cookies file')
        raise HTTPException(
            status_code=500, detail=f'Could not delete the file: {exc}'
        ) from exc
    return {**store.status(), 'deleted': deleted}


@router.get('/api/settings')
def get_settings_endpoint(client_id: str = Query('')) -> dict[str, Any]:
    return state.settings


@router.get('/api/fs/dirs')
def suggest_fs_dirs_endpoint(path: str = Query('')) -> dict[str, Any]:
    """Directory names that complete ``path`` as typed in Settings."""

    return {'dirs': suggest_directories(path)}


@router.post('/api/settings/update')
async def update_settings_endpoint(
    request: Request, client_id: str = Query('')
) -> dict[str, Any]:
    try:
        payload = await request.json()
    except Exception:
        payload = {}
    before = json.dumps(state.settings, sort_keys=True, default=str)
    previous = json.loads(before)
    if isinstance(payload, dict):
        # Validated up front so a rejected save changes nothing.
        pending = {**state.settings, **payload}
        slskd_cfg = _effective_slskd_settings(pending)
        navidrome_cfg = _effective_navidrome_settings(pending)
        usenet_cfg = _effective_usenet_settings(pending)
        _validate_integration_settings(
            slskd_cfg if 'slskd' in payload else {},
            navidrome_cfg if 'navidrome' in payload else {},
            usenet_cfg if 'usenet' in payload else {},
        )
        for key, raw_value in payload.items():
            if key not in DEFAULT_SETTINGS:
                continue
            if key == 'max_parallel_downloads':
                state.settings[key] = _clamp_parallel_downloads(raw_value)
            elif key == 'download_delay_seconds':
                state.settings[key] = _clamp_download_delay(raw_value)
            elif key == 'max_track_duration_seconds':
                state.settings[key] = _clamp_track_duration(raw_value)
            elif key == 'external_sync_delay_seconds':
                state.settings[key] = _clamp_download_delay(raw_value)
            elif key == 'cover_resolution':
                state.settings[key] = _clamp_cover_resolution(raw_value)
            elif key == 'ui_language':
                # Not a language code: the saved one stays.
                state.settings[key] = _clean_ui_language(raw_value) or (
                    state.settings.get(key, '')
                )
            elif key == 'slskd':
                # The parallel limit is derived from max_parallel_downloads,
                # not stored with slskd's own options.
                state.settings[key] = {
                    k: v
                    for k, v in slskd_cfg.items()
                    if k != 'max_parallel_downloads'
                }
            elif key == 'navidrome':
                state.settings[key] = navidrome_cfg
            elif key == 'usenet':
                # Same as slskd: the parallel limit is derived from
                # max_parallel_downloads, not stored with usenet's options.
                state.settings[key] = {
                    k: v
                    for k, v in usenet_cfg.items()
                    if k != 'max_parallel_downloads'
                }
            elif key == 'external_library':
                state.settings[key] = effective_external_library({
                    'external_library': raw_value
                    if isinstance(raw_value, dict)
                    else {}
                })
            elif key == 'lyrics_lrc_beside':
                state.settings[key] = lyrics.coerce_bool(raw_value, True)
            elif key == 'lyrics_lrc_dir':
                state.settings[key] = str(raw_value or '').strip()
            else:
                state.settings[key] = raw_value
        if {'audio_providers', 'slskd', 'usenet'} & set(payload):
            state.settings['audio_providers'] = _stored_audio_providers(
                state.settings
            )
        if state.downloader is not None:
            if {
                'audio_providers',
                'slskd',
                'usenet',
                'max_parallel_downloads',
            } & set(payload):
                state.downloader.slskd_settings = (
                    state.downloader._normalize_slskd_settings(
                        _effective_slskd_settings(state.settings)
                    )
                )
                state.downloader.slskd_settings['output_dir'] = str(
                    state.downloader.download_dir
                )
                state.downloader.usenet_settings = (
                    state.downloader._normalize_usenet_settings(
                        _effective_usenet_settings(state.settings)
                    )
                )
                state.downloader.audio_providers = _effective_audio_providers(
                    state.settings
                )
            fmt = payload.get('format')
            if isinstance(fmt, str) and fmt:
                state.downloader.audio_format = fmt
            bitrate = payload.get('bitrate')
            if isinstance(bitrate, str) and bitrate:
                state.downloader.audio_bitrate = bitrate
            output = payload.get('output')
            if isinstance(output, str) and output:
                state.downloader.output_template = output.replace(
                    '.{output-ext}', ''
                )
            if 'lyrics_providers' in payload or 'download_lyrics' in payload:
                state.downloader.lyrics_providers = (
                    _effective_lyrics_providers(state.settings)
                )
            if 'organize_by_artist' in payload:
                state.downloader.organize_by_artist = bool(
                    payload['organize_by_artist']
                )
            if 'organize_by_album' in payload:
                state.downloader.organize_by_album = bool(
                    payload['organize_by_album']
                )
            if 'download_cover_art' in payload:
                state.downloader.download_cover_art = bool(
                    payload['download_cover_art']
                )
            if 'overwrite_existing_files' in payload:
                state.downloader.overwrite_existing_files = bool(
                    payload['overwrite_existing_files']
                )
            if 'max_track_duration_seconds' in payload:
                state.downloader.max_track_duration_seconds = state.settings[
                    'max_track_duration_seconds'
                ]
        if 'max_parallel_downloads' in payload:
            state.download_semaphore = asyncio.Semaphore(
                state.settings['max_parallel_downloads']
            )
            reset_slskd_parallelism(_effective_slskd_settings(state.settings))
            reset_usenet_parallelism(
                _effective_usenet_settings(state.settings)
            )
        if 'cover_resolution' in payload:
            providers.set_cover_resolution(state.settings['cover_resolution'])
        if 'external_library' in payload:
            invalidate_library_paths_cache()
            _unmap_removed_extra_folders(previous, state.settings)
        normalize_lyrics_location(state.settings)
        bind_lrc_resolver()
    if state.settings_path is not None:
        _save_settings(state.settings_path, state.settings)
    after = json.loads(json.dumps(state.settings, sort_keys=True, default=str))
    # Names only: values may be passwords and API keys. The page telling
    # the server its language isn't somebody changing settings.
    changed = sorted(
        key
        for key in after
        if after.get(key) != previous.get(key) and key != 'ui_language'
    )
    if changed:
        await log_activity(
            request, 'settings_changed', ', '.join(changed), {'keys': changed}
        )
    return state.settings


async def _json_object(request: Request) -> dict[str, Any]:
    try:
        payload = await request.json()
    except Exception:
        return {}
    return payload if isinstance(payload, dict) else {}


@router.post('/api/slskd/test')
async def test_slskd_endpoint(request: Request) -> dict[str, Any]:
    """Try a slskd configuration without saving it.

    The body is the ``slskd`` settings object as it stands in the form; an
    empty body tests the saved one. A failed test is a normal answer, not
    an error: ``{ok, server, checks: [{id, status, code, detail}]}``.
    """

    payload = await _json_object(request)
    saved = state.settings.get('slskd')
    cfg = _effective_slskd_settings({
        **state.settings,
        'slskd': payload or (saved if isinstance(saved, dict) else {}),
    })
    return await asyncio.to_thread(integration_check.check_slskd, cfg)


@router.post('/api/usenet/cleanup')
def cleanup_usenet_endpoint() -> dict[str, Any]:
    """Delete every finished SABnzbd history entry and its files.

    Manual counterpart of the automatic per-track cleanup: album folders
    kept for reuse are removed here too.
    """

    cfg = _effective_usenet_settings(state.settings)
    client = UsenetSabnzbdClient(cfg)
    if not client.configured():
        raise HTTPException(status_code=400, detail='usenet_not_configured')
    return {'deleted': client.delete_all_history()}


@router.post('/api/usenet/test')
async def test_usenet_endpoint(request: Request) -> dict[str, Any]:
    """Try a usenet configuration without saving it.

    Same shape as ``POST /api/slskd/test``, with the ``usenet`` settings
    object (indexers plus SABnzbd connection) as the body.
    """

    payload = await _json_object(request)
    saved = state.settings.get('usenet')
    cfg = _effective_usenet_settings({
        **state.settings,
        'usenet': payload or (saved if isinstance(saved, dict) else {}),
    })
    return await asyncio.to_thread(integration_check.check_usenet, cfg)


@router.post('/api/navidrome/test')
async def test_navidrome_endpoint(request: Request) -> dict[str, Any]:
    """Try a Navidrome configuration without saving it.

    Same shape as ``POST /api/slskd/test``, with the ``navidrome`` settings
    object as the body.
    """

    payload = await _json_object(request)
    saved = state.settings.get('navidrome')
    cfg = _effective_navidrome_settings({
        **state.settings,
        'navidrome': payload or (saved if isinstance(saved, dict) else {}),
    })
    return await asyncio.to_thread(integration_check.check_navidrome, cfg)


# ---------------------------------------------------------------------------
# Liked songs
# ---------------------------------------------------------------------------


def _require_likes() -> LikedTracks:
    if state.likes is None:
        raise HTTPException(status_code=500, detail='Likes not ready')
    return state.likes


def _admin_like_scope() -> set[int]:
    """Whose likes the shared playlist file holds: every admin's, plus
    pre-feature rows (``user_id`` ``0``, made when likes belonged to
    whoever ran the single-user server)."""

    ids = {0}
    try:
        users = state.auth.users if state.auth is not None else None
        for user in users.list() if users is not None else []:
            if user.get('role') == 'admin':
                ids.add(int(user['id']))
    except Exception:
        logger.opt(exception=True).debug('Could not resolve the admin set')
    return ids


def _sync_liked_playlist() -> None:
    """Rewrite (or remove) the liked songs playlist to match the likes."""

    if state.likes is None or state.downloader is None:
        return
    ctx = library_context()
    try:
        sync_liked_playlist(
            state.likes,
            ctx.download_dir,
            ctx.slskd_dir,
            ctx.extra_dirs,
            user_ids=_admin_like_scope(),
        )
    except Exception:
        logger.exception('Liked songs playlist sync failed')


_LIBRARY_ANNOUNCE_DELAY = 2.0
# The pending "library changed" broadcast, if one is scheduled.
_library_announce: dict[str, Optional[asyncio.TimerHandle]] = {'timer': None}


def _broadcast_library_changed() -> None:
    _library_announce['timer'] = None
    spawn_task(
        state.connections.broadcast({'type': 'library_changed'}),
        name='library-changed',
    )


def _schedule_library_changed() -> None:
    loop = state.loop
    if loop is None or _library_announce['timer'] is not None:
        return
    _library_announce['timer'] = loop.call_later(
        _LIBRARY_ANNOUNCE_DELAY, _broadcast_library_changed
    )


def announce_library_changed() -> None:
    """Tell connected clients (the apps) the library changed, so they
    sync - at most once every couple of seconds, however many files a
    batch download adds. Safe from any thread."""

    loop = state.loop
    if loop is None:
        return
    loop.call_soon_threadsafe(_schedule_library_changed)


add_invalidation_listener(announce_library_changed)


def _announce_likes() -> None:
    """Tell open pages the likes changed, from any thread."""

    loop = state.loop
    if loop is None or state.likes is None:
        return
    asyncio.run_coroutine_threadsafe(
        state.connections.broadcast({
            'type': 'likes',
            'count': state.likes.count(),
        }),
        loop,
    )


def _clear_likes(user_id: Optional[int] = None) -> int:
    likes = _require_likes()
    cleared = likes.clear(user_id)
    _sync_liked_playlist()
    _announce_likes()
    return cleared


def likes_scope(request: Request) -> Optional[int]:
    """Whose likes *request* sees: ``None`` (everyone's) for an admin."""

    return None if request_is_admin(request) else request_user_id(request)


@router.get('/api/likes')
def get_likes(request: Request) -> dict[str, Any]:
    """The liked files, newest like first, and the playlist's name.

    ``files`` are library paths, the same ones ``GET /tracks`` uses.
    A user sees their own hearts; an admin sees everyone's.
    """

    likes = _require_likes()
    files = likes.paths(likes_scope(request))
    return {
        'files': files,
        'count': len(files),
        'playlist': m3u.sanitize_playlist_name(LIKED_PLAYLIST_NAME),
    }


@router.put('/api/likes')
async def set_like(request: Request) -> dict[str, Any]:
    """Like or unlike one library file: ``{file, liked}``.

    Idempotent — sending the state you want twice changes nothing — so a
    client can retry a tap that may not have arrived. Liking needs a file
    that is in the library; unliking accepts any path, so a heart on a
    file that has since vanished can still be cleared. The heart belongs
    to whoever tapped it.
    """

    payload = await _json_object(request)
    file = str(payload.get('file') or '').strip().replace('\\', '/')
    if not file:
        raise HTTPException(status_code=400, detail='file is required')
    liked = bool(payload.get('liked', True))
    result = await apply_like(file, liked, user_id=request_user_id(request))
    await log_activity(request, 'like' if liked else 'unlike', file)
    return result


async def apply_like(
    file: str, liked: bool, user_id: int = 0
) -> dict[str, Any]:
    """Like or unlike a library path (``PUT /api/likes`` and, by track
    id, ``PUT /api/v1/likes``)."""

    likes = _require_likes()

    if liked:
        full = resolve_library_file(file, library_context())
        if full is None:
            raise HTTPException(status_code=404, detail='File not found')
        meta = await asyncio.to_thread(read_audio_metadata, full)
        changed = await asyncio.to_thread(
            lambda: likes.like(
                file,
                content_key=content_key_for(full),
                title=str(meta.get('title') or full.stem),
                artist=str(meta.get('artist') or ''),
                duration=float(meta.get('duration') or 0.0),
                user_id=user_id,
            )
        )
    else:
        changed = await asyncio.to_thread(likes.unlike, file, user_id)

    if changed:
        await asyncio.to_thread(_sync_liked_playlist)
        _announce_likes()
    scope = None if user_id in _admin_like_scope() else user_id
    return {'file': file, 'liked': liked, 'count': likes.count(scope)}


@router.post('/api/likes/clear')
async def clear_likes_endpoint(request: Request) -> dict[str, Any]:
    """Unlike everything of one's own (everything for an admin), which
    also takes the playlist away.

    Only the hearts and the playlist file go; no song is deleted.
    """

    cleared = await asyncio.to_thread(_clear_likes, likes_scope(request))
    return {'cleared': cleared, 'count': 0}


# ── Discover ─────────────────────────────────────────────────────────
def _require_discover() -> DiscoverStore:
    if state.discover is None:
        raise HTTPException(status_code=500, detail='Discover store not ready')
    return state.discover


@router.post('/api/discover')
async def discover_endpoint(request: Request) -> dict[str, Any]:
    """Artists the library doesn't have yet, suggested from the ones it
    does (see ``downtify.discover``).

    Body ``{library: [{name, tracks, liked}]}``: every library artist with
    its track and liked-track counts, as the Library page groups them. The
    server adds how often each was listened to, and leaves out the library
    and the block list. A Deezer failure for some seeds isn't an error -
    the rest still count, and ``partial`` says so.
    """

    store = _require_discover()
    payload = await _json_object(request)
    library = payload.get('library')
    if not isinstance(library, list):
        raise HTTPException(status_code=400, detail='library is required')
    return await asyncio.to_thread(
        recommendations, store, library, user_id=request_user_id(request)
    )


@router.post('/api/discover/collections')
async def discover_collections_endpoint(request: Request) -> dict[str, Any]:
    """Albums and playlists for the library (see
    ``downtify.discover.collections``).

    Body: the same ``library`` as ``POST /api/discover``, plus ``albums``
    (``{artist, title}`` per library album) and ``playlist_ids`` (Spotify
    ids of downloaded playlists), both left out of the answer.
    """

    store = _require_discover()
    payload = await _json_object(request)
    library = payload.get('library')
    if not isinstance(library, list):
        raise HTTPException(status_code=400, detail='library is required')
    albums = payload.get('albums')
    playlist_ids = payload.get('playlist_ids')
    return await asyncio.to_thread(
        collections,
        store,
        library,
        albums if isinstance(albums, list) else [],
        playlist_ids if isinstance(playlist_ids, list) else [],
    )


def _list_field(payload: dict[str, Any], name: str) -> list[Any]:
    value = payload.get(name)
    return value if isinstance(value, list) else []


@router.post('/api/discover/collections/deezer')
async def discover_deezer_collections_endpoint(
    request: Request,
) -> dict[str, Any]:
    """Albums and playlists for the library from Deezer alone - the web
    page's first answer (see ``downtify.discover.deezer_collections``).

    Body: what ``POST /api/discover/collections`` takes, plus
    ``playlist_names`` (the library's playlist names, so a Deezer playlist
    already downloaded isn't suggested).
    """

    store = _require_discover()
    payload = await _json_object(request)
    library = payload.get('library')
    if not isinstance(library, list):
        raise HTTPException(status_code=400, detail='library is required')
    return await asyncio.to_thread(
        deezer_collections,
        store,
        library,
        _list_field(payload, 'albums'),
        _list_field(payload, 'playlist_names'),
    )


@router.post('/api/discover/collections/spotify')
async def discover_spotify_collections_endpoint(
    request: Request,
) -> dict[str, Any]:
    """What Spotify adds to the Deezer answer, its albums matched to Deezer
    - the web page's second answer (see
    ``downtify.discover.spotify_collections``).

    Body: what ``POST /api/discover/collections`` takes, plus ``shown``
    (the album ``key``\\ s the page already shows, left out unmatched).
    """

    store = _require_discover()
    payload = await _json_object(request)
    library = payload.get('library')
    if not isinstance(library, list):
        raise HTTPException(status_code=400, detail='library is required')
    return await asyncio.to_thread(
        spotify_collections,
        store,
        library,
        _list_field(payload, 'albums'),
        _list_field(payload, 'playlist_ids'),
        _list_field(payload, 'shown'),
    )


@router.get('/api/preview')
async def song_preview_endpoint(
    artist: str = Query(...),
    title: str = Query(...),
    duration: Optional[float] = Query(None),
) -> dict[str, str]:
    """A song's 30 s preview clip from Deezer, for a song without one of
    its own (a YouTube Music result, a long Spotify playlist's later
    tracks). ``""`` when Deezer has no song by that artist with that
    title; ``503`` when Deezer couldn't be asked."""

    try:
        url = await asyncio.to_thread(
            deezer.find_track_preview, artist, title, duration
        )
    except ValueError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    return {'preview_url': url}


@router.get('/api/similar/tracks')
async def similar_tracks_endpoint(
    artist: str = Query('', max_length=200),
    track: str = Query('', max_length=200),
    limit: int = Query(20, ge=1, le=50),
) -> dict[str, Any]:
    """Tracks similar to *track* by *artist*, from YouTube Music's own
    radio mix for the track (see
    ``downtify.providers.youtube_similar_tracks``). Either *artist*
    or *track* alone is enough for a seed.

    Response ``{artist, track, source, tracks}`` - downloadable song
    rows plus ``match``. ``502`` when YouTube Music can't be used.
    """

    try:
        return await asyncio.to_thread(
            providers.youtube_similar_tracks,
            artist,
            track,
            limit=limit,
        )
    except ValueError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@router.get('/api/stream')
async def stream_endpoint(
    video_id: str = Query(..., min_length=1, max_length=64),
) -> dict[str, str]:
    """A track's full audio as a fresh direct URL (``?video_id=``).

    What plays in the built-in player when the song behind a row isn't
    downloaded yet: no download, no tags, nothing stored. The URL is
    short-lived and bound to this server's network, so it is fetched
    on demand and never cached or persisted - ask again rather than
    storing it. ``400`` for a malformed id, ``503`` when YouTube can't
    be reached or refuses (including age-gated tracks without usable
    cookies - see Settings > YouTube cookies).
    """

    try:
        vid = stream.clean_video_id(video_id)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    try:
        cookies = await asyncio.to_thread(
            stream.resolve_cookies_file, state.cookies_store
        )
        resolved = await asyncio.to_thread(
            stream.stream_url_for_video, vid, cookies_file=cookies
        )
    except ValueError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    return {'url': resolved['url']}


@router.get('/api/stream/file')
async def stream_file_endpoint(
    request: Request,
    video_id: str = Query(..., min_length=1, max_length=64),
    duration: float = Query(0, ge=0),
) -> FileResponse:
    """A track's full audio, downloaded once and served from this server.

    ``GET /api/stream/file?video_id=`` is what the web player behind a
    song that isn't downloaded yet plays: the first request downloads
    the audio into ``/data/stream_cache`` (concurrent requests for the
    same video share one download), later ones are served from disk.
    Served with seeking support, pruned least-recently-used past
    ``DOWNTIFY_STREAM_CACHE_MB`` (see ``downtify.stream``). ``duration``
    (seconds, when the caller knows it) refuses long tracks before any
    download; the served file is probed either way. ``400`` for a
    malformed id or a track past the duration limit (Settings →
    Downloads), ``503`` when YouTube can't provide the audio.
    """

    try:
        vid = stream.clean_video_id(video_id)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    limit = _max_track_duration_seconds()
    if limit and duration > limit:
        raise HTTPException(
            status_code=400, detail=stream.too_long_detail(limit)
        )
    cache = state.stream_cache
    if cache is None:
        raise HTTPException(
            status_code=503, detail='Streaming is not ready yet'
        )
    cookies = stream.resolve_cookies_file(state.cookies_store)
    was_cached = await asyncio.to_thread(cache.cached_path, vid) is not None
    try:
        path = await cache.get(vid, cookies_file=cookies, max_seconds=limit)
    except TrackTooLongError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    if not was_cached:
        record_stream_fetch_traffic(path, request_user_id(request))
    return FileResponse(
        str(path),
        media_type=stream.media_type_for(path),
        filename=f'{vid}{path.suffix}',
    )


async def _prefetch_stream_video(
    cache: StreamCache,
    video_id: str,
    cookies_file: str,
    max_seconds: Optional[int] = None,
) -> None:
    """Cache one video's audio in the background (never raises)."""

    try:
        await cache.get(
            video_id, cookies_file=cookies_file, max_seconds=max_seconds
        )
    except Exception:
        logger.debug('Stream prefetch failed for videoId={}', video_id)


@router.post('/api/stream/prefetch')
async def stream_prefetch_endpoint(request: Request) -> dict[str, bool]:
    """Start caching a video's audio without waiting for it.

    Body ``{video_id}``; answers ``{queued: true}`` at once while the
    download continues detached, so the player can warm the next track
    up while the current one is still loading. ``400`` for a malformed
    id, ``503`` when streaming isn't ready.
    """

    payload = await _json_object(request)
    try:
        vid = stream.clean_video_id(payload.get('video_id'))
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    cache = state.stream_cache
    if cache is None:
        raise HTTPException(
            status_code=503, detail='Streaming is not ready yet'
        )
    cookies = stream.resolve_cookies_file(state.cookies_store)
    spawn_task(
        _prefetch_stream_video(
            cache, vid, cookies, _max_track_duration_seconds()
        ),
        name=f'stream-prefetch-{vid}',
    )
    return {'queued': True}


@router.post('/api/discover/listens')
async def record_listen_endpoint(request: Request) -> dict[str, Any]:
    """Count one listen to ``{artist}`` - sent by the player once a track
    has played long enough to count.

    An app may also send ``track_id`` instead of ``artist`` (the track's
    album artist is used), ``played_at`` (ISO 8601, for plays it reports
    after being offline; a future time counts as now) and ``play_id``
    (the same play reported twice counts once).
    """

    store = _require_discover()
    payload = await _json_object(request)
    artist = str(payload.get('artist') or '')
    track_id = str(payload.get('track_id') or '')
    if not artist and track_id and state.library_sync is not None:
        row = await asyncio.to_thread(state.library_sync.row_for, track_id)
        artist = str((row or {}).get('album_artist') or '')
    when = _played_at(payload.get('played_at'))
    row = await asyncio.to_thread(
        store.record_listen,
        artist,
        when,
        str(payload.get('play_id') or '').strip(),
        request_user_id(request),
    )
    if row is None:
        raise HTTPException(status_code=400, detail='artist is required')
    return row


def _played_at(value: Any) -> Optional[datetime]:
    """``played_at`` from a listen report: ``None`` (now) when missing,
    unreadable or in the future."""

    if not value:
        return None
    try:
        when = datetime.fromisoformat(str(value).replace('Z', '+00:00'))
    except ValueError:
        return None
    if when.tzinfo is None:
        when = when.replace(tzinfo=timezone.utc)
    return None if when > datetime.now(timezone.utc) else when


@router.delete('/api/discover/listens')
async def clear_listens_endpoint(request: Request) -> dict[str, Any]:
    """Forget every counted listen of one's own. The library and likes
    are untouched."""

    store = _require_discover()
    scope = None if request_is_admin(request) else request_user_id(request)
    cleared = await asyncio.to_thread(store.clear_listens, scope)
    return {'cleared': cleared}


@router.get('/api/discover/blocked')
async def blocked_artists_endpoint(request: Request) -> list[dict[str, Any]]:
    store = _require_discover()
    scope = None if request_is_admin(request) else request_user_id(request)
    return await asyncio.to_thread(store.blocked, scope)


@router.post('/api/discover/blocked')
async def block_artist_endpoint(request: Request) -> dict[str, Any]:
    """Never suggest ``{name}`` again. Blocking twice is a no-op."""

    store = _require_discover()
    payload = await _json_object(request)
    row = await asyncio.to_thread(
        store.block, str(payload.get('name') or ''), request_user_id(request)
    )
    if row is None:
        raise HTTPException(status_code=400, detail='name is required')
    return row


@router.delete('/api/discover/blocked')
async def unblock_artist_endpoint(
    request: Request, name: str = Query(...)
) -> dict[str, Any]:
    store = _require_discover()
    scope = None if request_is_admin(request) else request_user_id(request)
    removed = await asyncio.to_thread(store.unblock, name, scope)
    return {'name': name, 'removed': removed}


# ── Podcasts ─────────────────────────────────────────────────────────
def _require_podcasts() -> PodcastStore:
    if state.podcasts is None:
        raise HTTPException(status_code=500, detail='Podcast store not ready')
    return state.podcasts


def _podcast_watch(
    feed_url: str, user_id: Optional[int] = None
) -> Optional[MonitoredPlaylist]:
    db = state.monitor_db
    if db is None:
        return None
    return db.get_by_spotify_id(feed_url, user_id)


def _podcast_show_for_request(
    show_id: int, request: Optional[Request]
) -> Optional[dict[str, Any]]:
    """The show when *request* may open it (own or admin's)."""

    podcasts = state.podcasts
    if podcasts is None:
        return None
    show = podcasts.get_show(show_id)
    if show is None:
        return None
    if request_is_admin(request):
        return show
    user_id = request_user_id(request)
    if user_id and int(show.get('user_id') or 0) == user_id:
        return show
    return None


def _podcast_episode_for_request(
    episode_id: int, request: Optional[Request]
) -> Optional[dict[str, Any]]:
    """The episode (with its show) when *request* may open it."""

    podcasts = state.podcasts
    if podcasts is None:
        return None
    episode = podcasts.get_episode(episode_id)
    if episode is None:
        return None
    show = _podcast_show_for_request(episode['show_id'], request)
    if show is None:
        return None
    return episode


def _show_payload(
    show: dict[str, Any],
    watch: Optional[MonitoredPlaylist],
    user_id: int = 0,
) -> dict[str, Any]:
    episodes = (
        state.podcasts.list_episodes(show['id'], user_id=user_id)
        if state.podcasts
        else []
    )
    downloaded = sum(
        1 for e in episodes if e['filename'] and not e['dismissed']
    )
    return {
        **show,
        'watch_id': watch.id if watch else None,
        'interval_minutes': watch.interval_minutes if watch else None,
        'enabled': watch.enabled if watch else None,
        'last_checked': watch.last_checked if watch else None,
        'episode_count': len(episodes),
        'downloaded_count': downloaded,
    }


@router.post('/api/podcasts/resolve')
async def resolve_podcast(request: Request) -> dict[str, Any]:
    """Preview a podcast from a pasted link, before subscribing.

    Accepts a direct RSS feed URL or a Spotify show/episode link (see
    ``downtify.podcasts`` for how the latter is matched to a feed). Use
    ``GET /api/podcasts/search`` for free-text search instead.
    """

    payload = await _json_object(request)
    url = str(payload.get('url') or '').strip()
    if not url:
        raise HTTPException(status_code=400, detail='url is required')

    matched_guid = None
    if spotify.parse_spotify_url(url) is not None:
        try:
            feed, matched_guid = await asyncio.to_thread(
                resolve_spotify_podcast, url
            )
        except PodcastFeedNotFoundError as exc:
            raise HTTPException(
                status_code=404,
                detail=(
                    f'"{exc.show_name}" has no public RSS feed — likely a '
                    'Spotify-exclusive show, which Downtify cannot download'
                ),
            ) from exc
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
    else:
        try:
            feed = await asyncio.to_thread(fetch_feed, url)
        except Exception as exc:
            raise HTTPException(
                status_code=400,
                detail='Could not read a podcast feed from that link',
            ) from exc
        if not feed.episodes and not feed.name:
            raise HTTPException(
                status_code=400,
                detail='That link is not a podcast RSS feed',
            )

    scope = None if request_is_admin(request) else request_user_id(request)
    existing = await asyncio.to_thread(_podcast_watch, feed.feed_url, scope)
    if existing is None and not request_is_admin(request):
        podcasts = _require_podcasts()
        show = await asyncio.to_thread(
            podcasts.get_show_by_feed_url, feed.feed_url, scope
        )
        subscribed = show is not None
    else:
        subscribed = existing is not None
    return {
        'show': {
            'name': feed.name,
            'author': feed.author,
            'description': feed.description,
            'artwork_url': feed.artwork_url,
            'feed_url': feed.feed_url,
            'source_url': url,
        },
        'episodes': [vars(e) for e in feed.episodes],
        'matched_episode_guid': matched_guid,
        'already_subscribed': subscribed,
    }


@router.get('/api/podcasts/search')
async def search_podcasts_endpoint(q: str = '') -> dict[str, Any]:
    """Free-text podcast search, via the iTunes podcast directory."""

    results = await asyncio.to_thread(search_shows, q, 10)
    return {'results': results}


@router.post('/api/podcasts/subscribe')
async def subscribe_podcast(request: Request) -> dict[str, Any]:
    """Subscribe to a show resolved with ``POST /api/podcasts/resolve``.

    Subscriptions belong to whoever subscribes (an admin sees every
    show); the same feed subscribed twice lands in two folders.
    """

    podcasts = _require_podcasts()
    db = _require_monitor_db()
    user_id = request_user_id(request)
    payload = await _json_object(request)
    feed_url = str(payload.get('feed_url') or '').strip()
    name = str(payload.get('name') or '').strip()
    if not feed_url or not name:
        raise HTTPException(
            status_code=400, detail='feed_url and name are required'
        )
    if (
        await asyncio.to_thread(db.get_by_spotify_id, feed_url, user_id)
        is not None
    ):
        raise HTTPException(
            status_code=409, detail='Already subscribed to this podcast'
        )
    retention = max(0, int(payload.get('retention') or 0))
    interval_minutes = int(payload.get('interval_minutes') or 720)

    show = await asyncio.to_thread(
        podcasts.add_show,
        feed_url,
        name,
        author=str(payload.get('author') or ''),
        description=str(payload.get('description') or ''),
        artwork_url=str(payload.get('artwork_url') or ''),
        source_url=str(payload.get('source_url') or feed_url),
        retention=retention,
        user_id=user_id,
    )
    watch = await asyncio.to_thread(
        db.add_playlist,
        feed_url,
        name,
        str(payload.get('source_url') or feed_url),
        interval_minutes,
        KIND_PODCAST,
        user_id=user_id,
    )
    _start_initial_check(watch, db)
    return _show_payload(show, watch, user_id)


@router.get('/api/podcasts/shows')
async def list_podcast_shows(request: Request) -> list[dict[str, Any]]:
    podcasts = _require_podcasts()
    scope = None if request_is_admin(request) else request_user_id(request)
    shows = await asyncio.to_thread(podcasts.list_shows, scope)
    user_id = request_user_id(request)
    return [
        _show_payload(s, _podcast_watch(s['feed_url'], user_id), user_id)
        for s in shows
    ]


@router.get('/api/podcasts/shows/{show_id}')
async def get_podcast_show(request: Request, show_id: int) -> dict[str, Any]:
    show = _podcast_show_for_request(show_id, request)
    if show is None:
        raise HTTPException(status_code=404, detail='Show not found')
    user_id = request_user_id(request)
    return _show_payload(
        show, _podcast_watch(show['feed_url'], user_id), user_id
    )


@router.get('/api/podcasts/shows/{show_id}/episodes')
async def list_podcast_episodes(
    request: Request, show_id: int, include_dismissed: bool = False
) -> dict[str, Any]:
    show = _podcast_show_for_request(show_id, request)
    if show is None:
        raise HTTPException(status_code=404, detail='Show not found')
    podcasts = _require_podcasts()
    user_id = request_user_id(request)
    episodes = await asyncio.to_thread(
        podcasts.list_episodes,
        show_id,
        include_dismissed=include_dismissed,
        user_id=user_id,
    )
    return {'show': show, 'episodes': episodes}


@router.patch('/api/podcasts/shows/{show_id}')
async def update_podcast_show(
    show_id: int, request: Request
) -> dict[str, Any]:
    show = _podcast_show_for_request(show_id, request)
    if show is None:
        raise HTTPException(status_code=404, detail='Show not found')
    podcasts = _require_podcasts()
    payload = await _json_object(request)

    if 'retention' in payload:
        show = await asyncio.to_thread(
            podcasts.update_show,
            show_id,
            retention=max(0, int(payload['retention'] or 0)),
        )
        if show is None:
            raise HTTPException(status_code=404, detail='Show not found')

    user_id = request_user_id(request)
    scope = None if request_is_admin(request) else user_id
    watch = _podcast_watch(show['feed_url'], scope)
    db = state.monitor_db
    if watch is not None and db is not None:
        kwargs: dict[str, Any] = {}
        if 'interval_minutes' in payload:
            kwargs['interval_minutes'] = int(payload['interval_minutes'])
        if 'enabled' in payload:
            kwargs['enabled'] = bool(payload['enabled'])
        if kwargs:
            watch = await asyncio.to_thread(
                db.update_playlist, watch.id, **kwargs
            )

    return _show_payload(show, watch, user_id)


@router.delete('/api/podcasts/shows/{show_id}')
async def delete_podcast_show(
    request: Request, show_id: int, keep_files: bool = False
) -> dict[str, Any]:
    """Unsubscribe, deleting downloaded episodes unless ``keep_files``."""

    show = _podcast_show_for_request(show_id, request)
    if show is None:
        raise HTTPException(status_code=404, detail='Show not found')
    podcasts = _require_podcasts()
    show = await asyncio.to_thread(podcasts.delete_show, show_id)
    if show is None:
        raise HTTPException(status_code=404, detail='Show not found')
    watch = _podcast_watch(show['feed_url'], show['user_id'])
    if watch is not None and state.monitor_db is not None:
        await asyncio.to_thread(state.monitor_db.delete_playlist, watch.id)
    deleted_files = False
    if not keep_files:
        show_dir = (
            Path(state.downloader.download_dir)
            / PODCASTS_DIRNAME
            / show['folder_name']
            if state.downloader is not None
            else None
        )
        if show_dir is not None and show_dir.is_dir():
            await asyncio.to_thread(
                shutil.rmtree, show_dir, ignore_errors=True
            )
            deleted_files = True
        invalidate_library_paths_cache()
    return {'ok': True, 'show': show, 'files_deleted': deleted_files}


@router.post('/api/podcasts/episodes/{episode_id}/download')
async def download_podcast_episode(
    request: Request, episode_id: int
) -> dict[str, Any]:
    """Download one episode on demand, outside the retention policy."""

    episode = _podcast_episode_for_request(episode_id, request)
    if episode is None:
        raise HTTPException(status_code=404, detail='Episode not found')
    podcasts = _require_podcasts()
    show = await asyncio.to_thread(podcasts.get_show, episode['show_id'])
    if show is None:
        raise HTTPException(status_code=404, detail='Show not found')
    if state.downloader is None:
        raise HTTPException(status_code=500, detail='Downloader not ready')

    info = EpisodeInfo(
        guid=episode['guid'],
        title=episode['title'],
        description=episode['description'],
        published_at=episode['published_at'],
        duration_seconds=episode['duration_seconds'],
        season_number=episode['season_number'],
        episode_number=episode['episode_number'],
        enclosure_url=episode['enclosure_url'],
        enclosure_type=episode['enclosure_type'],
    )
    loop = state.loop or asyncio.get_running_loop()

    def _progress(pct: float) -> None:
        asyncio.run_coroutine_threadsafe(
            state.connections.broadcast({
                'type': 'podcast_progress',
                'show': show['name'],
                'episode': episode['title'],
                'progress': pct,
            }),
            loop,
        )

    try:
        cover_bytes = await asyncio.to_thread(
            best_cover_bytes, show['artwork_url']
        )
        filename = await asyncio.to_thread(
            download_episode,
            info,
            show_name=show['name'],
            author=show['author'],
            folder_name=show['folder_name'],
            download_dir=Path(state.downloader.download_dir),
            cover_bytes=cover_bytes,
            progress=_progress,
        )
    except Exception as exc:
        raise HTTPException(
            status_code=502, detail=f'Download failed: {exc}'
        ) from exc
    await asyncio.to_thread(podcasts.mark_downloaded, episode_id, filename)
    invalidate_library_paths_cache()
    await state.connections.broadcast({'type': 'podcasts'})
    return await asyncio.to_thread(podcasts.get_episode, episode_id)


@router.delete('/api/podcasts/episodes/{episode_id}')
async def delete_podcast_episode(
    request: Request, episode_id: int
) -> dict[str, Any]:
    """Remove a downloaded episode's file; never auto-downloaded again."""

    episode = _podcast_episode_for_request(episode_id, request)
    if episode is None:
        raise HTTPException(status_code=404, detail='Episode not found')
    podcasts = _require_podcasts()
    if episode['filename'] and state.downloader is not None:
        full = Path(state.downloader.download_dir) / episode['filename']
        try:
            await asyncio.to_thread(full.unlink, missing_ok=True)
        except OSError:
            logger.opt(exception=True).warning(
                'Could not remove podcast episode file {}', full
            )
        invalidate_library_paths_cache()
    await asyncio.to_thread(
        podcasts.prune_download, episode_id, dismissed=True
    )
    await state.connections.broadcast({'type': 'podcasts'})
    return {'ok': True}


@router.put('/api/podcasts/episodes/{episode_id}/playback')
async def set_podcast_playback(
    episode_id: int, request: Request
) -> dict[str, Any]:
    """Save an episode's resume position and/or played state.

    Called periodically while a podcast episode plays (throttled on the
    client) and once more on pause/seek/close, so the position survives
    a reload or a switch to another device.
    """

    podcasts = _require_podcasts()
    if _podcast_episode_for_request(episode_id, request) is None:
        raise HTTPException(status_code=404, detail='Episode not found')
    payload = await _json_object(request)
    position = payload.get('position_seconds')
    played = payload.get('played')
    user_id = request_user_id(request)
    await asyncio.to_thread(
        podcasts.set_playback,
        episode_id,
        position_seconds=float(position) if position is not None else None,
        played=bool(played) if played is not None else None,
        user_id=user_id,
    )
    return await asyncio.to_thread(podcasts.get_episode, episode_id, user_id)


@router.websocket('/api/ws')
async def websocket_endpoint(
    ws: WebSocket, client_id: str = Query(...)
) -> None:
    principal = (ws.scope.get('state') or {}).get('principal')
    await state.connections.connect(
        client_id,
        ws,
        getattr(principal, 'device_id', '') or '',
        getattr(principal, 'user_id', 0) or 0,
        bool(getattr(principal, 'is_admin', False)),
    )
    try:
        while True:
            await ws.receive_text()
    except WebSocketDisconnect:
        state.connections.disconnect(client_id)
    except Exception:
        state.connections.disconnect(client_id)


# ---------------------------------------------------------------------------
# Playlist monitoring endpoints
# ---------------------------------------------------------------------------


def _require_monitor_db() -> PlaylistMonitorDB:
    if state.monitor_db is None:
        raise HTTPException(
            status_code=500, detail='Monitor database not ready'
        )
    return state.monitor_db


def _youtube_artist_for_name(name: str) -> tuple[str, str]:
    """Find the YouTube Music artist channel that matches *name*.

    Spotify's artist embed exposes no discography (only a top-tracks
    preview), so a watched Spotify artist is followed through YouTube
    Music instead — which is also where the audio is fetched from, so
    every release we can see is one we can actually download. Returns
    ``(channel_id, resolved_name)``.
    """

    results = providers.search_artists(name, limit=10)
    if not results:
        raise HTTPException(
            status_code=404,
            detail=f'No YouTube Music artist found for {name!r}',
        )
    wanted = name.casefold().strip()
    exact = [
        r
        for r in results
        if str(r.get('name') or '').casefold().strip() == wanted
    ]
    best = (exact or results)[0]
    channel_id = str(best.get('artist_id') or '')
    if not channel_id:
        raise HTTPException(
            status_code=502,
            detail=f'YouTube Music artist for {name!r} has no channel id',
        )
    return channel_id, str(best.get('name') or name)


async def _resolve_watch_target(url: str) -> tuple[str, str, str]:
    """Resolve a pasted URL into ``(kind, watch_key, display_name)``.

    Accepts a Spotify or YouTube Music playlist URL (watched by its
    tracks), and a Spotify artist URL or a YouTube Music artist URL
    (``/channel/UC...`` or ``/@handle``, watched by their discography).
    """

    playlist_target = parse_playlist_url(url)
    if playlist_target is not None:
        _, playlist_id = playlist_target
        try:
            name, _tracks = await asyncio.to_thread(
                fetch_playlist, *playlist_target
            )
        except Exception as exc:
            logger.exception('Failed to resolve playlist {}', playlist_id)
            raise HTTPException(status_code=502, detail=str(exc)) from exc
        return KIND_PLAYLIST, playlist_id, name

    spotify_parsed = spotify.parse_spotify_url(url)
    if spotify_parsed is not None and spotify_parsed[0] == 'artist':
        _, artist_id = spotify_parsed
        try:
            spotify_name = await asyncio.to_thread(
                spotify.artist_name_from_id, artist_id
            )
        except Exception as exc:
            logger.exception('Failed to resolve artist {}', artist_id)
            raise HTTPException(status_code=502, detail=str(exc)) from exc
        channel_id, name = await asyncio.to_thread(
            _youtube_artist_for_name, spotify_name
        )
        return KIND_ARTIST, channel_id, name

    youtube_parsed = providers.parse_youtube_url(url)
    if youtube_parsed is not None and youtube_parsed[0] == 'artist':
        _, channel_or_handle = youtube_parsed
        try:
            channel_id = await asyncio.to_thread(
                providers.resolve_artist_channel_id, channel_or_handle
            )
            info = await asyncio.to_thread(
                providers.artist_info_from_channel_id, channel_id
            )
        except ValueError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        except Exception as exc:
            logger.exception(
                'Failed to resolve artist channel {}', channel_or_handle
            )
            raise HTTPException(status_code=502, detail=str(exc)) from exc
        return KIND_ARTIST, channel_id, str(info.get('name') or channel_id)

    raise HTTPException(
        status_code=400,
        detail=(
            'A Spotify or YouTube Music playlist URL, or a Spotify or '
            'YouTube Music artist URL, is required'
        ),
    )


def _monitor_watch_for_request(
    playlist_id: int, request: Optional[Request]
) -> Optional[MonitoredPlaylist]:
    """The watch when *request* may touch it (own or admin's)."""

    db = state.monitor_db
    if db is None:
        return None
    watch = db.get_playlist(playlist_id)
    if watch is None:
        return None
    if request_is_admin(request):
        return watch
    user_id = request_user_id(request)
    if user_id and watch.user_id == user_id:
        return watch
    return None


@router.get('/api/monitor/playlists')
async def list_monitor_playlists(request: Request) -> list[dict[str, Any]]:
    db = _require_monitor_db()
    scope = None if request_is_admin(request) else request_user_id(request)
    playlists = await asyncio.to_thread(db.list_playlists, scope)
    return [p.to_dict() for p in playlists]


@router.post('/api/monitor/playlists')
async def add_monitor_playlist(request: Request) -> dict[str, Any]:
    db = _require_monitor_db()
    user_id = request_user_id(request)
    try:
        payload = await request.json()
    except Exception:
        payload = {}

    url = payload.get('url', '')
    interval_minutes = int(payload.get('interval_minutes', 60))
    release_types = _release_types_from(payload)

    kind, watch_key, name = await _resolve_watch_target(url)
    # Release filters only mean something for an artist's discography.
    new_only = kind == KIND_ARTIST and bool(payload.get('new_only'))
    if kind != KIND_ARTIST:
        release_types = ALL_RELEASE_TYPES

    existing = await asyncio.to_thread(
        db.get_by_spotify_id, watch_key, user_id
    )
    if existing is not None:
        raise HTTPException(
            status_code=409,
            detail=(
                'This artist is already being watched'
                if kind == KIND_ARTIST
                else 'This playlist is already being monitored'
            ),
        )

    playlist = await asyncio.to_thread(
        db.add_playlist,
        watch_key,
        name,
        url,
        interval_minutes,
        kind,
        release_types,
        new_only,
        user_id,
    )
    _start_initial_check(playlist, db)
    return playlist.to_dict()


def _release_types_from(payload: dict[str, Any]) -> str:
    """``release_types`` from a request body, in its stored form; every
    type when it isn't given. ``400`` for a list that names none."""

    if 'release_types' not in payload:
        return ALL_RELEASE_TYPES
    types = normalize_release_types(payload.get('release_types'))
    if not types:
        raise HTTPException(
            status_code=400,
            detail='Choose at least one kind of release: album, single or ep',
        )
    return types


def _start_initial_check(
    playlist: MonitoredPlaylist, db: PlaylistMonitorDB
) -> None:
    """Run a watch's first download pass now, in the background.

    Saves waiting up to a full monitor sweep for the initial backfill.
    """
    if state.downloader is None:
        return
    loop = state.loop or asyncio.get_running_loop()

    async def _initial_check() -> None:
        try:
            await check_watch(
                playlist,
                db,
                state.downloader,  # type: ignore[arg-type]
                state.connections.broadcast,
                loop,
                state.settings,
                library_stores(),
                state.podcasts,
            )
        except Exception:
            logger.exception('Initial check failed for watch {}', playlist.id)

    spawn_task(_initial_check(), name='monitor-initial-check')


async def _change_watch_url(
    db: PlaylistMonitorDB,
    current: MonitoredPlaylist,
    url: str,
    user_id: Optional[int] = None,
) -> Optional[MonitoredPlaylist]:
    """Apply a new URL to a watch; return the retargeted watch, if any.

    Another link to the same playlist or artist just replaces the stored
    URL. A link to a different one of the same kind retargets the watch
    (see :meth:`PlaylistMonitorDB.retarget_playlist`).
    """
    kind, watch_key, name = await _resolve_watch_target(url)
    if kind != current.kind:
        raise HTTPException(
            status_code=400,
            detail=(
                'This watch follows an artist; paste an artist URL'
                if current.kind == KIND_ARTIST
                else 'This watch follows a playlist; paste a playlist URL'
            ),
        )
    if watch_key == current.spotify_id:
        await asyncio.to_thread(db.update_playlist, current.id, url=url)
        return None
    other = await asyncio.to_thread(db.get_by_spotify_id, watch_key, user_id)
    if other is not None:
        raise HTTPException(
            status_code=409,
            detail=f'"{other.name}" is already being watched',
        )
    return await asyncio.to_thread(
        db.retarget_playlist, current.id, watch_key, name, url
    )


@router.patch('/api/monitor/playlists/{playlist_id}')
async def update_monitor_playlist(
    playlist_id: int, request: Request
) -> dict[str, Any]:
    db = _require_monitor_db()
    try:
        payload = await request.json()
    except Exception:
        payload = {}

    current = await asyncio.to_thread(
        _monitor_watch_for_request, playlist_id, request
    )
    if current is None:
        raise HTTPException(
            status_code=404, detail='Monitored playlist not found'
        )

    retargeted = None
    url = str(payload.get('url') or '').strip()
    if url and url != current.url:
        retargeted = await _change_watch_url(
            db,
            current,
            url,
            None if request_is_admin(request) else request_user_id(request),
        )

    kwargs: dict[str, Any] = {}
    if 'interval_minutes' in payload:
        kwargs['interval_minutes'] = int(payload['interval_minutes'])
    if 'enabled' in payload:
        kwargs['enabled'] = bool(payload['enabled'])

    # An artist's release filters: a check right away downloads what they
    # now let through (a type just turned on, the back catalog after
    # "new releases only" is turned off) instead of waiting for the
    # next scheduled one.
    filters_changed = False
    if 'release_types' in payload or 'new_only' in payload:
        if current.kind != KIND_ARTIST:
            raise HTTPException(
                status_code=400,
                detail='Release filters only apply to artist watches',
            )
        if 'release_types' in payload:
            types = _release_types_from(payload)
            filters_changed = types != current.release_types
            kwargs['release_types'] = types
        if 'new_only' in payload:
            new_only = bool(payload['new_only'])
            filters_changed = filters_changed or new_only != current.new_only
            await asyncio.to_thread(db.set_new_only, playlist_id, new_only)

    updated = await asyncio.to_thread(
        db.update_playlist, playlist_id, **kwargs
    )
    if updated is None:
        raise HTTPException(
            status_code=404, detail='Monitored playlist not found'
        )
    if (retargeted is not None or filters_changed) and updated.enabled:
        _start_initial_check(updated, db)
    return updated.to_dict()


@router.delete('/api/monitor/playlists/{playlist_id}')
async def delete_monitor_playlist(
    playlist_id: int, request: Request
) -> dict[str, Any]:
    db = _require_monitor_db()
    visible = await asyncio.to_thread(
        _monitor_watch_for_request, playlist_id, request
    )
    if visible is None:
        raise HTTPException(
            status_code=404, detail='Monitored playlist not found'
        )
    deleted = await asyncio.to_thread(db.delete_playlist, playlist_id)
    if not deleted:
        raise HTTPException(
            status_code=404, detail='Monitored playlist not found'
        )
    return {'deleted': True, 'id': playlist_id}


@router.post('/api/monitor/playlists/{playlist_id}/check')
async def manual_check_playlist(
    playlist_id: int, request: Request
) -> dict[str, Any]:
    db = _require_monitor_db()
    playlist = await asyncio.to_thread(
        _monitor_watch_for_request, playlist_id, request
    )
    if playlist is None:
        raise HTTPException(
            status_code=404, detail='Monitored playlist not found'
        )
    if state.downloader is None:
        raise HTTPException(status_code=500, detail='Downloader not ready')

    loop = state.loop or asyncio.get_running_loop()

    async def _run() -> None:
        try:
            count = await check_watch(
                playlist,
                db,
                state.downloader,
                state.connections.broadcast,
                loop,
                # Was omitted before, which silently ignored the
                # delay-between-downloads setting on a manual check.
                state.settings,
                library_stores(),
                state.podcasts,
            )
            logger.info(
                'Manual check: downloaded {} new track(s) from "{}"',
                count,
                playlist.name,
            )  # type: ignore[union-attr]
        except Exception:
            logger.exception('Manual check failed for watch {}', playlist_id)

    spawn_task(_run(), name='monitor-manual-check')
    return {'status': 'check_started', 'id': playlist_id}
