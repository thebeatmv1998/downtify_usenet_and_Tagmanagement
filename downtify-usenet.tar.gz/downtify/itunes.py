"""Fetch genre metadata from the iTunes Search API.

The public ``itunes.apple.com/search`` endpoint returns
``primaryGenreName`` for every song result — no API key or
authentication required.  This module provides a single entry-point,
:func:`fetch_genre`, that looks up a track and returns the genre
string (or ``""`` when nothing matches).
"""

from __future__ import annotations

import re
import time
import unicodedata
from threading import Lock
from typing import Any, Optional
from urllib.parse import quote_plus

import httpx
from loguru import logger

_ITUNES_SEARCH_URL = 'https://itunes.apple.com/search'
_TIMEOUT = 10  # seconds
#: Minimum spacing between API calls. iTunes' public search endpoint
#: starts answering 403 after a short burst (roughly 20 requests a
#: minute from one IP), so this is deliberately conservative: a paced
#: lookup that succeeds beats a fast one that is refused.
_MIN_INTERVAL = 1.1  # seconds between API calls (rate-limit courtesy)
#: How long to pause iTunes after it refuses a request with 403/429/5xx.
_COOLDOWN_SECONDS = 15.0
#: After this many refusals in a row, treat iTunes as down for
#: ``_DOWN_SECONDS`` and let the callers fall back to another source
#: instead of paying a cooldown for every single track.
_BLOCK_LIMIT = 3
_DOWN_SECONDS = 300.0
#: A browser-ish identity; iTunes' public endpoint is friendlier to a
#: named client than to the default httpx user agent.
_USER_AGENT = (
    'Downtify/3.4 (self-hosted music library; '
    '+https://github.com/henriquesebastiao/downtify)'
)

# ── In-memory cache ────────────────────────────────────────────────
# key = "normalized_artist|normalized_album" → genre string.
# Avoids repeated API calls when downloading a full album (all tracks
# share the same album and therefore the same genre).
_genre_cache: dict[str, str] = {}
_cache_lock = Lock()

# Same idea for cover art, which a library upgrade asks about once per
# track: every track of an album shares one artwork URL.
_artwork_cache: dict[str, str] = {}

#: Successful search responses, keyed by normalized query + limit. A
#: merge scan asks the same "artist title" query for the primary and the
#: album-disambiguation pass, and repeats across runs; without this they
#: would be two network calls each time.
_search_cache: dict[str, list[dict[str, Any]]] = {}

# Timestamp of the last outgoing request – used for rate pacing.
_last_request_time: float = 0.0
#: While ``monotonic() < _cooldown_until`` the next request waits it out;
#: while ``< _down_until`` iTunes is skipped entirely (see :data:`_BLOCK_LIMIT`).
_cooldown_until: float = 0.0
_down_until: float = 0.0
_consecutive_blocks: int = 0
_rate_lock = Lock()


# ── Text normalisation ────────────────────────────────────────────
def _normalise(text: str) -> str:
    """Lowercase, strip accents, collapse whitespace."""
    if not text:
        return ''
    # Decompose → strip combining marks → recompose
    nfkd = unicodedata.normalize('NFKD', text)
    stripped = ''.join(ch for ch in nfkd if unicodedata.category(ch) != 'Mn')
    folded = stripped.casefold()
    # Remove common noise: feat., ft., parenthetical extras
    folded = re.sub(r'\s*\(.*?\)', '', folded)
    folded = re.sub(r'\s*\[.*?\]', '', folded)
    folded = re.sub(r'\b(feat\.?|ft\.?)\b.*', '', folded)
    return re.sub(r'\s+', ' ', folded).strip()


def _names_match(a: str, b: str) -> bool:
    """Fuzzy comparison after normalisation."""
    na, nb = _normalise(a), _normalise(b)
    if not na or not nb:
        return False
    if na == nb:
        return True
    # One contains the other (handles "The Night Owls" vs
    # "The Night Owls & …" or "Do I Still Recall?" vs
    # "Do I Still Recall? - Single Version").
    return na in nb or nb in na


def _query_pair(artist: str, title: str, album: str) -> tuple[str, str]:
    """The search query and, when useful, an album-disambiguated one.

    For the "album tag is the song's own title" case the two would be the
    same query — asking twice only burns the rate budget, so the second
    is dropped.
    """

    primary = f'{artist} {title}'.strip()
    if album and _normalise(album) != _normalise(title):
        return primary, f'{artist} {title} {album}'.strip()
    return primary, ''


# ── iTunes API call ───────────────────────────────────────────────
def is_available() -> bool:
    """False while iTunes is in a block cooldown (see :data:`_BLOCK_LIMIT`)."""

    return time.monotonic() >= _down_until


def _rate_wait() -> None:
    """Block until the cooldown is over and the spacing has elapsed."""

    global _last_request_time
    with _rate_lock:
        now = time.monotonic()
        wait = max(
            _cooldown_until - now,
            _MIN_INTERVAL - (now - _last_request_time),
        )
        if wait > 0:
            time.sleep(wait)
        _last_request_time = time.monotonic()


def _note_blocked(status: int) -> None:
    """Back off after a refusal and, after a few in a row, mark it down."""

    global _cooldown_until, _down_until, _consecutive_blocks
    with _rate_lock:
        _consecutive_blocks += 1
        _cooldown_until = max(
            _cooldown_until, time.monotonic() + _COOLDOWN_SECONDS
        )
        if _consecutive_blocks >= _BLOCK_LIMIT:
            _down_until = time.monotonic() + _DOWN_SECONDS
    logger.warning(
        'iTunes Search returned HTTP {} — backing off {}s (down for {}s '
        'after {} refusals)',
        status,
        int(_COOLDOWN_SECONDS),
        int(_DOWN_SECONDS),
        _consecutive_blocks,
    )


def _note_success() -> None:
    global _consecutive_blocks
    _consecutive_blocks = 0


def _get_json(url: str) -> Optional[dict[str, Any]]:
    """GET *url*, pacing and backing off around iTunes' rate limit.

    Returns ``None`` on any failure (network, refusal, unreadable body);
    a genuine ``200`` with no results is a real answer, not a failure.
    """

    _rate_wait()
    try:
        resp = httpx.get(
            url,
            timeout=_TIMEOUT,
            headers={
                'User-Agent': _USER_AGENT,
                'Accept': 'application/json',
            },
        )
    except Exception:
        logger.opt(exception=True).debug('iTunes request failed: {}', url)
        return None
    if resp.status_code in {403, 429} or resp.status_code >= 500:
        _note_blocked(resp.status_code)
        return None
    try:
        resp.raise_for_status()
        data = resp.json()
    except Exception:
        logger.opt(exception=True).debug('iTunes response unreadable')
        return None
    _note_success()
    return data if isinstance(data, dict) else None


def _search_itunes(query: str, limit: int = 5) -> list[dict[str, Any]]:
    """Call the iTunes Search API and return the ``results`` list.

    Successful responses (including an empty result set) are cached, so
    the same query is never fetched twice in a run. A refusal is not
    cached — the next call may find iTunes back.
    """

    cache_key = f'{query.strip().casefold()}|{limit}'
    with _cache_lock:
        cached = _search_cache.get(cache_key)
    if cached is not None:
        return cached
    if not is_available():
        return []

    params = f'term={quote_plus(query)}&entity=song&limit={limit}'
    url = f'{_ITUNES_SEARCH_URL}?{params}'
    data = _get_json(url)
    if data is None:
        return []
    results = data.get('results') or []
    with _cache_lock:
        if len(_search_cache) > 4096:
            _search_cache.clear()
        _search_cache[cache_key] = results
    logger.debug(
        'iTunes Search returned {} result(s) for q={!r}',
        len(results),
        query[:100],
    )
    return results


# ── Best-match selection ──────────────────────────────────────────
def _pick_best(
    results: list[dict[str, Any]],
    artist: str,
    title: str,
) -> Optional[dict[str, Any]]:
    """Return the result whose artist + track name best match."""
    for r in results:
        if r.get('wrapperType') != 'track':
            continue
        if r.get('kind') != 'song':
            continue
        r_artist = r.get('artistName', '')
        r_title = r.get('trackName', '')
        if _names_match(r_artist, artist) and _names_match(r_title, title):
            return r
    # Fallback: accept any result whose title matches (artist may
    # differ due to "feat." / collaboration discrepancies).
    for r in results:
        if r.get('wrapperType') != 'track' or r.get('kind') != 'song':
            continue
        if _names_match(r.get('trackName', ''), title):
            return r
    return None


# ── Public API ────────────────────────────────────────────────────
def fetch_genre(song: dict[str, Any]) -> str:
    """Return the genre string for *song*, or ``""`` if unavailable.

    ``song`` is the standard Downtify track dict with at least
    ``name``, ``artists`` (list[str]) and optionally ``album_name``.
    """

    artists = song.get('artists') or []
    artist = artists[0] if artists else (song.get('artist') or '')
    title = song.get('name', '')
    album = song.get('album_name', '')

    if not artist and not title:
        return ''

    # ── Check album-level cache first ─────────────────────────────
    cache_key = f'{_normalise(artist)}|{_normalise(album)}' if album else ''
    if cache_key:
        with _cache_lock:
            cached = _genre_cache.get(cache_key)
        if cached is not None:
            logger.debug(
                'iTunes genre cache hit: {} → {!r}', cache_key, cached
            )
            return cached

    # ── Search iTunes ─────────────────────────────────────────────
    query, query_alt = _query_pair(artist, title, album)
    results = _search_itunes(query, limit=5)
    match = _pick_best(results, artist, title)

    if match is None and query_alt:
        # Retry with the album name for disambiguation.
        results_alt = _search_itunes(query_alt, limit=5)
        match = _pick_best(results_alt, artist, title)

    genre = ''
    if match:
        genre = (match.get('primaryGenreName') or '').strip()
        logger.info(
            'iTunes genre resolved: {!r} by {!r} → {!r}',
            title,
            artist,
            genre,
        )
    else:
        logger.info('iTunes genre: no match for {!r} by {!r}', title, artist)

    # ── Populate album cache ──────────────────────────────────────
    if cache_key and genre:
        with _cache_lock:
            _genre_cache[cache_key] = genre
    elif cache_key:
        # Negative cache: avoid retrying the same album repeatedly.
        with _cache_lock:
            _genre_cache.setdefault(cache_key, '')

    return genre


# ── Track metadata ────────────────────────────────────────────────────
#: How far the duration an iTunes match reports may drift from the
#: file's own before the match is distrusted. Same-named live versions,
#: remixes and remasters must not rewrite a studio track's tags.
_METADATA_DURATION_TOLERANCE_SECONDS = 10.0


def _duration_matches(match: dict[str, Any], song: dict[str, Any]) -> bool:
    millis = match.get('trackTimeMillis')
    duration = float(song.get('duration') or 0.0)
    if not millis or duration <= 0:
        return True
    remote = float(millis) / 1000.0
    return abs(remote - duration) <= _METADATA_DURATION_TOLERANCE_SECONDS


def lookup_track_metadata(song: dict[str, Any]) -> Optional[dict[str, Any]]:
    """Album, year, track number and genre for *song*, or ``None``.

    Same search and best-match selection as :func:`fetch_genre`, for
    tracks whose Spotify ID is not known and which therefore can't be
    re-read from Spotify. A match whose duration disagrees with the
    file's by more than ten seconds is rejected; ``None`` means "no
    safe match", and the caller leaves the file's tags alone.
    """

    artists = song.get('artists') or []
    artist = artists[0] if artists else (song.get('artist') or '')
    title = song.get('name', '') or song.get('title', '')
    album = song.get('album_name', '') or song.get('album', '')

    if not title:
        return None

    query, query_alt = _query_pair(artist, title, album)
    match = _pick_best(_search_itunes(query, limit=5), artist, title)
    if match is None and query_alt:
        # Retry with the album name in the query for disambiguation.
        match = _pick_best(_search_itunes(query_alt, limit=5), artist, title)

    if match is None or not _duration_matches(match, song):
        logger.debug(
            'iTunes metadata: no safe match for {!r} by {!r}', title, artist
        )
        return None

    release = str(match.get('releaseDate') or '')
    found = {
        'album_name': str(match.get('collectionName') or ''),
        'album_artist': str(
            match.get('collectionArtistName') or match.get('artistName') or ''
        ),
        'year': release[:4],
        'release_date': release[:10],
        'track_number': int(match.get('trackNumber') or 0),
        'genre': str(match.get('primaryGenreName') or '').strip(),
    }
    logger.info(
        'iTunes metadata resolved: {!r} by {!r} → album {!r}',
        title,
        artist,
        found['album_name'],
    )
    return found


# ── Cover art ─────────────────────────────────────────────────────
#: Every artwork URL iTunes returns ends in ``<size>x<size>bb.<ext>``;
#: asking for a larger size returns a genuinely larger image, up to the
#: original master (commonly 1400px, sometimes 3000px).
_ARTWORK_SIZE_SUFFIX = re.compile(r'/\d+x\d+bb\.(jpg|png)$')


def artwork_url_at(url: str, size: int) -> str:
    """Rewrite an iTunes artwork URL to ask for a ``size``-pixel square."""

    if not url:
        return ''
    return _ARTWORK_SIZE_SUFFIX.sub(
        lambda m: f'/{size}x{size}bb.{m.group(1)}', url
    )


def search_podcasts(query: str, limit: int = 10) -> list[dict[str, Any]]:
    """Search the iTunes podcast directory for *query*.

    Keyless, like the song search above. Each result carries a
    ``feedUrl`` — the show's public RSS feed — when one is on file;
    Spotify-exclusive shows and other feed-less listings come back
    without it, which callers must treat as "can't be downloaded"
    rather than retrying or guessing a feed.
    """

    if not query.strip():
        return []
    params = f'term={quote_plus(query)}&entity=podcast&limit={max(1, limit)}'
    url = f'{_ITUNES_SEARCH_URL}?{params}'
    data = _get_json(url)
    if data is None:
        return []
    results = data.get('results') or []
    return [r for r in results if isinstance(r, dict) and r.get('feedUrl')]


def resolve_podcast_feed(show_name: str) -> Optional[dict[str, Any]]:
    """The best iTunes match for a show name, or ``None``.

    Used to turn a Spotify show/episode link — which only ever gives a
    name, never a feed — into an RSS feed URL. Matching is the same
    "does the name line up" heuristic as songs; a podcast can't be
    disambiguated by album the way a song can, so a false-positive
    match here means the wrong show's episodes.
    """

    name = (show_name or '').strip()
    if not name:
        return None
    for r in search_podcasts(name, limit=10):
        if _names_match(r.get('collectionName', ''), name):
            return {
                'name': r.get('collectionName', name),
                'author': r.get('artistName', ''),
                'feed_url': r.get('feedUrl', ''),
                'artwork_url': r.get('artworkUrl600', ''),
            }
    logger.info('iTunes podcast: no feed match for {!r}', name)
    return None


def fetch_artwork_url(song: dict[str, Any], size: int = 1200) -> str:
    """Return an iTunes cover URL for *song* at *size* px, or ``""``.

    Same matching as :func:`fetch_genre`: artist and title must line up,
    with a title-only fallback for differing "feat." credits.
    """

    artists = song.get('artists') or []
    artist = artists[0] if artists else (song.get('artist') or '')
    title = song.get('name', '') or song.get('title', '')
    album = song.get('album_name', '') or song.get('album', '')

    if not title:
        return ''

    cache_key = f'{_normalise(artist)}|{_normalise(album)}' if album else ''
    if cache_key:
        with _cache_lock:
            cached = _artwork_cache.get(cache_key)
        if cached is not None:
            return artwork_url_at(cached, size) if cached else ''

    query, query_alt = _query_pair(artist, title, album)
    match = _pick_best(_search_itunes(query, limit=5), artist, title)
    if match is None and query_alt:
        match = _pick_best(_search_itunes(query_alt, limit=5), artist, title)

    base = str((match or {}).get('artworkUrl100') or '').strip()
    if cache_key:
        with _cache_lock:
            _artwork_cache.setdefault(cache_key, base)
    if not base:
        logger.debug(
            'iTunes artwork: no match for {!r} by {!r}', title, artist
        )
        return ''
    return artwork_url_at(base, size)
